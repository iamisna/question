#include "vpmac.h"

/* 
 * 기능 : 입력받은 메시지 길이의 패딩 후 메시지 길이 계산
 * 입력 : 패딩전 메시지 길이
 * 출력 : 패딩후 메시지 길이
 */
int Pad_len(int bytelen)
{
    int tmp = bytelen%(16*Mac_msg_len);
    return bytelen + (16*Mac_msg_len -tmp);     //padding 후에 필요한 길이.

}

/* 
 * 기능 : 입력받은 메시지 길이에 one-zero 패딩을 한 결과를 dst에 저장.
 * 입력 : 패딩전 메시지, 패딩후 메시지 길이
 * 출력 : 없음
 */
void Pad_msg(byte** dst, byte* src, int bytelen)
{
    for(int i =0; i<bytelen;i++){
        (*dst)[i] = src[i]; 
    }
    (*dst)[bytelen] = 0x80;             // one-zero padding
}

/* 
 * 기능 : VP 서명 생성 함수
 * 입력 : 메시지, 키테이블, 메시지의 길이
 * 출력 : 없음
 */
void VPMAC_gen(byte* dst, const int srclen, 
    WBWFLEA_MAC_WK1* wk1_tab, WBWFLEA_MAC_WK2* wk2_tab, byte* src)
{
    /* 메시지 원하는 블록만큼 패딩 */
    int pad_len = Pad_len(srclen);
    byte *padded_msg;    
    padded_msg = calloc(pad_len, sizeof(int));  

    Pad_msg(&padded_msg, src, srclen);   //one-zero pad to msg

    /* 파라미터 설정 */
    int blklen = pad_len/16;           // block length
    byte enc[16] = {0x0,};  
    byte IV[16]= {0x0,};
    memcpy(IV,wk2_tab->IV,16);

    /* 블록 길이만큼 반복 */
    for(int i=0;i<blklen;i++)    
    {
        /* 키테이블을 이용한 XOR 연산 */
        for(int j=0;j<16;j++)
        {
            byte tmp = wk2_tab->XOR[j/4][(2*j+1)%8   ][((( (padded_msg[16*i+j] >>4)&0xf)<<4 )^ ((IV[j] >>4)&0xf) )];

            enc[j] = ((tmp & 0xf) << 4);

            enc[j] ^= wk2_tab->XOR[j/4][(2*j)%8 ][(( (padded_msg[16*i+j]&0xf)<<4 )^ (IV[j]&0xf)) ];
        }
        /* wbwflea */
        wbwflea_sep_encryptwb(wk1_tab, wk2_tab, (byte*)enc);

        /* IV 갱신 */
        for(int j=0;j<16;j++)
        {
            IV[j]= enc[j];        
        }
    }
    for(int j=0;j<16;j++)
    {
        dst[j]= IV[j];        
    }
    free(padded_msg);
}


/* 
 * 기능 : VP 서명 검증 함수 (non wb)
 * 입력 : 메시지, 키, 메시지의 길이, IV, 화이트박스 연산시 사용한 Be, 서명 생성에서 생성한 tag
 * 출력 : VALID or INVALID
 */
int VPMAC_verify( const int srclen,
    byte* key, byte* src, byte* IV, byte* BeSeed, byte* tag)
{
    WFLEA_CTX wfleactx;
    wflea_gen_ctx(&wfleactx, 128, key); 

    WBWFLEA_EXT_ENCODING Be;
    gen_randperm_128bits(&Be, BeSeed); 

    /* 메시지 패딩 */
    int pad_len = Pad_len(srclen);
    byte *padded_msg;    
    padded_msg = calloc(pad_len, sizeof(int));  
    Pad_msg(&padded_msg, src, srclen);   //one-zero pad to msg

    int blklen = pad_len/16;           // block length

    byte IVtmp[16] = {0x0,};
    byte enc[16] = {0x0,};  
    byte dec[16] = {0x0,};

    memcpy(IVtmp,IV,16);

    for(int i=0;i<blklen;i++)     
    {
        for(int j=0;j<16;j++)
        {
            enc[j] = padded_msg[16*i+j] ^ IVtmp[j] ;
        }
                
        wflea_encryptblk_4bits(dec, enc, &wfleactx);             // in sign, usign wfLEA. not Wbwflea.

        for(int j=0;j<16;j++)
        {
            IVtmp[j]= dec[j];        
        }
    }

    /* 생성된 tag에 Be를 이용하여 화이트 박스 연산과 비교 */    
    wbwflea_ext_transform(&Be, (word*)(dec), 1);

    free(padded_msg);
    
    /* 서명이 동일한지 판단 */
    for (int j = 0; j < 16; j++)
    {
        if(dec[j] != tag[j])
        {
            return INVALID;
        }
    }

    return VALID;

}


/* 
 * 기능 : LEA CBC-MAC 연산 (non wb). tag를 dst에 저장
 * 입력 : 메시지, 키, 메시지의 길이, IV
 * 출력 : 없음
 */
void CBCMAC_LEA(byte* dst, const byte* src, byte* IV, const int srclen, byte* key)
{
    WFLEA_CTX ctx;
    wflea_gen_ctx(&ctx, 128, key); 

    int blklen = srclen/16;

    byte enc[16] = {0x0,};  
    byte dec[16] = {0x0,}; 
    byte inIV[16] ={0x0,};

    memcpy(inIV,IV,16);
    for(int i=0;i<blklen;i++)     
    {
        for(int j=0;j<16;j++)
        {
            enc[j] = src[16*i+j]^inIV[j];    //iv와 xor
        }

        wflea_encryptblk(dec, enc, &ctx);    //lea 연산

        for(int j=0;j<16;j++)
        {
            inIV[j]= dec[j];        
        }
            
    }
    for(int j=0;j<16;j++)
    {
        dst[j]= inIV[j];        //마지막 결과 dst로 저장
    }

}

/* 
 * 기능 : WK1 생성함수
 * 입력 : Ain생성 시드, Bin 생성 시드, key
 * 출력 : 없음
 */
void VPMAC_WK1_KEY_GEN(WBWFLEA_MAC_WK1* wk1_tab, byte* AinSeed, byte* BinSeed, byte* key){
    /* setup: WFLEA context (roundkey generation) */
    WFLEA_CTX wflea_ctx;
    wflea_gen_ctx(&wflea_ctx, WBWFLEA_KEY_BYTES*8, key);

    WBWFLEA_EXT_ENCODING Ain, Bin;
    gen_randperm_128bits(&Ain, AinSeed); 
    gen_randperm_128bits(&Bin, BinSeed); 

    WBWFLEA_ENCODINGS_FOR_MACMID enc_ctx2;

    wbwflea_gen_encodings_for_MACmid(&enc_ctx2, Ain, Bin);        // 외부인코딩 포함 내부 퍼뮤테이션 생성
    
    wbwflea_gen_MAC_enc_tablemid(wk1_tab, &enc_ctx2, &wflea_ctx); // 퍼뮤테이션을 이용한 테이블 생성.

}

/* 
 * 기능 : WK2 생성함수
 * 입력 : Ain생성 시드, Bin 생성 시드, IV, 외부인코딩 시드, key
 * 출력 : 없음
 */

void VPMAC_WK2_KEY_GEN(WBWFLEA_MAC_WK2* wk2_tab, byte* AinSeed, byte* BinSeed, byte* IV, byte* BeSeed, byte* key){
   /* setup: WFLEA context (roundkey generation) */
    WFLEA_CTX wflea_ctx;
    wflea_gen_ctx(&wflea_ctx, WBWFLEA_KEY_BYTES*8, key);
    
    /* external encoding generation (for encryption) */
    WBWFLEA_EXT_ENCODING Ae, Be;

    wbwflea_gen_ext_encoding(&Ae);

    gen_randperm_128bits(&Be, BeSeed); 

    /* wk2 start*/

    WBWFLEA_ENCODINGS_FOR_MACfirst enc_ctx1;
    // gen_rand_bytes_using_randf(seed, 32);
    // drbg_setup(seed);

    WBWFLEA_EXT_ENCODING Ain,Bin;
    gen_randperm_128bits(&Ain, AinSeed); 
    gen_randperm_128bits(&Bin, BinSeed); 


    wbwflea_gen_encodings_for_MACfirst(&enc_ctx1,&Ae,Ain);        //  table1  wk2 permutation
    
    WBWFLEA_ENCODINGS_FOR_MACend enc_ctx3;
    // gen_rand_bytes_using_randf(seed, 32);
    // drbg_setup(seed);

    wbwflea_gen_encodings_for_MACend(&enc_ctx3, Bin,&Be);         //  table3  wk2 permutation
    
    wbwflea_gen_MAC_enc_tablefirst(wk2_tab, &enc_ctx1, &wflea_ctx);   //  table1  wk2
    wbwflea_gen_MAC_enc_tableend(wk2_tab, &enc_ctx3, &wflea_ctx);     //  table3  wk2 

    
    /* CBC-table-permutation */
    WBWFLEA_EXT_ENCODING CBCAe;    //CBC에서 f인코딩

    wbwflea_gen_ext_identity_encoding(&CBCAe);   // wk2  xor permutation

    cbc_gen_encoding_table(wk2_tab, &CBCAe, &Be, &Ae); // wk2  table4

    memcpy(wk2_tab->IV,IV,16);


}
