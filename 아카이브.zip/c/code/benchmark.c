#include "benchmark.h"

#define MAX_CBCBYTELEN 1000
#define MAX_CTRBYTELEN 1000
#define MAX_VPMACBYTELEN 1000

/* 
 * 기능 : WBWFLEA의 키생성, 암호화, 복호화 연산 시간측정
 * 입력 : 없음
 * 출력 : 없음
 */
void TIME_WBWFL()
{
    clock_t start, finish;
    double duration;

    /* setup: key */
    byte key[32] = {0x0,};
    gen_rand_bytes(key, 32);                                //랜덤하게 Key 생성. 
    
    /* setup: WFLEA context (roundkey generation) */
    WFLEA_CTX wflea_ctx;
    wflea_gen_ctx(&wflea_ctx, WBWFLEA_KEY_BYTES*8, key);    //key 설정.

    byte enc[16] = {0x0,};   
    gen_rand_bytes(enc, 16);                                //테스트를 위해 랜덤한 평문 생성.

    /* external encoding generation (for encryption) */
    WBWFLEA_EXT_ENCODING Ae, Be;
    byte AeSeed[32] = {0x0,}; 
    byte BeSeed[32] = {0x0,};
    gen_rand_bytes(AeSeed, 32);                             // 외부인코딩 생성을 위해 drbg용 랜덤 시드 생성
    gen_rand_bytes(BeSeed, 32);                             

    gen_randperm_128bits(&Ae, AeSeed);                      // 랜덤 시드를 이용하여 외부 인코딩 생성.
    gen_randperm_128bits(&Be, BeSeed);                      

    WBWFLEA_ENCODINGS_FOR_ENCRYPTION enc_ctx;
    wbwflea_gen_encodings_for_encryption_notable(&enc_ctx, &Ae, &Be);  // 외부인코딩포함 암호화용 permutation 생성.

    WBWFLEA_ENCRYPTION_TABLE enc_tab;

    start=clock();
    for (int cnt=0;cnt<iteration_num;cnt++){
        wbwflea_gen_encryption_table(&enc_tab, &enc_ctx, &wflea_ctx);      // pemutation과 key를 이용하여 암호화 카테이블 생성
    }
    finish = clock();
    duration = (double)(finish-start)/CLOCKS_PER_SEC;

    printf("%d WBWFLEA ENC Keytable gen %f sec.\n",iteration_num,duration);

    byte wbe_dat[16] = {0x0,}; memcpy(wbe_dat, enc, 16);         // WFLEA와 결과 비교를 위해 동일한 평문 사용. 

    start=clock();
    for (int cnt=0;cnt<((blklen+1)*iteration_num);cnt++){
        wbwflea_encryptwb(&enc_tab, (byte*)wbe_dat);                  // 화이트박스 암호화
    }
    finish = clock();
    duration = (double)(finish-start)/CLOCKS_PER_SEC;

    printf("%d WBWFLEA Encrypt %f sec.\n",iteration_num,duration);



    /* external encoding generation (for decryption) */
    WBWFLEA_EXT_ENCODING Ad, Bd;
    byte AdSeed[32] = {0x0,}; 
    byte BdSeed[32] = {0x0,};
    gen_rand_bytes(AdSeed, 32);             // 외부인코딩 생성을 위해 drbg용 랜덤 시드 생성
    gen_rand_bytes(BdSeed, 32);

    gen_randperm_128bits(&Ad, AdSeed);
    gen_randperm_128bits(&Bd, BdSeed);      // 랜덤 시드를 이용하여 외부 인코딩 생성.

    /* random networked encodings generation (for decryption) */
    WBWFLEA_ENCODINGS_FOR_DECRYPTION dec_ctx;
    wbwflea_gen_encodings_for_decryption_notable(&dec_ctx, &Ad, &Bd);   // 외부인코딩포함 복호화용 permutation 생성.

    /* decryption table generation with external encoding, random networked encodings, roundkey */
    WBWFLEA_DECRYPTION_TABLE dec_tab;


    start=clock();
    for (int cnt=0;cnt<iteration_num;cnt++){
        wbwflea_gen_decryption_table(&dec_tab, &dec_ctx, &wflea_ctx);   // pemutation과 key를 이용하여 복호화 카테이블 생성
    }
    finish = clock();
    duration = (double)(finish-start)/CLOCKS_PER_SEC;

    printf("%d WBWFLEA Dec Keytable gen %f sec.\n",iteration_num,duration);


    byte wbd_dat[16] = {0x0,}; memcpy(wbd_dat, wbe_dat, 16);    // 라운드 트립 결과 비교를 위해 동일한 암호문 사용. 
    
    start=clock();
    for (int cnt=0;cnt<((blklen+1)*iteration_num);cnt++){
        wbwflea_decryptwb(&dec_tab, (byte*)wbd_dat);                // 화이트박스 복호화 
    }
    finish = clock();
    duration = (double)(finish-start)/CLOCKS_PER_SEC;

    printf("%d WBWFLEA Decrypt %f sec.\n",iteration_num,duration);

}


/* 
 * 기능 : WBCBC의 키생성, 암호화, 복호화 연산 시간측정
 * 입력 : 없음
 * 출력 : 없음
 */
void TIME_WBCBC()
{
    clock_t start, finish;
    double duration;

    byte key[16] ={0x0,};   gen_rand_bytes(key,16);    //랜덤하게 Key 생성.
    byte IV[16]  ={0x0,};    gen_rand_bytes(IV,16);    //랜덤하게 IV 생성.

    byte WbIV[16];                  //WBLEA CBC 용 IV
    memcpy(WbIV,IV,16);    

    byte wbe_dat[MAX_CBCBYTELEN] ={0x0,};   // wbcbc용 평문
    gen_rand_bytes(wbe_dat,blklen*16);     // 랜덤한 평문 생성


    int wb_data_len = blklen*16;           // 입력받은 wbcbc bytelen 설정.

    /* external encoding generation (for encryption) */
    WBWFLEA_EXT_ENCODING Be;            
    byte BeSeed[32] = {0x0,};               //외부 인코딩 Be를 생성하기 위한 seed
    gen_rand_bytes(BeSeed, 32);             //BeSeed 랜덤 생성
    gen_randperm_128bits(&Be, BeSeed);      //BeSeed를 이용하여 외부 인코딩 생성

    /* encryption table */
    WBWFLEA_ENCRYPTION_TABLE enc_tab;       //wblea 암호화 테이블
    XOR_TABLE cbc_ex_tab;                   //암호화용 xor 테이블

    /*Xor encoding (for encryption) */
    WBWFLEA_EXT_ENCODING CBCAe;             
    byte CBCAeSeed[32] = {0x0,};            //xor 인코딩 CBCAe 생성을 위한 seed
    gen_rand_bytes(CBCAeSeed, 32);          //CBCAeSeed 랜덤 생성
    gen_randperm_128bits(&CBCAe, CBCAeSeed);//CBCAeSeed를 이용하여 인코딩 생성

    /* CBC encryption table  */

    start=clock();
    for (int cnt=0;cnt<iteration_num;cnt++){
        CBC_KEY_GEN_ENC(&enc_tab, &cbc_ex_tab, CBCAeSeed, BeSeed, key); //필요한 외부인코딩의 시드를 입력받아 암호화 테이블 생성
    }
    finish = clock();
    duration = (double)(finish-start)/CLOCKS_PER_SEC;

    printf("%d WBCBC Enc Keytable gen %f sec.\n", iteration_num,duration);


    /*WBLEA CBC encryption*/
    /*encryption*/

    /*encode in wb-secure zone*/
    byte* encoded_msg;   // wbcbc 인코딩후 메시지 

    byte wbe_dat2[MAX_CBCBYTELEN];
    memcpy(wbe_dat2,wbe_dat,wb_data_len);
    int wb_data_len2;
    wb_data_len2=wb_data_len;

    duration=0;
    for (int cnt=0;cnt<iteration_num;cnt++){                                       

        wb_data_len = wb_data_len2;
        memcpy(wbe_dat,wbe_dat2,wb_data_len);
        start=clock();
        
        Encode(&encoded_msg, wbe_dat, &wb_data_len, CBCAeSeed);         // 패딩 + 외부인코딩
        WBCBC_LEA(wb_data_len, &enc_tab, &cbc_ex_tab, (byte*)encoded_msg, WbIV);    //WBCBC encryption
    
        finish = clock();
        duration += (double)(finish-start)/CLOCKS_PER_SEC;
    }
    printf("%d WBCBC Encrypt %f sec.\n", iteration_num,duration);


    /*WBCBC decryption*/

    /* decryption table gen */
    WBWFLEA_DECRYPTION_TABLE dec_tab;       //wblea 복호화 테이블
    XOR_TABLE cbc_de_ex_tab;                //복호화용 xor 테이블

    /*Xor encoding (for decryption) */
    WBWFLEA_EXT_ENCODING CBCBe;             
    byte CBCBeSeed[32] = {0x0,};            //xor 인코딩 CBCBe 생성을 위한 seed
    gen_rand_bytes(CBCBeSeed, 32);          //CBCBeSeed 랜덤 생성
    gen_randperm_128bits(&CBCBe, CBCBeSeed);//CBCBeSeed를 이용하여 인코딩 생성

    start=clock();
    for (int cnt=0;cnt<iteration_num;cnt++){
        CBC_KEY_GEN_DEC(&dec_tab, &cbc_de_ex_tab, CBCBeSeed, BeSeed, key);//필요한 외부인코딩의 시드를 입력받아 암호화 테이블 생성
    }
    finish = clock();
    duration = (double)(finish-start)/CLOCKS_PER_SEC;

    printf("%d WBCBC Dec Keytable gen %f sec.\n", iteration_num,duration);

    /* decryption */

    byte* wbdecmsg;

    memcpy(wbe_dat2,encoded_msg,wb_data_len);
    wb_data_len2=wb_data_len;

    duration=0;
    for (int cnt=0;cnt<iteration_num;cnt++){
        wb_data_len=wb_data_len2;
        memcpy(encoded_msg,wbe_dat2,wb_data_len);

        start=clock();

        Inv_WBCBC_LEA(wb_data_len, &dec_tab, &cbc_de_ex_tab, (byte*)encoded_msg, WbIV); // WBCBC 복호화.
        Decode(&wbdecmsg, encoded_msg, &wb_data_len, CBCBeSeed);    // 패딩 + 외부인코딩 

        finish = clock();
        duration += (double)(finish-start)/CLOCKS_PER_SEC;
    }

    printf("%d WBCBC Decrypt %f sec.\n", iteration_num,duration);

    free(encoded_msg);
    free(wbdecmsg);

}


/* 
 * 기능 : WBCTR의 키생성, 암호화, 복호화 연산 시간측정
 * 입력 : 없음
 * 출력 : 없음
 */
void TIME_WBCTR()
{
    clock_t start, finish;
    double duration;

    /* param set */
    byte key[16] ={0x0,};   gen_rand_bytes(key,16);    //랜덤하게 Key 생성.
    byte IV[16]  ={0x0,};    gen_rand_bytes(IV,16);    //랜덤하게 IV 생성.

    byte WbIV[16];     // WBLEA CTR 용 IV
    memcpy(WbIV,IV,16);

    byte wbe_dat[MAX_CBCBYTELEN] ={0x0,};   // wbcbc용 평문
    gen_rand_bytes(wbe_dat,blklen*16);     // 랜덤한 평문 생성

    int wb_data_len = blklen*16;         // 입력받은 wbctr bytelen 설정.

    /* CTR-table-permutation */
    WBWFLEA_EXT_ENCODING Ae;   
    byte AeSeed[32] = {0x0,};               //외부인코딩 Ae용 seed
    gen_rand_bytes(AeSeed, 32);             //랜덤 생성
    gen_randperm_128bits(&Ae, AeSeed);      //Aeseed를 이용하여 Ae 생성

    WBWFLEA_EXT_ENCODING CTRG;    
    byte CTRGSeed[32] = {0x0,};             //xor용 외부인코딩 CTRG용 seed
    gen_rand_bytes(CTRGSeed, 32);           //랜덤 생성
    gen_randperm_128bits(&CTRG, CTRGSeed);  //CTRGseed를 이용하여 CTRG 생성

    WBWFLEA_EXT_ENCODING CTRH;              
    byte CTRHSeed[32] = {0x0,};             //xor용 외부인코딩 CTRH용 seed
    gen_rand_bytes(CTRHSeed, 32);           //랜덤 생성
    gen_randperm_128bits(&CTRH, CTRHSeed);  //CTRHseed를 이용하여 CTRH 생성
    
    /* encryption table */
    WBWFLEA_ENCRYPTION_TABLE enc_tab;
    XOR_TABLE ctr_ex_tab;

    start=clock();
    for (int cnt=0;cnt<iteration_num;cnt++){
        CTR_KEY_GEN_ENC(&enc_tab, &ctr_ex_tab, AeSeed, CTRHSeed, CTRGSeed, key); //필요한 외부인코딩의 시드를 입력받아 암호화 테이블 생성
    }
    finish = clock();
    duration = (double)(finish-start)/CLOCKS_PER_SEC;

    printf("%d WBCTR Enc Keytable gen %f sec.\n", iteration_num,duration);

    /*encode in wb-secure zone*/
    byte* encoded_msg;                                          //인코딩된 메시지 저장

    byte wbe_dat2[MAX_CBCBYTELEN];
    memcpy(wbe_dat2,wbe_dat,wb_data_len);
    int wb_data_len2;
    wb_data_len2=wb_data_len;

    duration=0;
    for (int cnt=0;cnt<iteration_num;cnt++){                                           
        wb_data_len = wb_data_len2;
        memcpy(wbe_dat,wbe_dat2,wb_data_len);

        start=clock();
        
        Encode(&encoded_msg, wbe_dat, &wb_data_len, CTRGSeed);          // 패딩 +인코딩
        WBCTR_LEA(wb_data_len, &enc_tab, &ctr_ex_tab, (byte*)encoded_msg, WbIV); // WBCTR encryption  
        
        finish = clock();
        duration += (double)(finish-start)/CLOCKS_PER_SEC;
    }
    
    printf("%d WBCTR Encrypt %f sec.\n", iteration_num,duration);

    /*WBCTR decryption*/

    /* decryption table gen*/
    WBWFLEA_ENCRYPTION_TABLE dec_tab;   //wblea 복호화 테이블
    XOR_TABLE ctr_de_ex_tab;            //복호화용 XOR 테이블

    /* CTR-table-permutation */
    WBWFLEA_EXT_ENCODING CTRHd;   
    byte CTRHdSeed[32] = {0x0,};        //xor 인코딩 CTRHd 생성을 위한 seed
    gen_rand_bytes(CTRHdSeed, 32);      //CTRHdSeed 랜덤 생성
    gen_randperm_128bits(&CTRHd, CTRHdSeed); //CTRHdSeed를 이용하여 인코딩 생성

    start=clock();
    for (int cnt=0;cnt<iteration_num;cnt++){                                       

       CTR_KEY_GEN_DEC(&dec_tab, &ctr_de_ex_tab, AeSeed, CTRHSeed, CTRHdSeed, key);
    }
    finish = clock();
    duration = (double)(finish-start)/CLOCKS_PER_SEC;

    printf("%d WBCTR Dec Keytable gen %f sec.\n", iteration_num,duration);
    
    byte* wbdecmsg;

    memcpy(wbe_dat2,encoded_msg,wb_data_len);
    wb_data_len2=wb_data_len;

    duration=0;
    for (int cnt=0;cnt<iteration_num;cnt++){                                       
        wb_data_len=wb_data_len2;
        memcpy(encoded_msg,wbe_dat2,wb_data_len);

        start=clock();
        WBCTR_LEA(wb_data_len, &dec_tab, &ctr_de_ex_tab, (byte*)encoded_msg, WbIV);  //WBCTR  복호화
        Decode(&wbdecmsg, encoded_msg, &wb_data_len, CTRHdSeed); //패딩 부분 삭제 
        finish = clock();
        duration += (double)(finish-start)/CLOCKS_PER_SEC;

    }

    printf("%d WBCTR Decrypt %f sec.\n", iteration_num,duration);

    free(encoded_msg);
    free(wbdecmsg);

}


/* 
 * 기능 : VPMAC의 키생성, 서명생성, 서명 검증 연산 시간측정
 * 입력 : 없음
 * 출력 : 없음
 */
void TIME_VPMAC()
{
    clock_t start, finish;
    double duration;

    /*param gen*/
    byte key[16] ={0x0,};   gen_rand_bytes(key,16);    //랜덤하게 Key 생성.
    byte IV[16]  ={0x0,};    gen_rand_bytes(IV,16);    //랜덤하게 IV 생성.

    byte IVsig[16]={0,};    //서명용 IV
    memcpy(IVsig,IV,16);    //동일한 IV 저장.

    byte wbe_dat[MAX_VPMACBYTELEN]={0x0,}; // 서명생성용 평문
    gen_rand_bytes(wbe_dat,blklen*16);    // 랜덤 생성

    byte copy_dat[MAX_VPMACBYTELEN];        // 서명 검증용 평문 생성
    memcpy(copy_dat,wbe_dat,blklen*16);    // 서명 생성과 동일

    int data_len = blklen*16;       //입력받은 byte 길이
 

    /* setup: WFLEA context (roundkey generation) */
    WFLEA_CTX wflea_ctx;
    wflea_gen_ctx(&wflea_ctx, WBWFLEA_KEY_BYTES*8, key);

    /* external encoding generation (for encryption) */
    WBWFLEA_EXT_ENCODING Be;       
    byte BeSeed[32] = {0x0,};               //외부 인코딩 Be를 생성하기 위한 seed
    gen_rand_bytes(BeSeed, 32);             //BeSeed 랜덤 생성
    gen_randperm_128bits(&Be, BeSeed);      //BeSeed를 이용하여 외부 인코딩 생성

    /* wk1 gen*/
    WBWFLEA_EXT_ENCODING Ain, Bin;
    byte AinSeed[32] = {0,};                //외부 인코딩 Ain 생성용 seed
    gen_rand_bytes(AinSeed, 32);            //시드 랜덤 생성
    gen_randperm_128bits(&Ain, AinSeed);    //구조체 Ain 생성
    
    byte BinSeed[32] = {0,};            //외부 인코딩 Bin 생성용 seed
    gen_rand_bytes(BinSeed, 32);        //시드 랜덤 생성    
    gen_randperm_128bits(&Bin, BinSeed); //구조체 Bin 생성

    WBWFLEA_MAC_WK1 wk1_tab;
    
    start=clock();
    for (int cnt=0;cnt<iteration_num;cnt++){                                       
        VPMAC_WK1_KEY_GEN(&wk1_tab, AinSeed, BinSeed, key); //고정된 wk1 생성
    }    
    finish = clock();
    duration = (double)(finish-start)/CLOCKS_PER_SEC;

    printf("%d VPMAC WK1 gen %f sec.\n", iteration_num,duration);


    /* wk2 gen*/
    WBWFLEA_MAC_WK2 wk2_tab;

    start=clock();
    for (int cnt=0;cnt<iteration_num;cnt++){                                       

        VPMAC_WK2_KEY_GEN(&wk2_tab,  AinSeed, BinSeed, IV, BeSeed, key); //일회용 wk2 생성
    }
    finish = clock();
    duration = (double)(finish-start)/CLOCKS_PER_SEC;

    printf("%d VPMAC WK2 gen %f sec.\n", iteration_num,duration);

    /*VPMAC sig GEN*/
    byte dec[16] = {0,};        //16바이트 서명
    
    start=clock();
    for (int cnt=0;cnt<iteration_num;cnt++){                                       

        VPMAC_gen(dec, data_len, &wk1_tab, &wk2_tab, (byte*)wbe_dat); //VPMAC sig Gen
    }    
    finish = clock();
    duration = (double)(finish-start)/CLOCKS_PER_SEC;

    printf("%d VPMAC sig gen %f sec.\n", iteration_num,duration);


    byte tag[16];
    memcpy(tag,dec,16);    // 서명 검증시 사용할 tag에 복사.
        
    /* VPMAC sig verify*/

    start=clock();
    for (int cnt=0;cnt<iteration_num;cnt++){                                       

        wbwflea_ext_transform(&Be, (word*)IVsig, 0); //서명시 B(IV) 입력.
        int check = VPMAC_verify( data_len, key, (byte*)wbe_dat, IVsig, BeSeed, tag);  //서명 검증
    
    }
    finish = clock();
    duration = (double)(finish-start)/CLOCKS_PER_SEC;

    printf("%d VPMAC sig ver %f sec.\n", iteration_num,duration);





}