#ifndef _COMMON_H_
#define _COMMON_H_


#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <time.h>

#include "wflea.h"

#define     YES     1
#define     NO     0

int Word_to_Int(byte *b);
void Int_to_Word(byte *b,int i);

int is_equal_bytes(byte* src1, byte* src2, int size);
void gen_rand_bytes_using_randf(byte* dst, int size);
void gen_rand_bytes(byte* dst, int size);
void show_bytes(byte* x, int size);
void show_words(word* x, int size);


#endif