/** 
 * @file    main_test.c
 * @brief   set of test functions
 * @author  FDL @ KMU
 * @date    2020.2.10.
 * UTF-8
 * gcc main_test.c sha256.c wflea.c randperm.c wbwflea_encodings.c wbwflea_ext_transform.c wbwflea_tables.c wbwflea_encrypt.c cbclea.c ctrlea.c vpmac.c wbwfleamac_encoding.c common.c lea128.c benchmark.c -O2 -Wall
 */

#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <time.h>

#include "randperm.h"
#include "wflea.h"
#include "wbwflea_ext_transform.h"
#include "wbwflea_encodings.h"
#include "wbwflea_tables.h"
#include "wbwflea_encrypt.h"
#include "cbclea.h"
#include "ctrlea.h"
#include "vpmac.h"
#include "wbwfleamac_encoding.h"
#include "common.h"
#include "time.h"
#include "errors.h"
#include "lea128.h"
#include "benchmark.h"

/* 운영 모드 별 가능한 최대 바이트 수 default=1000*/
#define MAX_CBCBYTELEN      1000
#define MAX_CTRBYTELEN      1000
#define MAX_VPMACBYTELEN    1000

//#define _DEBUG_
//#define _DEMO_

/* test functions */
int test_wbwflea_encrypt();                    // wbwflea       vs wflea 
int test_wbwflea_cbc_encrypt(int msgbytelen);  // cbcwb         vs cbc
int test_wbwflea_ctr_encrypt(int msgbytelen);  // ctrwb         vs ctr
int test_VPmac(int msgbytelen);                // VPmacGentag   vs VPmacvertag
int test_VPMAC_Wk1Wk2(int msgbytelen);         // wk1 사전 설정. 이후 wk2 바꿀때 검증 여부 확인.


/* -- test functions -- */
/**
 * 기능	: wbwflea 와 wflea의 결과비교. (인코딩 적용시 동일 값 나오는가.)
 * 주요함수 
 *  - wbwflea_encryptwb(&enc_tab, (byte*)wbe_dat)   :    wbwflea 암호화      
 *  - wbwflea_decryptwb(&dec_tab, (byte*)wbe_dat)   :    wbwflea 복호화      
 *  - wflea_encryptblk(dec, enc, &wflea_ctx)        :    lea 암호화
 *  - wflea_decryptblk(rec, dec, &wflea_ctx)        :    lea 복호화
 * 입력 : 없음.
 * 출력 : 상황에 맞는 에러 코드 출력
 **/

int test_wbwflea_encrypt()
{
    //byte seed[32];
    printf("[test: Whitebox WF-LEA encryption]\n");

    /* test: WFLEA round trip */
    printf("[1. WFLEA]\n");
    /* setup: key */
    byte key[32] = {0x0,};
    gen_rand_bytes(key, 32);                                //랜덤하게 Key 생성. 
    
    /* setup: WFLEA context (roundkey generation) */
    WFLEA_CTX wflea_ctx;
    wflea_gen_ctx(&wflea_ctx, WBWFLEA_KEY_BYTES*8, key);    //key 설정.

    byte enc[16] = {0x0,};   
    byte dec[16] = {0x0,};  
    byte rec[16] = {0x0,};  

    /* plaintext generation */
    gen_rand_bytes(enc, 16);                                //테스트를 위해 랜덤한 평문 생성.
    printf("P            "); show_bytes(enc, 16);
    /* WFLEA encryption */
    wflea_encryptblk(dec, enc, &wflea_ctx);                 //wflea 암호화
    printf("E(P)         "); show_bytes(dec, 16);
    /* WFLEA decryption */    
    wflea_decryptblk(rec, dec, &wflea_ctx);                 //wflea 복호화
    printf("D(E(P))      "); show_bytes(rec, 16);
    

    /* test: whitebox encryption */
    printf("[2. WBWFLEA]\n");       
    /* external encoding generation (for encryption) */
    WBWFLEA_EXT_ENCODING Ae, Be;
    byte AeSeed[32] = {0x0,}; 
    byte BeSeed[32] = {0x0,};
    gen_rand_bytes(AeSeed, 32);                             // 외부인코딩 생성을 위해 drbg용 랜덤 시드 생성
    gen_rand_bytes(BeSeed, 32);                             

    gen_randperm_128bits(&Ae, AeSeed);                      // 랜덤 시드를 이용하여 외부 인코딩 생성.
    gen_randperm_128bits(&Be, BeSeed);                      

    // wbwflea_show_ext_encoding(&Ae);
    // wbwflea_show_ext_encoding(&Be);


    /* random networked encodings generation (for encryption) */
    WBWFLEA_ENCODINGS_FOR_ENCRYPTION enc_ctx;
    wbwflea_gen_encodings_for_encryption_notable(&enc_ctx, &Ae, &Be);  // 외부인코딩포함 암호화용 permutation 생성.

    /* encryption table generation with external encoding, random networked encodings, roundkey */
    WBWFLEA_ENCRYPTION_TABLE enc_tab;
    wbwflea_gen_encryption_table(&enc_tab, &enc_ctx, &wflea_ctx);      // pemutation과 key를 이용하여 암호화 카테이블 생성

    printf("[Whitebox WF-LEA encryption]\n");
    byte wbe_dat[16] = {0x0,}; memcpy(wbe_dat, enc, 16);         // WFLEA와 결과 비교를 위해 동일한 평문 사용. 
    printf("P            "); show_bytes(wbe_dat, 16);
    
    /* Plaintext Obfuscation */
    wbwflea_ext_transform(&Ae, (word*)wbe_dat, 0);               // LEA와의 동일 결과 비교를 위해 평문 인코딩 
    printf("A(P)         "); show_bytes(wbe_dat, 16);

#ifdef _DEBUG_
    wbwflea_encryptwb_debug(&enc_tab, &enc_ctx, (byte*)wbe_dat); // 화이트박스 암호화 (디버깅용)
    getchar();
#else
    wbwflea_encryptwb(&enc_tab, (byte*)wbe_dat);                  // 화이트박스 암호화
#endif
    printf("Ewb(A(P))    "); show_bytes(wbe_dat, 16);


    /* external excoding B */
    wbwflea_ext_transform(&Be, (word*)wbe_dat, 0);
    printf("B(Ewb(A(P))) "); show_bytes(wbe_dat, 16);          // LEA와의 동일 결과 비교를 위해 암호문 인코딩 
    //printf("[WBWFLEA vs LEA test result]\n ");

    if(is_equal_bytes(dec, wbe_dat, 16)==NO)         // B(ENCWB(A(PT))) = ENC(PT) 비교. 
        return WBWFL_EXEC_0001;
    /* test: whitebox decryption */

    /* external encoding generation (for decryption) */
    WBWFLEA_EXT_ENCODING Ad, Bd;
    byte AdSeed[32] = {0x0,}; 
    byte BdSeed[32] = {0x0,};
    gen_rand_bytes(AdSeed, 32);             // 외부인코딩 생성을 위해 drbg용 랜덤 시드 생성
    gen_rand_bytes(BdSeed, 32);

    gen_randperm_128bits(&Ad, AdSeed);
    gen_randperm_128bits(&Bd, BdSeed);      // 랜덤 시드를 이용하여 외부 인코딩 생성.

    //wbwflea_show_ext_encoding(&Ad);
    //wbwflea_show_ext_encoding(&Bd);
    
    /* random networked encodings generation (for decryption) */
    WBWFLEA_ENCODINGS_FOR_DECRYPTION dec_ctx;
    wbwflea_gen_encodings_for_decryption_notable(&dec_ctx, &Ad, &Bd);   // 외부인코딩포함 복호화용 permutation 생성.

    /* decryption table generation with external encoding, random networked encodings, roundkey */
    WBWFLEA_DECRYPTION_TABLE dec_tab;
    wbwflea_gen_decryption_table(&dec_tab, &dec_ctx, &wflea_ctx);   // pemutation과 key를 이용하여 복호화 카테이블 생성

    printf("[3. WBWFLEA round trip]\n");
    printf("[Whitebox WF-LEA decryption]\n");
    byte wbd_dat[16] = {0x0,}; memcpy(wbd_dat, dec, 16);    // 라운드 트립 결과 비교를 위해 동일한 암호문 사용. 
    printf("C            "); show_bytes(wbd_dat, 16);
    
    /* external excoding A */
    wbwflea_ext_transform(&Ad, (word*)wbd_dat, 0);       // LEA와의 동일 결과 비교를 위해 암호문 인코딩
    printf("A(C)         "); show_bytes(wbd_dat, 16);

#ifdef _DEBUG_
    wbwflea_decryptwb_debug(&dec_tab, &dec_ctx, (byte*)wbd_dat);  // 화이트박스 복호화 (디버깅용)
    getchar();
#else 
    wbwflea_decryptwb(&dec_tab, (byte*)wbd_dat);                // 화이트박스 복호화 
#endif 
    printf("Dwb(A(C))    "); show_bytes(wbd_dat, 16);

    /* external excoding B */
    wbwflea_ext_transform(&Bd, (word*)wbd_dat, 0);      // LEA와의 동일 결과 비교를 위해 복호문 인코딩
    printf("B(Dwb(A(C))) "); show_bytes(wbd_dat, 16);

    if(is_equal_bytes(rec, wbd_dat, 16)==NO)                // B(DecWB(A(CT))) = DEC(CT) 비교. 
        return WBWFL_EXEC_0002;

    /* WFLEA roundtrip */    
    //printf("[WFLEA roundtrip test result] "); 
    if(is_equal_bytes(enc, wbd_dat, 16)==NO)             //평문 = 복호문 인지 검사.
        return WBWFL_EXEC_0003;


    return WBWFL_EXEC_0000;
}

/* -- test functions -- */

/**
 * 기능 : wbcbc 와 cbc 결과 비교 (인코딩 적용시 동일 값 나오는가.)
 * 주요함수
 *  - WBCBC_LEA(wb_data_len, &enc_tab, &cbc_ex_tab, (byte*)encoded_msg, WbIV)        : WBCBC 암호화
 *  - Inv_WBCBC_LEA(wb_data_len, &dec_tab, &cbc_de_ex_tab, (byte*)encoded_msg, WbIV) : WBCBC 복호화
 *  - CBC_LEA(&dec_cbc,cbcmsg,CBCIV , cbc_data_len,&ctx)                             : CBCLEA 암호화
 *  - IN_CBC_LEA(rec,  dec_cbc,  CBCIV,  cbc_data_len, &ctx)                         : CBCLEA 복호화
 * 입력 : msgbytelen - cbc 동작에 사용할 바이트 길이 
 * 출력 : 상황에 맞는 에러 코드 출력
 **/
int test_wbwflea_cbc_encrypt(int msgbytelen)
{
    printf("[test: CBC Whitebox LEA encryption]\n" );

    /* param set */
    byte key[16] ={0x0,};   gen_rand_bytes(key,16);    //랜덤하게 Key 생성.
    byte IV[16]  ={0x0,};    gen_rand_bytes(IV,16);    //랜덤하게 IV 생성.

    byte CBCIV[16];                 //LEA CBC 용 IV   
    byte WbIV[16];                  //WBLEA CBC 용 IV
    memcpy(CBCIV,IV,16);            //동일한 IV 나눠 갖음.
    memcpy(WbIV,IV,16);    

    byte wbe_dat[MAX_CBCBYTELEN] ={0x0,};   // wbcbc용 평문
    gen_rand_bytes(wbe_dat,msgbytelen);     // 랜덤한 평문 생성
    byte cbc_dat[MAX_CBCBYTELEN] ={0x0,};   // cbclea용 평문
    memcpy(cbc_dat,wbe_dat,msgbytelen);     // wbcbc와 동일한 평문 나눠가짐.
    byte rndtrip[MAX_CBCBYTELEN] ={0x0,};   // roundtrip 확인용.
    memcpy(rndtrip,wbe_dat,msgbytelen);     // 평문 저장.

    int cbc_data_len = msgbytelen;          // 입력받은 cbc bytelen 설정.
    int wb_data_len = msgbytelen;           // 입력받은 wbcbc bytelen 설정.

    printf("[1. WBCBC encryption]\n" );

    /*key table gen (encryption, decryption)*/
    /* external encoding generation (for encryption) */
    WBWFLEA_EXT_ENCODING Be;            
    byte BeSeed[32] = {0x0,};               //외부 인코딩 Be를 생성하기 위한 seed
    gen_rand_bytes(BeSeed, 32);             //BeSeed 랜덤 생성
    gen_randperm_128bits(&Be, BeSeed);      //BeSeed를 이용하여 외부 인코딩 생성

    /* encryption table */
    WBWFLEA_ENCRYPTION_TABLE enc_tab;       //wblea 암호화 테이블
    XOR_TABLE cbc_ex_tab;                   //암호화용 xor 테이블

    /*Xor encoding (for encryption) */
    WBWFLEA_EXT_ENCODING CBCAe;             
    byte CBCAeSeed[32] = {0x0,};            //xor 인코딩 CBCAe 생성을 위한 seed
    gen_rand_bytes(CBCAeSeed, 32);          //CBCAeSeed 랜덤 생성
    gen_randperm_128bits(&CBCAe, CBCAeSeed);//CBCAeSeed를 이용하여 인코딩 생성

    /* CBC encryption table  */
    CBC_KEY_GEN_ENC(&enc_tab, &cbc_ex_tab, CBCAeSeed, BeSeed, key); //필요한 외부인코딩의 시드를 입력받아 암호화 테이블 생성


    /*WBLEA CBC encryption*/
    /*encryption*/
    printf("P           : "); show_bytes(wbe_dat, msgbytelen);  //초기 평문

    /*encode in wb-secure zone*/
    byte* encoded_msg;                                          // wbcbc 인코딩후 메시지 
    Encode(&encoded_msg, wbe_dat, &wb_data_len, CBCAeSeed);         // 패딩 + 외부인코딩
    printf("Encoded msg : "); show_bytes(encoded_msg, wb_data_len);  // 인코딩 결과

    /*WB CBC lea*/
    WBCBC_LEA(wb_data_len, &enc_tab, &cbc_ex_tab, (byte*)encoded_msg, WbIV);    //WBCBC encryption

    //printf("Wb CBC data : "); show_bytes(encoded_msg, wb_data_len);
    printf("Ewb(A(P))   : "); show_bytes(encoded_msg, wb_data_len);
    

    /* CBC LEA encryption */
    printf("[2. CBC LEA encryption]\n" );
    WBWFLEA_EXT_ENCODING ex_id;
    wbwflea_gen_ext_identity_encoding(&ex_id);  // CBC lea는 외부인코딩x

    //printf("msg len     : %d\n",cbc_data_len);
    byte *cbcmsg;                       // 패딩한 메시지 
    printf("P           : "); show_bytes(cbc_dat,cbc_data_len);
    
    /*Encode*/
    //Encode(&cbcmsg, cbc_dat, &cbc_data_len, ex_id); //외부인코딩은 항등함수이므로 패딩만  
    CBC_PAD(&cbcmsg, cbc_dat, &cbc_data_len);
    
    //printf("padded len  : %d\n",cbc_data_len);
    printf("Encoded msg : "); show_bytes(cbcmsg,cbc_data_len);  // 인코딩 결과

    // WFLEA_CTX ctx;
    // wflea_gen_ctx(&ctx, 128, key);      // key 저장
   
    byte *dec_cbc;                      //길이에 맞는 암호문 배열 설정.
    dec_cbc = calloc(cbc_data_len, sizeof(int));

    /* encoded IV! */
    wbwflea_ext_transform(&Be, (word*)CBCIV, 0);    //B(IV),  cbclea와 wbcbc의 동일한 결과를 위함.
    printf("B(IV)       : "); show_bytes(IV,16);
    
    /*CBC lea*/
    CBC_LEA(&dec_cbc,cbcmsg,CBCIV, cbc_data_len,key); //cbc lea 암호화
    printf("CBC data    : "); show_bytes(dec_cbc,cbc_data_len);

    for (int i=0; i<cbc_data_len/16;i++ ){
        wbwflea_ext_transform(&Be, (word*)(dec_cbc+(16*i)), 1);  //  cbclea와 wbcbc의 동일한 결과를 위함.
    }
    printf("B(CBC data) : "); show_bytes(dec_cbc,cbc_data_len);

    //printf("[CBCLEA vs WBCBC encryption test result] ");       //  인코딩한 cbclea와 wbcbc의 결과 비교
    if(is_equal_bytes(dec_cbc, encoded_msg, wb_data_len)==NO)
        return WBCBC_EXEC_0001;

    /*WBCBC decryption*/

    /* decryption table gen */
    WBWFLEA_DECRYPTION_TABLE dec_tab;       //wblea 복호화 테이블
    XOR_TABLE cbc_de_ex_tab;                //복호화용 xor 테이블

    /*Xor encoding (for decryption) */
    WBWFLEA_EXT_ENCODING CBCBe;             
    byte CBCBeSeed[32] = {0x0,};            //xor 인코딩 CBCBe 생성을 위한 seed
    gen_rand_bytes(CBCBeSeed, 32);          //CBCBeSeed 랜덤 생성
    gen_randperm_128bits(&CBCBe, CBCBeSeed);//CBCBeSeed를 이용하여 인코딩 생성

    CBC_KEY_GEN_DEC(&dec_tab, &cbc_de_ex_tab, CBCBeSeed, BeSeed, key);//필요한 외부인코딩의 시드를 입력받아 암호화 테이블 생성

    /* decryption */
    printf("[3. WBCBC decryption]\n" );
    Inv_WBCBC_LEA(wb_data_len, &dec_tab, &cbc_de_ex_tab, (byte*)encoded_msg, WbIV); // WBCBC 복호화.
    printf("rec         : "); show_bytes(encoded_msg, wb_data_len);

    byte* wbdecmsg;
    Decode(&wbdecmsg, encoded_msg, &wb_data_len, CBCBeSeed);    // 패딩 + 외부인코딩 
    printf("DEcode(rec ): "); show_bytes(wbdecmsg, wb_data_len);
   
    for (int i=0; i<cbc_data_len/16;i++ ){
        wbwflea_ext_transform(&Be, (word*)(dec_cbc+(16*i)), 0);  //CBClea와 동일 값 확인을 위함.
    }

    /* CBC LEA decryption */
    printf("[4. CBC LEA decryption]\n" );

    /*CBC lea*/
    byte *rec;
    rec = calloc(cbc_data_len, sizeof(int));
    IN_CBC_LEA(rec,  dec_cbc,  CBCIV,  cbc_data_len, key); // B(IV)를 이용한 CBCLEA 복호화

    byte *decode_msg;
    //Decode(&decode_msg, rec, &cbc_data_len, ex_id); //패딩 정보를 이용하여 원본 메시지 복원. 
    Remove_Pad(&decode_msg, rec, &cbc_data_len);

    /*CBC lea deryption  */
    printf("CBC rec     : "); show_bytes(decode_msg, cbc_data_len);

    //printf("[CBCLEA vs WBCBC decryption test result] ");       //  인코딩한 cbclea와 wbcbc의 복호화 결과 비교
    if(is_equal_bytes(decode_msg, wbdecmsg, cbc_data_len)==NO)
        return WBCBC_EXEC_0002;

    //printf("[CBCLEA roundtrip test result]           ");       //  round trip 결과 비교
    if(is_equal_bytes(rndtrip, wbdecmsg, cbc_data_len)==NO)
        return WBCBC_EXEC_0003;


    free(cbcmsg);
    free(encoded_msg);
    free(wbdecmsg);
    free(rec);
    free(decode_msg);
    free(dec_cbc);

    return WBCBC_EXEC_0000;
}


/**
 * 기능 : wbctr 와 ctr 결과 비교 (인코딩 적용시 동일 값 나오는가.)
 * 주요함수
 *  - WBCTR_LEA(wb_data_len, &enc_tab, &ctr_ex_tab, (byte*)encoded_msg, WbIV)        : WBCTR 암호화
 *  - WBCTR_LEA(wb_data_len, &dec_tab, &ctr_de_ex_tab, (byte*)encoded_msg, WbIV)     : WBCBC 복호화
 *  - CTR_LEA_w_Encoder(dec_ctr,ctrmsg,IV,ctr_data_len,&Ae,&ctx)                     : CTRLEA 암호화
 *  - CTR_LEA_w_Encoder(rec,dec_ctr,CTRIV,ctr_data_len,&Ae,&ctx)                     : CTRLEA 복호화
 * 입력 : msgbytelen - ctr 동작에 사용할 바이트 길이 
 * 출력 : 상황에 맞는 에러 코드 출력
 **/

int test_wbwflea_ctr_encrypt(int msgbytelen)
{
    printf("[test: CTR Whitebox LEA encryption]\n");

    /* param set */
    byte key[16] ={0x0,};   gen_rand_bytes(key,16);    //랜덤하게 Key 생성.
    byte IV[16]  ={0x0,};    gen_rand_bytes(IV,16);    //랜덤하게 IV 생성.

    byte CTRIV[16];    // LEA CTR 용 IV 
    byte WbIV[16];     // WBLEA CTR 용 IV
    memcpy(CTRIV,IV,16);
    memcpy(WbIV,IV,16);

    byte wbe_dat[MAX_CBCBYTELEN] ={0x0,};   // wbcbc용 평문
    gen_rand_bytes(wbe_dat,msgbytelen);     // 랜덤한 평문 생성
    byte ctr_dat[MAX_CTRBYTELEN] ={0x0,};   // ctrlea용 평문
    memcpy(ctr_dat,wbe_dat,msgbytelen);     // wbctr와 동일한 평문 나눠가짐.
    byte rndtrip[MAX_CBCBYTELEN] ={0x0,};   // roundtrip 확인용.
    memcpy(rndtrip,wbe_dat,msgbytelen);     // 평문 저장.

    int ctr_data_len = msgbytelen;        // 입력받은 ctr bytelen 설정.
    //int blk_len= ctr_data_len/16;        
    int wb_data_len = msgbytelen;         // 입력받은 wbctr bytelen 설정.

    printf("[1. WBCTR encryption]\n" );
    /*key table gen (encryption, decryption)*/
    /* CTR-table-permutation */
    WBWFLEA_EXT_ENCODING Ae;   
    byte AeSeed[32] = {0x0,};               //외부인코딩 Ae용 seed
    gen_rand_bytes(AeSeed, 32);             //랜덤 생성
    gen_randperm_128bits(&Ae, AeSeed);      //Aeseed를 이용하여 Ae 생성

    WBWFLEA_EXT_ENCODING CTRG;    
    byte CTRGSeed[32] = {0x0,};             //xor용 외부인코딩 CTRG용 seed
    gen_rand_bytes(CTRGSeed, 32);           //랜덤 생성
    gen_randperm_128bits(&CTRG, CTRGSeed);  //CTRGseed를 이용하여 CTRG 생성

    WBWFLEA_EXT_ENCODING CTRH;              
    byte CTRHSeed[32] = {0x0,};             //xor용 외부인코딩 CTRH용 seed
    gen_rand_bytes(CTRHSeed, 32);           //랜덤 생성
    gen_randperm_128bits(&CTRH, CTRHSeed);  //CTRHseed를 이용하여 CTRH 생성
    
    /* encryption table */
    WBWFLEA_ENCRYPTION_TABLE enc_tab;
    XOR_TABLE ctr_ex_tab;

    /* CTR encryption table */
    CTR_KEY_GEN_ENC(&enc_tab, &ctr_ex_tab, AeSeed, CTRHSeed, CTRGSeed, key); //필요한 외부인코딩의 시드를 입력받아 암호화 테이블 생성

    /* WBLEA CTR encryption*/
    printf("P            "); show_bytes(wbe_dat, msgbytelen);       // 초기 평문
    
    /*encode in wb-secure zone*/
    byte* encoded_msg;                                          //인코딩된 메시지 저장
    Encode(&encoded_msg, wbe_dat, &wb_data_len, CTRGSeed);          // 패딩 +인코딩
    printf("Encoded msg : "); show_bytes(encoded_msg, wb_data_len); //인코딩 결과
    
    /*WB CTR lea encryption*/
    WBCTR_LEA(wb_data_len, &enc_tab, &ctr_ex_tab, (byte*)encoded_msg, WbIV); // WBCTR encryption  
    //printf("Wb CBC data : "); show_bytes(encoded_msg, wb_data_len);
    printf("Ewb(A(P))   : "); show_bytes(encoded_msg, wb_data_len);
    
    /* CTR LEA encryption */
    printf ("[2. CTR LEA encryption]\n");
    WBWFLEA_EXT_ENCODING ex_id;
    wbwflea_gen_ext_identity_encoding(&ex_id);  // 일반 ctr은 인코딩 필요없으므로 항등함수

    //printf("msg len     : %d\n",ctr_data_len);
    byte *ctrmsg;                                   //패딩후 메시지
    printf("P           : "); show_bytes(ctr_dat,ctr_data_len);
 
    /* Encode */
    //Encode(&ctrmsg, ctr_dat, &ctr_data_len, ex_id); //외부인코딩은 항등함수이므로 패딩만  
    CBC_PAD(&ctrmsg, ctr_dat, &ctr_data_len);

    //printf("padded len  : %d\n",ctr_data_len);
    printf("Padded Msg  : "); show_bytes(ctrmsg,ctr_data_len);

    
    byte *dec_ctr;              //길이에 맞는 암호문 배열 설정.
    dec_ctr = calloc(ctr_data_len,sizeof(int));

    /* encode Ae for compare WBLEA and LEA*/
    CTR_LEA_w_Encoder(dec_ctr,ctrmsg,IV,ctr_data_len,&Ae,key); // 내부에서 IV에 Ae 인코딩
    printf("CTR data    : "); show_bytes(dec_ctr,ctr_data_len);

    for (int i=0; i<ctr_data_len/16;i++ ){        
        wbwflea_ext_transform(&CTRH, (word*)(dec_ctr+(16*i)),0); //  ctrlea와 wbctr의 동일한 결과를 위함.
    }
    printf("B(CTR data) : "); show_bytes(dec_ctr,ctr_data_len);


    //printf("[CTRLEA vs WBCTR encryption test result] ");       //  인코딩한 ctrlea와 wbctr의 결과 비교
    if(is_equal_bytes(dec_ctr, encoded_msg, wb_data_len)==NO)
        return WBCTR_EXEC_0001;

    /*WBCTR decryption*/

    /* decryption table gen*/
    WBWFLEA_ENCRYPTION_TABLE dec_tab;   //wblea 복호화 테이블
    XOR_TABLE ctr_de_ex_tab;            //복호화용 XOR 테이블

    /* CTR-table-permutation */
    WBWFLEA_EXT_ENCODING CTRHd;   
    byte CTRHdSeed[32] = {0x0,};        //xor 인코딩 CTRHd 생성을 위한 seed
    gen_rand_bytes(CTRHdSeed, 32);      //CTRHdSeed 랜덤 생성
    gen_randperm_128bits(&CTRHd, CTRHdSeed); //CTRHdSeed를 이용하여 인코딩 생성

    CTR_KEY_GEN_DEC(&dec_tab, &ctr_de_ex_tab, AeSeed, CTRHSeed, CTRHdSeed, key);

    /* decryption */
    printf("[3. WBCTR decryption]\n" );

    /*WB CTR LEA decryption*/
    WBCTR_LEA(wb_data_len, &dec_tab, &ctr_de_ex_tab, (byte*)encoded_msg, WbIV);  //WBCTR  복호화
    printf("rec         : "); show_bytes(encoded_msg, wb_data_len);

    byte* wbdecmsg;
    Decode(&wbdecmsg, encoded_msg, &wb_data_len, CTRHdSeed); //패딩 부분 삭제 

    printf("DEcode(rec ): "); show_bytes(wbdecmsg, wb_data_len);


    /* CTR LEA decryption */
    printf("[4. CTR LEA decryption]\n" );

    byte* rec;
    rec=calloc(ctr_data_len,sizeof(int));

    for (int i=0; i<ctr_data_len/16;i++ ){
        wbwflea_ext_transform(&CTRH, (word*)(dec_ctr+(16*i)), 1); //WBCTR와 동일 값 확인을 위함.
    }

    CTR_LEA_w_Encoder(rec,dec_ctr,CTRIV,ctr_data_len,&Ae,key);   //내부에서 IV에 Ae 인코딩

    byte *decode_msg;
    //Decode(&decode_msg, rec, &ctr_data_len, ex_id); //패딩 정보를 이용하여 원본 메시지 복원.
    Remove_Pad(&decode_msg, rec, &ctr_data_len);

    printf("CTR rec     : "); show_bytes(decode_msg, ctr_data_len);

    //printf("[CTRLEA vs WBCTR decryption test result] ");       //  인코딩한 ctrlea와 wbctr의 복호화 결과 비교
    if(is_equal_bytes(decode_msg, wbdecmsg, ctr_data_len)==NO)
        return WBCTR_EXEC_0002;


    //printf("[CTRLEA roundtrip test result]           ");       //  round trip 결과 비교
    if(is_equal_bytes(rndtrip, wbdecmsg, ctr_data_len)==NO)
        return WBCTR_EXEC_0003;



    free(ctrmsg);
    free(dec_ctr);
    free(decode_msg);
    free(encoded_msg);
    free(wbdecmsg);
    free(rec);

    return WBCTR_EXEC_0000;

}

/**
 * 기능 : VPMAC sig Gen 와 VPMAC sig verify 결과 비교 (인코딩 적용시 동일 값 나오는가.)
 * 주요함수
 *  - VPMAC_gen(dec, data_len, &wk1_tab, &wk2_tab, (byte*)wbe_dat)              : VPMAC sig Gen
 *  - VPMAC_verify( data_len, &wflea_ctx, (byte*)wbe_dat, IVsig, BeSeed, tag)   : VPMAC sig verify
 * 입력 : msgbytelen - vpmac 동작에 사용할 바이트 길이 
 * 출력 : 상황에 맞는 에러 코드 출력
 **/
 
int test_VPmac(int msgbytelen)
{
    printf("[test: VPMAC sig Gen]\n");

    /*param gen*/
    byte key[16] ={0x0,};   gen_rand_bytes(key,16);    //랜덤하게 Key 생성.
    byte IV[16]  ={0x0,};    gen_rand_bytes(IV,16);    //랜덤하게 IV 생성.

    byte IVsig[16]={0,};    //서명용 IV
    memcpy(IVsig,IV,16);    //동일한 IV 저장.

    byte wbe_dat[MAX_VPMACBYTELEN]={0x0,}; // 서명생성용 평문
    gen_rand_bytes(wbe_dat,msgbytelen);    // 랜덤 생성

    byte copy_dat[MAX_VPMACBYTELEN];        // 서명 검증용 평문 생성
    memcpy(copy_dat,wbe_dat,msgbytelen);    // 서명 생성과 동일

    int data_len = msgbytelen;       //입력받은 byte 길이
 
    printf("[1. VPMAC sig Gen]\n" );

    /* setup: WFLEA context (roundkey generation) */
    WFLEA_CTX wflea_ctx;
    wflea_gen_ctx(&wflea_ctx, WBWFLEA_KEY_BYTES*8, key);

    /* test: VPMAC sig Gen */
    /* external encoding generation (for encryption) */
    WBWFLEA_EXT_ENCODING Be;       
    byte BeSeed[32] = {0x0,};               //외부 인코딩 Be를 생성하기 위한 seed
    gen_rand_bytes(BeSeed, 32);             //BeSeed 랜덤 생성
    gen_randperm_128bits(&Be, BeSeed);      //BeSeed를 이용하여 외부 인코딩 생성

    /* wk1 gen*/
    WBWFLEA_EXT_ENCODING Ain, Bin;
    byte AinSeed[32] = {0,};                //외부 인코딩 Ain 생성용 seed
    gen_rand_bytes(AinSeed, 32);            //시드 랜덤 생성
    gen_randperm_128bits(&Ain, AinSeed);    //구조체 Ain 생성
    
    byte BinSeed[32] = {0,};            //외부 인코딩 Bin 생성용 seed
    gen_rand_bytes(BinSeed, 32);        //시드 랜덤 생성    
    gen_randperm_128bits(&Bin, BinSeed); //구조체 Bin 생성

    WBWFLEA_MAC_WK1 wk1_tab;
    VPMAC_WK1_KEY_GEN(&wk1_tab, AinSeed, BinSeed, key); //고정된 wk1 생성
    
    /* wk2 gen*/
    WBWFLEA_MAC_WK2 wk2_tab;
    VPMAC_WK2_KEY_GEN(&wk2_tab,  AinSeed, BinSeed, IV, BeSeed, key); //일회용 wk2 생성

    /*VPMAC sig GEN*/
    printf("P            : "); show_bytes(wbe_dat,data_len);        
    byte dec[16] = {0,};        //16바이트 서명
    VPMAC_gen(dec, data_len, &wk1_tab, &wk2_tab, (byte*)wbe_dat); //VPMAC sig Gen
    printf("Ewb(P)       : "); show_bytes(dec, 16);

    byte tag[16];
    memcpy(tag,dec,16);    // 서명 검증시 사용할 tag에 복사.
    
    /* CBCMAC sig GEN*/
    printf("[VPMAC gen check(CBCMAC LEA)]\n");

    int chekc_data_len=msgbytelen;  // VPMAC과 동일한 평문길이 입력
    int pad_len = Pad_len(chekc_data_len);  // 메시지 패딩.
    byte *padded_msg;                   // 패딩 메시지 저장
    padded_msg = calloc(pad_len, sizeof(int));  

    byte plaindec[16]={0x0,}; 
    Pad_msg(&padded_msg, copy_dat, chekc_data_len);   //one-zero 패딩
    wbwflea_ext_transform(&Be, (word*)IV, 0);       //VPMAC과 비교를 위함.

    CBCMAC_LEA(plaindec, padded_msg,IV,pad_len,key); //CBCMAC
    printf("E(P)        : "); show_bytes(plaindec, 16);

    wbwflea_ext_transform(&Be, (word*)(plaindec), 1);    // VPMAC과 비교를 위함
    printf("B(E(P))     : "); show_bytes(plaindec, 16);

    //printf("[VPMAC vs CBCMAC test result] ");
    if(is_equal_bytes(plaindec, dec, 16)==NO)      // VPMAC과 CBCMAC 비교
        return VPMAC_EXEC_0001;
    
    /* VPMAC sig verify*/
    //printf("[VPMAC sig verify]\n");
    wbwflea_ext_transform(&Be, (word*)IVsig, 0); //서명시 B(IV) 입력.
    
    //printf("[VPMAC sig GEN vs sig verify test result] ");  
    if(VPMAC_verify( data_len, key, (byte*)wbe_dat, IVsig, BeSeed, tag)==INVALID)  //서명 검증
    {
        return VPMAC_EXEC_0002;
    }
    
    return VPMAC_EXEC_0000;
    
    free(padded_msg);
}



/**
 * 기능 : VPMAC 동작시 WK1는 고정하고, WK2를 바꾸며 진행 시 올바르게 검증 성공하는가
 * 주요함수
 *  - VPMAC_gen(dec, data_len, &wk1_tab, &wk2_tab, (byte*)wbe_dat)              : VPMAC sig Gen
 *  - VPMAC_verify( data_len, &wflea_ctx, (byte*)wbe_dat, IVsig, BeSeed, tag)   : VPMAC sig verify
 * 입력 : msgbytelen - vpmac 동작에 사용할 바이트 길이 
 * 출력 : 상황에 맞는 에러 코드 출력
 **/
 
int test_VPMAC_Wk1Wk2(int msgbytelen)
{
    /* pre-computation */
    /* key gen */
    byte key[16] ={0x0,};
    gen_rand_bytes(key,16);   //랜덤하게 Key 생성.

    /* external encoding generation (for encryption) */
    
    /* static wk1 gen */
    WBWFLEA_EXT_ENCODING Ain, Bin;
    byte AinSeed[32] = {0,};                //외부 인코딩 Ain 생성용 seed
    gen_rand_bytes(AinSeed, 32);            //시드 랜덤 생성
    gen_randperm_128bits(&Ain, AinSeed);    //구조체 Ain 생성
    
    byte BinSeed[32] = {0,};            //외부 인코딩 Bin 생성용 seed
    gen_rand_bytes(BinSeed, 32);        //시드 랜덤 생성    
    gen_randperm_128bits(&Bin, BinSeed); //구조체 Bin 생성


    WBWFLEA_MAC_WK1 wk1_tab;            //wk1_tab 사전 생성.
    VPMAC_WK1_KEY_GEN(&wk1_tab, AinSeed, BinSeed, key);


    /* second ephemeral */
    printf("[test: ephemeral WK2]\n");
    /* setup: WFLEA context (roundkey generation) */
    WFLEA_CTX wflea_ctx;
    wflea_gen_ctx(&wflea_ctx, WBWFLEA_KEY_BYTES*8, key);    //key에 따른 구조체 생성

    printf("[WK2 verify test result] "); //WK1은 고정되고 WK2가 변할때 검증이 잘 이루어지는가  
    for(int x=0; x < 10000; x++){        
        /*param gen*/
        byte IV[16]  ={0x0,};
        gen_rand_bytes(IV,16);      //랜덤하게 IV 생성.

        byte IVsig[16]={0,};
        memcpy(IVsig,IV,16);        //서명용 IV 동일하게 저장

        byte wbe_dat[MAX_VPMACBYTELEN]={0x0,};   // 서명생성용 평문
        gen_rand_bytes(wbe_dat,msgbytelen);

        int data_len = msgbytelen;              //입력받은 메시지 
        
        /* ephemeral wk2 gen */
        WBWFLEA_EXT_ENCODING Be;       
        byte BeSeed[32] = {0x0,};               //외부 인코딩 Be를 생성하기 위한 seed
        gen_rand_bytes(BeSeed, 32);             //BeSeed 랜덤 생성
        gen_randperm_128bits(&Be, BeSeed);      //BeSeed를 이용하여 외부 인코딩 생성

        WBWFLEA_MAC_WK2 wk2_tab;
        VPMAC_WK2_KEY_GEN(&wk2_tab, AinSeed, BinSeed, IV, BeSeed, key); //일회용 wk2 생성

        /* VPMAC sig GEN */  
        byte dec[16] = {0,};
        VPMAC_gen(dec, data_len, &wk1_tab, &wk2_tab, (byte*)wbe_dat); // 서명 생성

        byte tag[16];
        memcpy(tag,dec,16);     //tag로 저장

        /* VPMAC sig verify */            
        wbwflea_ext_transform(&Be, (word*)IVsig, 0); //IV 디코딩 하여 입력

        if(VPMAC_verify( data_len, key, (byte*)wbe_dat, IVsig, BeSeed, tag)!=VALID) //서명 검증
        {
            return VPMAC_EXEC_0003;
        }
    }
    return VPMAC_EXEC_0000;

    printf("all equal.\n");  // 모든 경우 동일

}



/**
 * @brief main function
 */
int main()
{
    /* setup for rand function */
    srand(time(NULL));
    
    /* setup for msg byte length */
    int msgbytelen = 79;                    // number of blk

    /* 함수 검증 */
    int error_msg;
    error_msg = test_wbwflea_encrypt();        //WBWFLEA 
    if(error_msg == WBWFL_EXEC_0001)
    {
        printf("ERROR: WBWFL_EXEC_0001\n");
    }
    else if(error_msg == WBWFL_EXEC_0002)
    {
        printf("ERROR: WBWFL_EXEC_0002\n");
    }
       else if(error_msg == WBWFL_EXEC_0003)
    {
        printf("ERROR: WBWFL_EXEC_0003\n");
    }
    else printf("NO ERROR in WBWFL_EXEC\n");

    error_msg = test_wbwflea_cbc_encrypt(msgbytelen);   //WBLEA CBC
    if(error_msg == WBCBC_EXEC_0001)
    {
        printf("ERROR: WBCBC_EXEC_0001\n");
    }
    else if(error_msg == WBCBC_EXEC_0002)
    {
        printf("ERROR: WBCBC_EXEC_0002\n");
    }
    else if(error_msg == WBCBC_EXEC_0003)
    {
        printf("ERROR: WBCBC_EXEC_0003\n");
    }
    else printf("NO ERROR in WBCBC_EXEC\n");

    error_msg = test_wbwflea_ctr_encrypt(msgbytelen);   //WBLEA CTR
    if(error_msg == WBCTR_EXEC_0001)
    {
        printf("ERROR: WBCTR_EXEC_0001\n");
    }
    else if(error_msg == WBCTR_EXEC_0002)
    {
        printf("ERROR: WBCTR_EXEC_0002\n");
    }
    else if(error_msg == WBCTR_EXEC_0003)
    {
        printf("ERROR: WBCTR_EXEC_0003\n");
    }
    else printf("NO ERROR in WBCTR_EXEC\n");


    error_msg = test_VPmac(msgbytelen);                 //VPMAC
    if(error_msg == VPMAC_EXEC_0001)
    {
        printf("ERROR: VPMAC_EXEC_0001\n");
    }
    else if(error_msg == VPMAC_EXEC_0002)
    {
        printf("ERROR: VPMAC_EXEC_0002\n");
    }
    else printf("NO ERROR in VPMAC_EXEC\n");

    error_msg = test_VPMAC_Wk1Wk2(msgbytelen);          // Wk1 Wk2 test
    if(error_msg == VPMAC_EXEC_0003)
    {
        printf("ERROR: VPMAC_EXEC_0003\n");
    }
    else printf("NO ERROR in VPMAC_EXEC\n");

    /* 시간측정 */
    TIME_WBWFL();
    TIME_WBCBC();
    TIME_WBCTR();
    TIME_VPMAC();


    return 0;
}
