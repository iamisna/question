#ifndef _CBCLEA_H_
#define _CBCLEA_H_

/**
 * @file    cbclea.h
 * @brief   Whitebox WF-LEA C code: configuration for key size: 128 or 192 or 256
 * @author  FDL @ KMU
 * @version 2022.07.22.
 */

#include <stdio.h>
#include <stdlib.h>
#include <memory.h>

#include "randperm.h"
#include "wflea.h"
#include "wbwflea_ext_transform.h"
#include "wbwflea_encrypt.h"
#include "wbwflea_encodings.h"
#include "common.h"


typedef struct {
    byte XOR[4][8][256];
}XOR_TABLE;

void XOR_encoding_table(
            XOR_TABLE* tab,
            WBWFLEA_EXT_ENCODING* f,
            WBWFLEA_EXT_ENCODING* g,
            WBWFLEA_EXT_ENCODING* h);


void XOR_decoding_table(
            XOR_TABLE* tab,
            WBWFLEA_EXT_ENCODING* f,
            WBWFLEA_EXT_ENCODING* g,
            WBWFLEA_EXT_ENCODING* h);

void cbc_gen_encoding_table(
            WBWFLEA_MAC_WK2* tab,
            WBWFLEA_EXT_ENCODING* f,
            WBWFLEA_EXT_ENCODING* g,
            WBWFLEA_EXT_ENCODING* h);


void CBC_KEY_GEN_ENC(WBWFLEA_ENCRYPTION_TABLE* enc_tab,XOR_TABLE* cbc_ex_tab, 
                        byte* CBCAeSeed, byte* BeSeed, byte* key);

void CBC_KEY_GEN_DEC(WBWFLEA_DECRYPTION_TABLE* dec_tab, XOR_TABLE* cbc_de_ex_tab, 
                  byte* CBCBeSeed, byte* BeSeed, byte* key);

void Encode(byte** dst, byte* wbe_dat, int* data_len, byte* CBCAeSeed);
void Decode(byte** msg, byte* encoded_msg, int* data_len, byte* CBCBeSeed);
void Remove_Pad(byte** dst, byte* src, int* srclen);
void CBC_PAD(byte** dst,  byte* src, int* srclen);
void CBC_LEA(byte** dst,  byte* src, byte* IV, const int  srclen,  byte* key);
void WBCBC_LEA(int srclen, WBWFLEA_ENCRYPTION_TABLE* enc_tab, XOR_TABLE* cbc_ex_tab, byte* data, byte* IV);
void IN_CBC_LEA(byte* dst, const byte* src, byte* IV, const int srclen, byte* key);
void Inv_WBCBC_LEA(const int srclen, WBWFLEA_DECRYPTION_TABLE* dec_tab, XOR_TABLE* cbc_ex_tab, byte* src, byte* IV);


#endif /* _CBCLEA_H_ */