#include "ctrlea.h"

/* 
 * 기능 : CTR 암호화 에서 사용하는 키테이블(wblea, xor) 생성
 * 입력 : 외부인코딩 시드, 키를 입력받아 테이블 생성
 * 출력 : 없음
 */
void CTR_KEY_GEN_ENC(WBWFLEA_ENCRYPTION_TABLE* enc_tab, XOR_TABLE* ctr_ex_tab, byte* AeSeed, byte* CTRHSeed, byte* CTRGSeed, byte* key){
    /* setup: WFLEA context (roundkey generation) */
    WFLEA_CTX wflea_ctx;
    wflea_gen_ctx(&wflea_ctx, WBWFLEA_KEY_BYTES*8, key);
    
    /* external encoding generation (for encryption) */
    WBWFLEA_EXT_ENCODING Ae,Be;
    gen_randperm_128bits(&Ae, AeSeed);      //Ae는 seed로 생성
    wbwflea_gen_ext_encoding(&Be);          //Be는 내장 랜덤으로 생성

    /* random networked encodings generation (for encryption) */
    WBWFLEA_ENCODINGS_FOR_ENCRYPTION enc_ctx;
    wbwflea_gen_encodings_for_encryption_notable(&enc_ctx, &Ae, &Be);

    /* encryption table generation with external encoding, random networked encodings, roundkey */
    wbwflea_gen_encryption_table(enc_tab, &enc_ctx, &wflea_ctx);    //wblea 테이블 생성

    /*Xor encoding (for encryption) */
    WBWFLEA_EXT_ENCODING CTRG;
    //wbwflea_gen_ext_encoding( CTRG);
    gen_randperm_128bits(&CTRG, CTRGSeed);

    WBWFLEA_EXT_ENCODING CTRH;
    //wbwflea_gen_ext_encoding( CTRH);
    gen_randperm_128bits(&CTRH, CTRHSeed);

    /*Xor table (for encryption) */
    CTR_XOR_decoding_table(ctr_ex_tab, &Be, &CTRG, &CTRH);      //xor 테이블 생성.

}


/* 
 * 기능 : CTR 복호화 에서 사용하는 키테이블(wblea, xor) 생성
 * 입력 : 외부인코딩 시드, 키를 입력받아 테이블 생성
 * 출력 : 없음
 */
void CTR_KEY_GEN_DEC(WBWFLEA_ENCRYPTION_TABLE* dec_tab, XOR_TABLE* cbc_de_ex_tab, 
                byte* AeSeed, byte* CTRHSeed, byte* CTRHdSeed, byte* key){
    /* setup: WFLEA context (roundkey generation) */
    WFLEA_CTX wflea_ctx;
    wflea_gen_ctx(&wflea_ctx, WBWFLEA_KEY_BYTES*8, key);
    
    // /* external encoding generation (for encryption) */
    WBWFLEA_EXT_ENCODING Ae;
    gen_randperm_128bits(&Ae, AeSeed);      //시드로 생성

    WBWFLEA_EXT_ENCODING CTRH;
    // //wbwflea_gen_ext_encoding( CTRH);
    gen_randperm_128bits(&CTRH, CTRHSeed);  //시드로 생성

    /* external encoding generation (for decryption) */
    WBWFLEA_EXT_ENCODING Bd;        
    wbwflea_gen_ext_encoding(&Bd);

    /* random networked encodings generation (for decryption) */
    WBWFLEA_ENCODINGS_FOR_ENCRYPTION dec_ctx;
    wbwflea_gen_encodings_for_encryption_notable(&dec_ctx, &Ae, &Bd);

    /* decryption table generation with external encoding, random networked encodings, roundkey */
    wbwflea_gen_encryption_table(dec_tab, &dec_ctx, &wflea_ctx);

    /* CTR-table-permutation */
    WBWFLEA_EXT_ENCODING CTRGd;    //CTRGd is inverse of CTRH

    memcpy(CTRGd.f,CTRH.f_inv,4*8*16);      //H의 역 퍼뮤테이션 생성.
    memcpy(CTRGd.f_inv,CTRH.f,4*8*16);

    WBWFLEA_EXT_ENCODING CTRHd;        
    //wbwflea_gen_ext_encoding(CTRHd);
    gen_randperm_128bits(&CTRHd, CTRHdSeed);

    /*Xor table (for decryption) */
    XOR_decoding_table(cbc_de_ex_tab, &Bd, &CTRGd, &CTRHd);

}


/* 
 * 기능 : CTR LEA 암호화 (non wb)
 * 입력 : 메시지, IV, 메시지 길이, 키를 입력받아 CBC LEA 암호화 진행
 * 출력 : 없음
 */
void CTR_LEA(byte* dst, const byte* src, byte* IV, const int srclen, byte* key)
{
    WFLEA_CTX ctx;
    wflea_gen_ctx(&ctx, 128, key); 

    
    int blklen = srclen/16;
    
    byte enc[16] = {0x0,};  
    byte dec[16] = {0x0,}; 
    byte inIV[16]= {0x0,};

    memcpy(inIV,IV,16);

    for(int i=0;i<blklen;i++)     // N-1 blk
    {
        CTRupdate(enc,inIV);        //이전 블록 IV+1
        
        wflea_encryptblk_4bits(dec, enc, &ctx); //암호화
        for(int j=0;j<16;j++)
        {
            dst[16*i+j] = dec[j]^src[16*i+j];   //IV암호문과 평문 xor
        }       
    }
}

/* 
 * 기능 : CTR LEA 암호화 (non wb). wbctr과 비교를 위해 내부에서 외부인코딩 Ae 진행.
 * 입력 : 메시지, IV, 메시지 길이, 키를 입력받아 CBC LEA 암호화 진행
 * 출력 : 없음
 */
void CTR_LEA_w_Encoder(byte* dst, const byte* src, byte* IV, const int srclen,  WBWFLEA_EXT_ENCODING* Ae, byte* key)
{
    WFLEA_CTX ctx;
    wflea_gen_ctx(&ctx, 128, key); 

    int blklen = srclen/16;
    
    byte enc[16] = {0x0,};  
    byte dec[16] = {0x0,}; 
    byte inIV[16]= {0x0,};

    memcpy(inIV,IV,16);

    for(int i=0;i<blklen;i++)     // N-1 blk
    {
        CTRupdate(enc, inIV);   //이전블록 IV+1  

        wbwflea_ext_transform(Ae, (word*)(enc), 1); //외부인코딩 역연산.
        
        wflea_encryptblk_4bits(dec, enc, &ctx);
        for(int j=0;j<16;j++)
        {
            dst[16*i+j] = dec[j]^src[16*i+j];
        }       
    }
}

/* 
 * 기능 : IV에 1더함
 * 입력 : IV
 * 출력 : 없음
 */
void CTRupdate(byte* enc, byte*IV){    
    byte tmp;
    int i=15;
    while(i>=0)
    {
        tmp = IV[i];
        IV[i] = (IV[i]+1)&0xff;
        if(tmp>IV[i])
        {
            i-=1;
        }
        else{            
            memcpy(enc,IV,16);
            return;
        }
    }
    memcpy(enc,IV,16);

}



/* 
 * 기능 : WBCTR 암호화 (non wb). 
 * 입력 : 메시지, 테이블, 메시지길이, iv 입력.
 * 출력 : 없음
 */
void WBCTR_LEA(const int srclen, WBWFLEA_ENCRYPTION_TABLE* enc_tab, XOR_TABLE* cbc_ex_tab, byte* src, byte* CTR)
{

    int blklen = srclen/16;           // block length
    byte enc[16] = {0x0,};  
    byte inCTR[16]={0x0,};

    byte IV[16]={0x0,};
        
    memcpy(inCTR,CTR,16);
    //printf("IV            "); show_bytes(IV, 16);

    for(int i=0;i<blklen;i++)     // N-1 blk
    {
        for(int j=0;j<16;j++){
            enc[j]=src[16*i+j];
        }
        CTRupdate(IV,inCTR);    //iv 증가

        wbwflea_encryptwb(enc_tab, (byte*)IV);

        for(int j=0;j<16;j++)
        {
            byte tmp = cbc_ex_tab->XOR[j/4][(2*j+1)%8   ][(((src[16*i+j] >>4)&0xf) ^(( (IV[j] >>4)&0xf)<<4) )];
            byte tmp1 = ((tmp & 0xf) << 4);
            enc[j] =tmp1^ cbc_ex_tab->XOR[j/4][(2*j)%8 ][((src[16*i+j]&0xf)^( (IV[j]&0xf)<<4 )) ];      //xor 테이블처리
        }

        for(int j=0;j<16;j++)
        {
            src[16*i+j] = enc[j];
            
        }    
    }

}

/* 
 * 기능 : 암호화에서 사용하는 8bit 입력 4bit 출력 xor 함수에 대한 테이블 생성 (CTR은 암복호화 구조 동일하므로 하나만 함수로)
 * 입력 : 입력 인코더(4bit 치환 2개), 출력 인코더 (4bit 치환 1개) 를 이용하여 테이블 생성
 * 출력 : 없음
 */
void CTR_XOR_decoding_table(
            XOR_TABLE* tab,
            WBWFLEA_EXT_ENCODING* f,
            WBWFLEA_EXT_ENCODING* g,
            WBWFLEA_EXT_ENCODING* h)
{
    int i, j, l;
    
    for(i = 0; i < 4; i++)
    {
        for(j = 0; j < 8; j++)
        {
            for (l = 0; l < 256; l++)
            {
                byte X = (l >> 4) & 0xf;
                byte Y = (l) & 0xf;
                byte Z = (f->f[i][j][X])^(g->f_inv[i][j][Y]);

                tab->XOR[i][j][l] = h->f[i][j][Z];                
            }
        }
    }
}
