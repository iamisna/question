#ifndef _WBWFLEA_ENCODINGS_H_
#define _WBWFLEA_ENCODINGS_H_

/**
 * @file    wbwflea_encodings.h
 * @brief   Whitebox WF-LEA C code: Random encoding generation
 * @author  FDL @ KMU
 * @version 2022.06.06.
 */

#include <stdio.h>
#include <stdlib.h>
#include <memory.h>

#include "randperm.h"
#include "wflea.h"
#include "wbwflea_config.h"
#include "wbwflea_ext_transform.h"


/**
 * @brief set of encodings for encryption
 */
typedef struct {
    byte     f[WBWFLEA_ROUNDS][4][8][16];
    byte f_inv[WBWFLEA_ROUNDS][4][8][16];
    byte     g[WBWFLEA_ROUNDS][3][8][16];
    byte g_inv[WBWFLEA_ROUNDS][3][8][16];
    byte     h[WBWFLEA_ROUNDS][3][8][16];
    byte h_inv[WBWFLEA_ROUNDS][3][8][16];
    byte     t[WBWFLEA_ROUNDS][3];
} WBWFLEA_ENCODINGS_FOR_ENCRYPTION;


/**
 * @brief set of encodings for decryption
 */
typedef struct {
    byte     f[WBWFLEA_ROUNDS][3][8][16];
    byte f_inv[WBWFLEA_ROUNDS][3][8][16];
    byte     g[WBWFLEA_ROUNDS][3][8][16];
    byte g_inv[WBWFLEA_ROUNDS][3][8][16];
    byte     h[WBWFLEA_ROUNDS][4][8][16];
    byte h_inv[WBWFLEA_ROUNDS][4][8][16];
    byte     t[WBWFLEA_ROUNDS][3];
} WBWFLEA_ENCODINGS_FOR_DECRYPTION;

/**
 * @brief generate random encodings for encryption
 * @param ctx                   (output) encodings for encryption
 * @param ext_A_file_name       (input) external encoding A binary
 * @param ext_B_file_name       (input) external encoding B binary
 */
void wbwflea_gen_encodings_for_encryption(
        WBWFLEA_ENCODINGS_FOR_ENCRYPTION* ctx, 
        char* ext_A_file_name, char* ext_B_file_name);
/**
 * @brief generate random encodings for decryption
 * @param ctx                   (output) encodings for decryption
 * @param ext_A_file_name       (input) external encoding A binary
 * @param ext_B_file_name       (input) external encoding B binary
 */

void wbwflea_gen_id_encodings_for_encryption(
        WBWFLEA_ENCODINGS_FOR_ENCRYPTION* ctx, 
        char* ext_A_file_name, char* ext_B_file_name);  //TEST

void wbwflea_gen_encodings_for_encryption_notable(
        WBWFLEA_ENCODINGS_FOR_ENCRYPTION* ctx, 
        WBWFLEA_EXT_ENCODING* A, WBWFLEA_EXT_ENCODING* B);


void wbwflea_gen_encodings_for_decryption(
        WBWFLEA_ENCODINGS_FOR_DECRYPTION* ctx,
        char* ext_A_file_name, char* ext_B_file_name);

void wbwflea_gen_encodings_for_decryption_notable(
        WBWFLEA_ENCODINGS_FOR_DECRYPTION* ctx, 
        WBWFLEA_EXT_ENCODING* A, WBWFLEA_EXT_ENCODING* B);



void wbwflea_show_encodings_for_encryption(WBWFLEA_ENCODINGS_FOR_ENCRYPTION* ctx);
void wbwflea_show_encodings_for_decryption(WBWFLEA_ENCODINGS_FOR_DECRYPTION* ctx);

#endif /* _WBWFLEA_ENCODINGS_H_ */