#include "wbwflea_encrypt.h"


/* 
 * 기능 : 화이트박스 lea 덧셈 연산
 * 입력 : 덧셈 테이블, 라운드, eta 번호, 더할 두 32Bit 원소
 * 출력 : 없음
 */
void wbwflea_ADDwb(word* Z, WBWFLEA_ENCRYPTION_TABLE* enc_tab, int r, int i, word X, word Y)
{
    int j;
    byte c = 0;
    *Z = 0;
    for (j = 0; j < 8; j++)
    {
        int cXY = (c << 8) ^ (get_jth_nibble(X, j) << 4) ^ (get_jth_nibble(Y, j));
        byte tmp = enc_tab->ETA[r][i][j][cXY];      //r 라운드 i 번째 테이블을 사용.  
        c = (tmp >> 4) & 0x1;
        *Z ^= ((tmp & 0xf) << (4*j));
    }
}

/* 
 * 기능 : 화이트박스 lea 회전 연산
 * 입력 : 회전 테이블, 라운드, etr 번호, 회전할 32Bit 원소
 * 출력 : 없음
 */
void wbwflea_ROL9wb(word* Y, WBWFLEA_ENCRYPTION_TABLE* enc_tab, int r, word X)
{
    int j;
    *Y = 0;
    for (j = 0; j < 8; j++)
    {
        int XY = (get_jth_nibble(X, (j+6)%8) << 4) ^ (get_jth_nibble(X, (j+5)%8));
        byte tmp = enc_tab->ETR[r][0][j][XY];   //r 라운드 첫번째 테이블을 사용.  
        *Y ^= ((tmp & 0xf) << (4*j));
    }
}

/* 
 * 기능 : 화이트박스 lea 회전 연산
 * 입력 : 회전 테이블, 라운드, dtr 번호, 회전할 32Bit 원소
 * 출력 : 없음
 */
void wbwflea_ROR9wb(word* Y, WBWFLEA_DECRYPTION_TABLE* dec_tab, int r, word X)
{
    int j;
    *Y = 0;
    for (j = 0; j < 8; j++)
    {
        int XY = (get_jth_nibble(X, (j+3)%8) << 4) ^ (get_jth_nibble(X, (j+2)%8));
        byte tmp = dec_tab->DTR[r][0][j][XY];   //r 라운드 첫번째 테이블을 사용.  
        *Y ^= ((tmp & 0xf) << (4*j));
    }

}

/* 
 * 기능 : 화이트박스 lea 회전 연산
 * 입력 : 회전 테이블, 라운드, etr 번호, 회전할 32Bit 원소
 * 출력 : 없음
 */
void wbwflea_ROR5wb(word* Y, WBWFLEA_ENCRYPTION_TABLE* enc_tab, int r, word X)
{
    int j;
    *Y = 0;
    for (j = 0; j < 8; j++)
    {
        int XY = (get_jth_nibble(X, (j+2)%8) << 4) ^ (get_jth_nibble(X, (j+1)%8));
        byte tmp = enc_tab->ETR[r][1][j][XY];   //r 라운드 두번째 테이블을 사용.  
        *Y ^= ((tmp & 0xf) << (4*j));
    }
}
/* 
 * 기능 : 화이트박스 lea 회전 연산
 * 입력 : 회전 테이블, 라운드, dtr 번호, 회전할 32Bit 원소
 * 출력 : 없음
 */
void wbwflea_ROL5wb(word* Y, WBWFLEA_DECRYPTION_TABLE* dec_tab, int r, word X)
{
    int j;
    *Y = 0;
    for (j = 0; j < 8; j++)
    {
        int XY = (get_jth_nibble(X, (j+7)%8) << 4) ^ (get_jth_nibble(X, (j+6)%8));
        byte tmp = dec_tab->DTR[r][1][j][XY]; //r 라운드 두번째 테이블을 사용.  
        *Y ^= ((tmp & 0xf) << (4*j));
    }
}
/* 
 * 기능 : 화이트박스 lea 회전 연산
 * 입력 : 회전 테이블, 라운드, etr 번호, 회전할 32Bit 원소
 * 출력 : 없음
 */
void wbwflea_ROR3wb(word* Y, WBWFLEA_ENCRYPTION_TABLE* enc_tab, int r, word X)
{
    int j;
    *Y = 0;
    for (j = 0; j < 8; j++)
    {
        int XY = (get_jth_nibble(X, (j+1)%8) << 4) ^ (get_jth_nibble(X, j));
        byte tmp = enc_tab->ETR[r][2][j][XY];   //r 라운드 세번째 테이블을 사용.  
        *Y ^= ((tmp & 0xf) << (4*j));
    }
}
/* 
 * 기능 : 화이트박스 lea 회전 연산
 * 입력 : 회전 테이블, 라운드, dtr 번호, 회전할 32Bit 원소
 * 출력 : 없음
 */
void wbwflea_ROL3wb(word* Y, WBWFLEA_DECRYPTION_TABLE* dec_tab, int r, word X)
{
    int j;
    *Y = 0;
    for (j = 0; j < 8; j++)
    {
        int XY = (get_jth_nibble(X, j) << 4) ^ (get_jth_nibble(X, (j+7)%8));
        byte tmp = dec_tab->DTR[r][2][j][XY];   //r 라운드 세번째 테이블을 사용.
        *Y ^= ((tmp & 0xf) << (4*j));
    }
}
/* 
 * 기능 : 화이트박스 lea 뺄셈 연산
 * 입력 : 뺄셈 테이블, 라운드, dts 번호, 뺄셈할 두 32Bit 원소
 * 출력 : 없음
 */
void wbwflea_SUBwb(word* Z, WBWFLEA_DECRYPTION_TABLE* dec_tab, int r, int i, word X, word Y)
{
    int j;
    byte b = 0;
    *Z = 0;
    for (j = 0; j < 8; j++)
    {
        int bXY = (b << 8) ^ (get_jth_nibble(X, j) << 4) ^ (get_jth_nibble(Y, j));
        byte tmp = dec_tab->DTS[r][i][j][bXY];  //r 라운드 i번째 테이블을 사용.
        b = (tmp >> 4) & 0x1;
        *Z ^= ((tmp & 0xf) << (4*j));
    }
}

/* 
 * 기능 : 화이트박스 lea 라운드 연산
 * 입력 : 암호화 테이블, 라운드, 라운드 입력
 * 출력 : 없음
 */
void wbwflea_roundwb(WBWFLEA_ENCRYPTION_TABLE* enc_tab, int r, word* X)
{
    word tmp = X[0];
    word T;

    wbwflea_ADDwb(&T, enc_tab, r, 0, X[0], X[1]);
    wbwflea_ROL9wb(X, enc_tab, r, T);

    wbwflea_ADDwb(&T, enc_tab, r, 1, X[1], X[2]);
    wbwflea_ROR5wb(X + 1, enc_tab, r, T);

    wbwflea_ADDwb(&T, enc_tab, r, 2, X[2], X[3]);
    wbwflea_ROR3wb(X + 2, enc_tab, r, T);

    X[3] = tmp;
}

/* 
 * 기능 : 화이트박스 lea 복호화 라운드 연산
 * 입력 : 복호화 테이블, 라운드, 라운드 입력
 * 출력 : 없음
 */

void wbwflea_invroundwb(WBWFLEA_DECRYPTION_TABLE* dec_tab, int r, word* X)
{
    word tmp = X[3];
    word T;

    wbwflea_ROR9wb(&T, dec_tab, r, X[0]);
    wbwflea_SUBwb(X, dec_tab, r, 0, T, X[3]);

    wbwflea_ROL5wb(&T, dec_tab, r, X[1]);
    wbwflea_SUBwb(X + 1, dec_tab, r, 1, T, X[0]);

    wbwflea_ROL3wb(&T, dec_tab, r, X[2]);
    wbwflea_SUBwb(X + 2, dec_tab, r, 2, T, X[1]);

	X[3] = X[2];
    X[2] = X[1];
    X[1] = X[0];
    X[0] = tmp;
}

/* 
 * 기능 : 워드 출력
 * 입력 : 워드배열, 워드길이
 * 출력 : 없음
 */
void wbwflea_show_words(word* x, int size)
{
    int j;
	for (j = 0; j < size; j++)
        printf("%08x:", *(x + j));
    printf("\n");
}

/* 
 * 기능 : 화이트박스 lea 전체 라운드 연산
 * 입력 : 암호화 테이블, 평문
 * 출력 : 없음
 */
void wbwflea_encryptwb(WBWFLEA_ENCRYPTION_TABLE* enc_tab, byte* x)
{
    int r;
    for (r = 0; r < WBWFLEA_ROUNDS; r++)
    {
        wbwflea_roundwb(enc_tab, r, (word*)x);
		//printf("[%2d] ", r); wbwflea_show_words((word*)x, 4);
    }
}

/* 
 * 기능 : 화이트박스 lea 전체 라운드 연산 디버깅용. 라운드 출력이 리턴
 * 입력 : 암호화 테이블, 평문
 * 출력 : 없음
 */
void wbwflea_encryptwb_debug(
    WBWFLEA_ENCRYPTION_TABLE* enc_tab,
    WBWFLEA_ENCODINGS_FOR_ENCRYPTION* enc_ctx,
    byte* x)
{
    int r;
    for (r = 0; r < WBWFLEA_ROUNDS; r++)
    {
        wbwflea_roundwb(enc_tab, r, (word*)x);
		printf("[%2d] ", r); wbwflea_show_words((word*)x, 4);
     
    }
}

/* 
 * 기능 : 화이트박스 lea 전체복호화 라운드 연산
 * 입력 : 복호화 테이블, 암호문
 * 출력 : 없음
 */
void wbwflea_decryptwb(WBWFLEA_DECRYPTION_TABLE* dec_tab, byte* x)
{
    int r;
    for (r = 0; r < WBWFLEA_ROUNDS; r++)
    {
        wbwflea_invroundwb(dec_tab, r, (word*)x);
		//printf("[%2d] ", r); wbwflea_show_words((word*)x, 4);
    }
}

/* 
 * 기능 : 화이트박스 lea 전체복호화 라운드 연산 디버깅용. 라운드별 출력 프린트
 * 입력 : 복호화 테이블, 암호문
 * 출력 : 없음
 */
void wbwflea_decryptwb_debug(
    WBWFLEA_DECRYPTION_TABLE* dec_tab, 
    WBWFLEA_ENCODINGS_FOR_DECRYPTION* dec_ctx,
    byte* x)
{
    int r;
    for (r = 0; r < WBWFLEA_ROUNDS; r++)
    {
        wbwflea_invroundwb(dec_tab, r, (word*)x);
		printf("[%2d] ", r); wbwflea_show_words((word*)x, 4);

    }
}

/* 
 * 기능 : VPMAC에서 사용하는 화이트박스 lea 전체복호화 라운드 연산. 서로다른 2개의 테이블 이용
 * 입력 : wk1,wk2 테이블, 암호문
 * 출력 : 없음
 */
void wbwflea_sep_encryptwb(WBWFLEA_MAC_WK1* wk1_tab, WBWFLEA_MAC_WK2* wk2_tab, byte* x)
{
    int r;
    for (r = 0; r < Table1; r++)        //상위 table1 라운드는 wk2
    {
        wbwflea_byte_roundwb(wk2_tab->ETA[r], wk2_tab->ETR[r], (word*)x);
    }
    for (r = Table1; r < WBWFLEA_ROUNDS-Table2; r++)        //중간은 wk1를이용
    {
        wbwflea_byte_roundwb(wk1_tab->ETA[r-Table1], wk1_tab->ETR [r-Table1], (word*)x);
    }
    for (r = WBWFLEA_ROUNDS-Table2; r < WBWFLEA_ROUNDS; r++)    //하위 table2 라운드는 wk2
    {
        wbwflea_byte_roundwb(wk2_tab->ETA [r-MIDTable], wk2_tab->ETR [r-MIDTable], (word*)x);
    }
}

/* 
 * 기능 : 바이트를 입력받아 진행하는 화이트박스 lea 암호화 라운드 연산
 * 입력 : ETA, ETR, 라운드 입력
 * 출력 : 없음
 */

void wbwflea_byte_roundwb(byte ETA[3][8][512], byte ETR[3][8][256], word* X)
{
    word tmp = X[0];
    word T;

    for(int i=0;i<4;i++){
        //printf("%08x ",X[i]);
    }
    //printf("\n");

    wbwflea_byte_ADDwb(&T, ETA,  0, X[0], X[1]);
    wbwflea_byte_ROL9wb(X, ETR, T);

    wbwflea_byte_ADDwb(&T, ETA, 1, X[1], X[2]);
    wbwflea_byte_ROR5wb(X + 1,  ETR, T);

    wbwflea_byte_ADDwb(&T, ETA,  2, X[2], X[3]);
    wbwflea_byte_ROR3wb(X + 2,  ETR, T);

    X[3] = tmp;

}

/* 
 * 기능 : 바이트를 입력받아 진행하는 화이트박스 lea 암호화 덧셈
 * 입력 : ETA, i, 더할 두 배열
 * 출력 : 없음
 */
void wbwflea_byte_ADDwb(word* Z, byte ETA[3][8][512], int i, word X, word Y)
{
    int j;
    byte c = 0;
    *Z = 0;
    for (j = 0; j < 8; j++)
    {
        int cXY = (c << 8) ^ (get_jth_nibble(X, j) << 4) ^ (get_jth_nibble(Y, j));
        byte tmp = ETA[i][j][cXY];
        c = (tmp >> 4) & 0x1;
        *Z ^= ((tmp & 0xf) << (4*j));
    }

}

/* 
 * 기능 : 바이트를 입력받아 진행하는 화이트박스 lea 암호화 회전
 * 입력 : ETR, 회전할 배열
 * 출력 : 없음
 */
void wbwflea_byte_ROL9wb(word* Y,  byte ETR[3][8][256], word X)
{
    int j;
    *Y = 0;
    for (j = 0; j < 8; j++)
    {
        int XY = (get_jth_nibble(X, (j+6)%8) << 4) ^ (get_jth_nibble(X, (j+5)%8));
        byte tmp = ETR[0][j][XY];
        *Y ^= ((tmp & 0xf) << (4*j));
    }

}

/* 
 * 기능 : 바이트를 입력받아 진행하는 화이트박스 lea 암호화 회전
 * 입력 : ETR, 회전할 배열
 * 출력 : 없음
 */
void wbwflea_byte_ROR5wb(word* Y, byte ETR[3][8][256], word X)
{
    int j;
    *Y = 0;
    for (j = 0; j < 8; j++)
    {
        int XY = (get_jth_nibble(X, (j+2)%8) << 4) ^ (get_jth_nibble(X, (j+1)%8));
        byte tmp = ETR[1][j][XY];
        *Y ^= ((tmp & 0xf) << (4*j));
    }

}

/* 
 * 기능 : 바이트를 입력받아 진행하는 화이트박스 lea 암호화 회전
 * 입력 : ETR, 회전할 배열
 * 출력 : 없음
 */
void wbwflea_byte_ROR3wb(word* Y,  byte ETR[3][8][256], word X)
{
    int j;
    *Y = 0;
    for (j = 0; j < 8; j++)
    {
        int XY = (get_jth_nibble(X, (j+1)%8) << 4) ^ (get_jth_nibble(X, j));
        byte tmp = ETR[2][j][XY];
        *Y ^= ((tmp & 0xf) << (4*j));
    }
}
