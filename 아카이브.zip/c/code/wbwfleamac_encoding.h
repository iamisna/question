#ifndef _WBWFLEAMAC_ENCODING_H_
#define _WBWFLEAMAC_ENCODING_H_

/**
 * @file    wbwfleamac_encodings.h
 * @brief   Whitebox WF-LEA C code: Random encoding generation
 * @author  FDL @ KMU
 * @version 2022.06.06.
 */

#include <stdio.h>
#include <stdlib.h>
#include <memory.h>

#include "randperm.h"
#include "wflea.h"
#include "wbwflea_config.h"
#include "wbwflea_ext_transform.h"


/**
 * @brief set of encodings for encryption
 */
typedef struct {
    byte     f[WBWFLEA_ROUNDS- Table1 - Table2][4][8][16];
    byte f_inv[WBWFLEA_ROUNDS- Table1 - Table2][4][8][16];
    byte     g[WBWFLEA_ROUNDS- Table1 - Table2][3][8][16];
    byte g_inv[WBWFLEA_ROUNDS- Table1 - Table2][3][8][16];
    byte     h[WBWFLEA_ROUNDS- Table1 - Table2][3][8][16];
    byte h_inv[WBWFLEA_ROUNDS- Table1 - Table2][3][8][16];
    byte     t[WBWFLEA_ROUNDS- Table1 - Table2][3];
} WBWFLEA_ENCODINGS_FOR_MACMID;

typedef struct {
    byte     f[Table1][4][8][16];
    byte f_inv[Table1][4][8][16];
    byte     g[Table1][3][8][16];
    byte g_inv[Table1][3][8][16];
    byte     h[Table1][3][8][16];
    byte h_inv[Table1][3][8][16];
    byte     t[Table1][3];
} WBWFLEA_ENCODINGS_FOR_MACfirst;


typedef struct {
    byte     f[Table2][4][8][16];
    byte f_inv[Table2][4][8][16];
    byte     g[Table2][3][8][16];
    byte g_inv[Table2][3][8][16];
    byte     h[Table2][3][8][16];
    byte h_inv[Table2][3][8][16];
    byte     t[Table2][3];
} WBWFLEA_ENCODINGS_FOR_MACend;

void wbwflea_gen_encodings_for_MACmid(
        WBWFLEA_ENCODINGS_FOR_MACMID* ctx, WBWFLEA_EXT_ENCODING A, WBWFLEA_EXT_ENCODING B);
        
void wbwflea_gen_encodings_for_MACfirst(
        WBWFLEA_ENCODINGS_FOR_MACfirst* ctx, WBWFLEA_EXT_ENCODING* A, WBWFLEA_EXT_ENCODING B);

void wbwflea_gen_encodings_for_MACend(
        WBWFLEA_ENCODINGS_FOR_MACend* ctx, WBWFLEA_EXT_ENCODING A, WBWFLEA_EXT_ENCODING* B);


#endif /* _WBWFLEA_ENCODINGS_H_ */