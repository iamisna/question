#ifndef _LEA128_H_
#define _LEA128_H_

/**
 * @file    lea128.h
 * @brief   LEA128 C code
 * @author  Dong-Chan Kim, FDL @ KMU
 * @version 2022.08.01.
 */

/* -- data type -- */
typedef unsigned char   byte; 	/*!<  8-bit data type */
typedef unsigned int    word; 	/*!< 32-bit data type */

#define LEA128_BYTELEN_KEY		16
#define LEA128_BYTELEN_BLK		16

#define LEA128_WORDLEN_RNDKEY	6
#define LEA128_WORDLEN_BLK		4

#define LEA128_NUM_RNDS	24

void lea128_keyschedule(word rndkey[LEA128_NUM_RNDS][LEA128_WORDLEN_RNDKEY], const byte key[LEA128_BYTELEN_KEY]);
/**
 * @brief LEA128 round function
 * @param x			(input/output) state
 * @param rndkey	(input) 192-bit roundkey
 */
void lea_round(word x[LEA128_WORDLEN_BLK], const word rndkey[LEA128_WORDLEN_RNDKEY]);

/**
 * @brief WFLEA inverse round function
 * @param x			(input/output) state
 * @param rndkey	(input) 192-bit roundkey
 */
void lea_round_inv(word x[LEA128_WORDLEN_BLK], const word rndkey[LEA128_WORDLEN_RNDKEY]);

/**
 * @brief WFLEA 1-block encryption function
 * @param ctx		(input) WFLEA context
 * @param src		(input) input data
 * @param dst		(output) output data
 */
void lea128_encryptblk(byte dst[LEA128_BYTELEN_BLK], const byte src[LEA128_BYTELEN_BLK], const word rndkey[LEA128_NUM_RNDS][LEA128_WORDLEN_RNDKEY]);

/**
 * @brief WFLEA 1-block decryption function
 * @param ctx		(input) WFLEA context
 * @param src		(input) input data
 * @param dst		(output) output data
 */
void lea128_decryptblk(byte dst[LEA128_BYTELEN_BLK], const byte src[LEA128_BYTELEN_BLK], const word rndkey[LEA128_NUM_RNDS][LEA128_WORDLEN_RNDKEY]);



#endif /* _LEA128_H_ */