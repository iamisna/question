#include "wbwflea_encodings.h"

/* 
 * 기능 : 암호화 테이블 생성 구조체 프린트
 * 입력 : 암호화 테이블 생성 구조체
 * 출력 : 없음
 */
void wbwflea_show_encodings_for_encryption(WBWFLEA_ENCODINGS_FOR_ENCRYPTION* ctx)
{
    int r;
    for (r = 0; r < WBWFLEA_ROUNDS; r++)
    {
        printf("f[%d][0]\n", r); show_32bit_perm_4bits(ctx->f[r][0], ctx->f_inv[r][0]);
        printf("f[%d][1]\n", r); show_32bit_perm_4bits(ctx->f[r][1], ctx->f_inv[r][1]);
        printf("f[%d][2]\n", r); show_32bit_perm_4bits(ctx->f[r][2], ctx->f_inv[r][2]);
        printf("f[%d][3]\n", r); show_32bit_perm_4bits(ctx->f[r][3], ctx->f_inv[r][3]);

        printf("g[%d][0]\n", r); show_32bit_perm_4bits(ctx->g[r][0], ctx->g_inv[r][0]);
        printf("g[%d][1]\n", r); show_32bit_perm_4bits(ctx->g[r][1], ctx->g_inv[r][1]);
        printf("g[%d][2]\n", r); show_32bit_perm_4bits(ctx->g[r][2], ctx->g_inv[r][2]);

        printf("h[%d][0]\n", r); show_32bit_perm_4bits(ctx->h[r][0], ctx->h_inv[r][0]);
        printf("h[%d][1]\n", r); show_32bit_perm_4bits(ctx->h[r][1], ctx->h_inv[r][1]);
        printf("h[%d][2]\n", r); show_32bit_perm_4bits(ctx->h[r][2], ctx->h_inv[r][2]);

        printf("t[%d][0] ", r); printf("%02x\n", ctx->t[r][0]);
        printf("t[%d][1] ", r); printf("%02x\n", ctx->t[r][1]);
        printf("t[%d][2] ", r); printf("%02x\n", ctx->t[r][2]);
    }
}

/* 
 * 기능 : 복호화 테이블 생성 구조체 프린트
 * 입력 : 복호화 테이블 생성 구조체
 * 출력 : 없음
 */
void wbwflea_show_encodings_for_decryption(WBWFLEA_ENCODINGS_FOR_DECRYPTION* ctx)
{
    int r;
    for (r = 0; r < WBWFLEA_ROUNDS; r++)
    {
        printf("f[%d][0]\n", r); show_32bit_perm_4bits(ctx->f[r][0], ctx->f_inv[r][0]);
        printf("f[%d][1]\n", r); show_32bit_perm_4bits(ctx->f[r][1], ctx->f_inv[r][1]);
        printf("f[%d][2]\n", r); show_32bit_perm_4bits(ctx->f[r][2], ctx->f_inv[r][2]);

        printf("g[%d]\n", r);
        printf("g[%d][0]\n", r); show_32bit_perm_4bits(ctx->g[r][0], ctx->g_inv[r][0]);
        printf("g[%d][1]\n", r); show_32bit_perm_4bits(ctx->g[r][1], ctx->g_inv[r][1]);
        printf("g[%d][2]\n", r); show_32bit_perm_4bits(ctx->g[r][2], ctx->g_inv[r][2]);

        printf("h[%d]\n", r);
        printf("h[%d][0]\n", r); show_32bit_perm_4bits(ctx->h[r][0], ctx->h_inv[r][0]);
        printf("h[%d][1]\n", r); show_32bit_perm_4bits(ctx->h[r][1], ctx->h_inv[r][1]);
        printf("h[%d][2]\n", r); show_32bit_perm_4bits(ctx->h[r][2], ctx->h_inv[r][2]);
        printf("h[%d][3]\n", r); show_32bit_perm_4bits(ctx->h[r][3], ctx->h_inv[r][3]);

        printf("t[%d][0] ", r); printf("%02x\n", ctx->t[r][0]);
        printf("t[%d][1] ", r); printf("%02x\n", ctx->t[r][1]);
        printf("t[%d][2] ", r); printf("%02x\n", ctx->t[r][2]);
    }
}

/* 
 * 기능 : 암호화 테이블 생성 구조체 생성함수. 외부인코딩이 저장된 파일을 입력받아 테이블 생성
 * 입력 : 외부인코딩 정보 저장된 파일
 * 출력 : 없음
 */
void wbwflea_gen_encodings_for_encryption(
        WBWFLEA_ENCODINGS_FOR_ENCRYPTION* ctx, 
        char* ext_A_file_name, char* ext_B_file_name)
{
    WBWFLEA_EXT_ENCODING A, B;
    wbwflea_read_ext_encoding(&A, ext_A_file_name);
    wbwflea_read_ext_encoding(&B, ext_B_file_name);     //파일 불러오기

    int r, j;

    /* f */
    /* case: r = 0 */
    memcpy(ctx->f[0],       A.f_inv,    4 * 8 * 16);
    memcpy(ctx->f_inv[0],   A.f,        4 * 8 * 16);
    /* case: r = 1, ..., Nr - 2 */
    for (r = 1; r < WBWFLEA_ROUNDS - 1; r++)
    {
        for (j = 0; j < 8; j++)
        {
            gen_randperm_4bits(ctx->f[r][0][j], ctx->f_inv[r][0][j]);
            gen_randperm_4bits(ctx->f[r][1][j], ctx->f_inv[r][1][j]);
            gen_randperm_4bits(ctx->f[r][2][j], ctx->f_inv[r][2][j]);
        }
        memcpy(ctx->f[r][3],        ctx->f[r-1][0],     8 * 16);
        memcpy(ctx->f_inv[r][3],    ctx->f_inv[r-1][0], 8 * 16);
    }
    /* case: r = Nr - 1 */
    memcpy(ctx->f[WBWFLEA_ROUNDS - 1][0],       B.f[3],     8 * 16);
    memcpy(ctx->f_inv[WBWFLEA_ROUNDS - 1][0],   B.f_inv[3], 8 * 16);
    for (j = 0; j < 8; j++)
    {
        gen_randperm_4bits(ctx->f[WBWFLEA_ROUNDS - 1][1][j], ctx->f_inv[WBWFLEA_ROUNDS - 1][1][j]);
        gen_randperm_4bits(ctx->f[WBWFLEA_ROUNDS - 1][2][j], ctx->f_inv[WBWFLEA_ROUNDS - 1][2][j]);
    }
    memcpy(ctx->f[WBWFLEA_ROUNDS - 1][3],       ctx->f[WBWFLEA_ROUNDS - 2][0],      8 * 16);
    memcpy(ctx->f_inv[WBWFLEA_ROUNDS - 1][3],   ctx->f_inv[WBWFLEA_ROUNDS - 2][0],  8 * 16);

    /* g */
    for (r = 0; r < WBWFLEA_ROUNDS; r++)
    {
        for (j = 0; j < 8; j++)
        {
            gen_randperm_4bits(ctx->g[r][0][j], ctx->g_inv[r][0][j]);
            gen_randperm_4bits(ctx->g[r][1][j], ctx->g_inv[r][1][j]);
            gen_randperm_4bits(ctx->g[r][2][j], ctx->g_inv[r][2][j]);
        }
    }

    /* h */
    /* case: r = 0, ..., Nr - 2 */
    for (r = 0; r < WBWFLEA_ROUNDS - 1; r++)
    {
        memcpy(ctx->h[r][0],        ctx->f_inv[r+1][0],     8 * 16);
        memcpy(ctx->h_inv[r][0],    ctx->f[r+1][0],         8 * 16);

        memcpy(ctx->h[r][1],        ctx->f_inv[r+1][1],     8 * 16);
        memcpy(ctx->h_inv[r][1],    ctx->f[r+1][1],         8 * 16);

        memcpy(ctx->h[r][2],        ctx->f_inv[r+1][2],     8 * 16);
        memcpy(ctx->h_inv[r][2],    ctx->f[r+1][2],         8 * 16);
    }
    /* case: r = Nr - 1 */
    memcpy(ctx->h[WBWFLEA_ROUNDS - 1],      B.f_inv,    3 * 8 * 16);
    memcpy(ctx->h_inv[WBWFLEA_ROUNDS - 1],  B.f,        3 * 8 * 16);

    /* t */
    for (r = 0; r < WBWFLEA_ROUNDS; r++)
    {
        gen_randperm_1bits(&(ctx->t[r][0]));
        gen_randperm_1bits(&(ctx->t[r][1]));
        gen_randperm_1bits(&(ctx->t[r][2]));
    }
        
}


/* 
 * 기능 : 항등 퍼뮤테이션으로 구성한 암호화 테이블 생성 구조체 생성함수. 
 * 입력 : 외부인코딩 정보 저장된 파일
 * 출력 : 없음
 */
void wbwflea_gen_id_encodings_for_encryption(
        WBWFLEA_ENCODINGS_FOR_ENCRYPTION* ctx, 
        char* ext_A_file_name, char* ext_B_file_name)
{
    WBWFLEA_EXT_ENCODING A, B;
    wbwflea_read_ext_encoding(&A, ext_A_file_name);
    wbwflea_read_ext_encoding(&B, ext_B_file_name);

    int r, j;

    /* f */
    /* case: r = 0 */
    memcpy(ctx->f[0],       A.f_inv,    4 * 8 * 16);
    memcpy(ctx->f_inv[0],   A.f,        4 * 8 * 16);
    /* case: r = 1, ..., Nr - 2 */
    for (r = 1; r < WBWFLEA_ROUNDS - 1; r++)
    {
        for (j = 0; j < 8; j++)
        {
            set_identity_4bits(ctx->f[r][0][j], ctx->f_inv[r][0][j]);
            set_identity_4bits(ctx->f[r][1][j], ctx->f_inv[r][1][j]);
            set_identity_4bits(ctx->f[r][2][j], ctx->f_inv[r][2][j]);
        }
        memcpy(ctx->f[r][3],        ctx->f[r-1][0],     8 * 16);
        memcpy(ctx->f_inv[r][3],    ctx->f_inv[r-1][0], 8 * 16);
    }
    /* case: r = Nr - 1 */
    memcpy(ctx->f[WBWFLEA_ROUNDS - 1][0],       B.f[3],     8 * 16);
    memcpy(ctx->f_inv[WBWFLEA_ROUNDS - 1][0],   B.f_inv[3], 8 * 16);
    for (j = 0; j < 8; j++)
    {
        set_identity_4bits(ctx->f[WBWFLEA_ROUNDS - 1][1][j], ctx->f_inv[WBWFLEA_ROUNDS - 1][1][j]);
        set_identity_4bits(ctx->f[WBWFLEA_ROUNDS - 1][2][j], ctx->f_inv[WBWFLEA_ROUNDS - 1][2][j]);
    }
    memcpy(ctx->f[WBWFLEA_ROUNDS - 1][3],       ctx->f[WBWFLEA_ROUNDS - 2][0],      8 * 16);
    memcpy(ctx->f_inv[WBWFLEA_ROUNDS - 1][3],   ctx->f_inv[WBWFLEA_ROUNDS - 2][0],  8 * 16);

    /* g */
    for (r = 0; r < WBWFLEA_ROUNDS; r++)
    {
        for (j = 0; j < 8; j++)
        {
            set_identity_4bits(ctx->g[r][0][j], ctx->g_inv[r][0][j]);
            set_identity_4bits(ctx->g[r][1][j], ctx->g_inv[r][1][j]);
            set_identity_4bits(ctx->g[r][2][j], ctx->g_inv[r][2][j]);
        }
    }

    /* h */
    /* case: r = 0, ..., Nr - 2 */
    for (r = 0; r < WBWFLEA_ROUNDS - 1; r++)
    {
        memcpy(ctx->h[r][0],        ctx->f_inv[r+1][0],     8 * 16);
        memcpy(ctx->h_inv[r][0],    ctx->f[r+1][0],         8 * 16);

        memcpy(ctx->h[r][1],        ctx->f_inv[r+1][1],     8 * 16);
        memcpy(ctx->h_inv[r][1],    ctx->f[r+1][1],         8 * 16);

        memcpy(ctx->h[r][2],        ctx->f_inv[r+1][2],     8 * 16);
        memcpy(ctx->h_inv[r][2],    ctx->f[r+1][2],         8 * 16);
    }
    /* case: r = Nr - 1 */
    memcpy(ctx->h[WBWFLEA_ROUNDS - 1],      B.f_inv,    3 * 8 * 16);
    memcpy(ctx->h_inv[WBWFLEA_ROUNDS - 1],  B.f,        3 * 8 * 16);

    /* t */
    for (r = 0; r < WBWFLEA_ROUNDS; r++)
    {
        ctx->t[r][0]=0;
        ctx->t[r][1]=0;
        ctx->t[r][2]=0;
    }
        
}


/* 
 * 기능 : 복호화 테이블 생성 구조체 생성함수. 
 * 입력 : 외부인코딩 정보 저장된 파일
 * 출력 : 없음
 */

void wbwflea_gen_encodings_for_decryption(
        WBWFLEA_ENCODINGS_FOR_DECRYPTION* ctx,
        char* ext_A_file_name, char* ext_B_file_name)
{
    WBWFLEA_EXT_ENCODING A, B;
    wbwflea_read_ext_encoding(&A, ext_A_file_name);
    wbwflea_read_ext_encoding(&B, ext_B_file_name);

    int r, j;

    /* h */
    /* case: r = 0 */
    memcpy(ctx->h[0][0], A.f_inv[3], 8 * 16);
    memcpy(ctx->h_inv[0][0], A.f[3], 8 * 16);
    for (j = 0; j < 8; j++)
    {
        gen_randperm_4bits(ctx->h[0][1][j], ctx->h_inv[0][1][j]);
        gen_randperm_4bits(ctx->h[0][2][j], ctx->h_inv[0][2][j]);
        gen_randperm_4bits(ctx->h[0][3][j], ctx->h_inv[0][3][j]);
    }

    /* case: r = 1, ..., Nr - 2 */
    for (r = 1; r < WBWFLEA_ROUNDS - 1; r++)
    {
        memcpy(ctx->h[r][0], ctx->h_inv[r-1][3], 8 * 16);
        memcpy(ctx->h_inv[r][0], ctx->h[r-1][3], 8 * 16);

        for (j = 0; j < 8; j++)
        {
            gen_randperm_4bits(ctx->h[r][1][j], ctx->h_inv[r][1][j]);
            gen_randperm_4bits(ctx->h[r][2][j], ctx->h_inv[r][2][j]);
            
            if(r != WBWFLEA_ROUNDS - 2)
            {
                gen_randperm_4bits(ctx->h[r][3][j], ctx->h_inv[r][3][j]);
            }
            else
            {
                memcpy(ctx->h[r][3],       B.f_inv[0],     8 * 16);
                memcpy(ctx->h_inv[r][3],   B.f[0],         8 * 16);
            }
        }
    }
    /* case: r = Nr - 1 */
    memcpy(ctx->h[WBWFLEA_ROUNDS - 1][0],       B.f[0],         8 * 16);
    memcpy(ctx->h_inv[WBWFLEA_ROUNDS - 1][0],   B.f_inv[0],     8 * 16);

    memcpy(ctx->h[WBWFLEA_ROUNDS - 1][1],       B.f_inv[1],     8 * 16);
    memcpy(ctx->h_inv[WBWFLEA_ROUNDS - 1][1],   B.f[1],         8 * 16);

    memcpy(ctx->h[WBWFLEA_ROUNDS - 1][2],       B.f_inv[2],     8 * 16);
    memcpy(ctx->h_inv[WBWFLEA_ROUNDS - 1][2],   B.f[2],         8 * 16);

    memcpy(ctx->h[WBWFLEA_ROUNDS - 1][3],       B.f_inv[3],     8 * 16);
    memcpy(ctx->h_inv[WBWFLEA_ROUNDS - 1][3],   B.f[3],         8 * 16);

    /* f */
    /* case: r = 0 */
    memcpy(ctx->f[0],       A.f_inv,    3 * 8 * 16);
    memcpy(ctx->f_inv[0],   A.f,        3 * 8 * 16);
    /* case: r = 1, ..., Nr - 1 */
    for (r = 1; r < WBWFLEA_ROUNDS; r++)
    {
        memcpy(ctx->f[r][0],        ctx->h[r-1][0],         8 * 16);
        memcpy(ctx->f_inv[r][0],    ctx->h_inv[r-1][0],     8 * 16);

        memcpy(ctx->f[r][1],        ctx->h_inv[r-1][1],     8 * 16);
        memcpy(ctx->f_inv[r][1],    ctx->h[r-1][1],         8 * 16);

        memcpy(ctx->f[r][2],        ctx->h_inv[r-1][2],     8 * 16);
        memcpy(ctx->f_inv[r][2],    ctx->h[r-1][2],         8 * 16);
    }

    /* g */
    for (r = 0; r < WBWFLEA_ROUNDS; r++)
    {
        for (j = 0; j < 8; j++)
        {
            gen_randperm_4bits(ctx->g[r][0][j], ctx->g_inv[r][0][j]);
            gen_randperm_4bits(ctx->g[r][1][j], ctx->g_inv[r][1][j]);
            gen_randperm_4bits(ctx->g[r][2][j], ctx->g_inv[r][2][j]);
        }
    }

    /* t */
    for (r = 0; r < WBWFLEA_ROUNDS; r++)
    {
        gen_randperm_1bits(&(ctx->t[r][0]));
        gen_randperm_1bits(&(ctx->t[r][1]));
        gen_randperm_1bits(&(ctx->t[r][2]));
    }
        
}

/* 
 * 기능 : 암호화 테이블 생성 구조체 생성함수. 파일없이 구조체를 입력받는다.
 * 입력 : 외부인코딩
 * 출력 : 없음
 */
void wbwflea_gen_encodings_for_encryption_notable(
        WBWFLEA_ENCODINGS_FOR_ENCRYPTION* ctx, 
        WBWFLEA_EXT_ENCODING* A, WBWFLEA_EXT_ENCODING* B)
{
    int r, j;

    /* f */
    /* case: r = 0 */
    memcpy(ctx->f[0],       A->f_inv,    4 * 8 * 16);
    memcpy(ctx->f_inv[0],   A->f,        4 * 8 * 16);
    /* case: r = 1, ..., Nr - 2 */
    for (r = 1; r < WBWFLEA_ROUNDS - 1; r++)
    {
        for (j = 0; j < 8; j++)
        {
            gen_randperm_4bits(ctx->f[r][0][j], ctx->f_inv[r][0][j]);
            gen_randperm_4bits(ctx->f[r][1][j], ctx->f_inv[r][1][j]);
            gen_randperm_4bits(ctx->f[r][2][j], ctx->f_inv[r][2][j]);
        }
        memcpy(ctx->f[r][3],        ctx->f[r-1][0],     8 * 16);
        memcpy(ctx->f_inv[r][3],    ctx->f_inv[r-1][0], 8 * 16);
    }
    /* case: r = Nr - 1 */
    memcpy(ctx->f[WBWFLEA_ROUNDS - 1][0],       B->f[3],     8 * 16);
    memcpy(ctx->f_inv[WBWFLEA_ROUNDS - 1][0],   B->f_inv[3], 8 * 16);
    for (j = 0; j < 8; j++)
    {
        gen_randperm_4bits(ctx->f[WBWFLEA_ROUNDS - 1][1][j], ctx->f_inv[WBWFLEA_ROUNDS - 1][1][j]);
        gen_randperm_4bits(ctx->f[WBWFLEA_ROUNDS - 1][2][j], ctx->f_inv[WBWFLEA_ROUNDS - 1][2][j]);
    }
    memcpy(ctx->f[WBWFLEA_ROUNDS - 1][3],       ctx->f[WBWFLEA_ROUNDS - 2][0],      8 * 16);
    memcpy(ctx->f_inv[WBWFLEA_ROUNDS - 1][3],   ctx->f_inv[WBWFLEA_ROUNDS - 2][0],  8 * 16);

    /* g */
    for (r = 0; r < WBWFLEA_ROUNDS; r++)
    {
        for (j = 0; j < 8; j++)
        {
            gen_randperm_4bits(ctx->g[r][0][j], ctx->g_inv[r][0][j]);
            gen_randperm_4bits(ctx->g[r][1][j], ctx->g_inv[r][1][j]);
            gen_randperm_4bits(ctx->g[r][2][j], ctx->g_inv[r][2][j]);
        }
    }

    /* h */
    /* case: r = 0, ..., Nr - 2 */
    for (r = 0; r < WBWFLEA_ROUNDS - 1; r++)
    {
        memcpy(ctx->h[r][0],        ctx->f_inv[r+1][0],     8 * 16);
        memcpy(ctx->h_inv[r][0],    ctx->f[r+1][0],         8 * 16);

        memcpy(ctx->h[r][1],        ctx->f_inv[r+1][1],     8 * 16);
        memcpy(ctx->h_inv[r][1],    ctx->f[r+1][1],         8 * 16);

        memcpy(ctx->h[r][2],        ctx->f_inv[r+1][2],     8 * 16);
        memcpy(ctx->h_inv[r][2],    ctx->f[r+1][2],         8 * 16);
    }
    /* case: r = Nr - 1 */
    memcpy(ctx->h[WBWFLEA_ROUNDS - 1],      B->f_inv,    3 * 8 * 16);
    memcpy(ctx->h_inv[WBWFLEA_ROUNDS - 1],  B->f,        3 * 8 * 16);

    /* t */
    for (r = 0; r < WBWFLEA_ROUNDS; r++)
    {
        gen_randperm_1bits(&(ctx->t[r][0]));
        gen_randperm_1bits(&(ctx->t[r][1]));
        gen_randperm_1bits(&(ctx->t[r][2]));
    }
        
}
/* 
 * 기능 : 복호화 테이블 생성 구조체 생성함수. 파일없이 구조체를 입력받는다.
 * 입력 : 외부인코딩
 * 출력 : 없음
 */
void wbwflea_gen_encodings_for_decryption_notable(
        WBWFLEA_ENCODINGS_FOR_DECRYPTION* ctx,
        WBWFLEA_EXT_ENCODING* A, WBWFLEA_EXT_ENCODING* B)
{

    int r, j;

    /* h */
    /* case: r = 0 */
    memcpy(ctx->h[0][0], A->f_inv[3], 8 * 16);
    memcpy(ctx->h_inv[0][0], A->f[3], 8 * 16);
    for (j = 0; j < 8; j++)
    {
        gen_randperm_4bits(ctx->h[0][1][j], ctx->h_inv[0][1][j]);
        gen_randperm_4bits(ctx->h[0][2][j], ctx->h_inv[0][2][j]);
        gen_randperm_4bits(ctx->h[0][3][j], ctx->h_inv[0][3][j]);
    }

    /* case: r = 1, ..., Nr - 2 */
    for (r = 1; r < WBWFLEA_ROUNDS - 1; r++)
    {
        memcpy(ctx->h[r][0], ctx->h_inv[r-1][3], 8 * 16);
        memcpy(ctx->h_inv[r][0], ctx->h[r-1][3], 8 * 16);

        for (j = 0; j < 8; j++)
        {
            gen_randperm_4bits(ctx->h[r][1][j], ctx->h_inv[r][1][j]);
            gen_randperm_4bits(ctx->h[r][2][j], ctx->h_inv[r][2][j]);
            
            if(r != WBWFLEA_ROUNDS - 2)
            {
                gen_randperm_4bits(ctx->h[r][3][j], ctx->h_inv[r][3][j]);
            }
            else
            {
                memcpy(ctx->h[r][3],       B->f_inv[0],     8 * 16);
                memcpy(ctx->h_inv[r][3],   B->f[0],         8 * 16);
            }
        }
    }
    /* case: r = Nr - 1 */
    memcpy(ctx->h[WBWFLEA_ROUNDS - 1][0],       B->f[0],         8 * 16);
    memcpy(ctx->h_inv[WBWFLEA_ROUNDS - 1][0],   B->f_inv[0],     8 * 16);

    memcpy(ctx->h[WBWFLEA_ROUNDS - 1][1],       B->f_inv[1],     8 * 16);
    memcpy(ctx->h_inv[WBWFLEA_ROUNDS - 1][1],   B->f[1],         8 * 16);

    memcpy(ctx->h[WBWFLEA_ROUNDS - 1][2],       B->f_inv[2],     8 * 16);
    memcpy(ctx->h_inv[WBWFLEA_ROUNDS - 1][2],   B->f[2],         8 * 16);

    memcpy(ctx->h[WBWFLEA_ROUNDS - 1][3],       B->f_inv[3],     8 * 16);
    memcpy(ctx->h_inv[WBWFLEA_ROUNDS - 1][3],   B->f[3],         8 * 16);

    /* f */
    /* case: r = 0 */
    memcpy(ctx->f[0],       A->f_inv,    3 * 8 * 16);
    memcpy(ctx->f_inv[0],   A->f,        3 * 8 * 16);
    /* case: r = 1, ..., Nr - 1 */
    for (r = 1; r < WBWFLEA_ROUNDS; r++)
    {
        memcpy(ctx->f[r][0],        ctx->h[r-1][0],         8 * 16);
        memcpy(ctx->f_inv[r][0],    ctx->h_inv[r-1][0],     8 * 16);

        memcpy(ctx->f[r][1],        ctx->h_inv[r-1][1],     8 * 16);
        memcpy(ctx->f_inv[r][1],    ctx->h[r-1][1],         8 * 16);

        memcpy(ctx->f[r][2],        ctx->h_inv[r-1][2],     8 * 16);
        memcpy(ctx->f_inv[r][2],    ctx->h[r-1][2],         8 * 16);
    }

    /* g */
    for (r = 0; r < WBWFLEA_ROUNDS; r++)
    {
        for (j = 0; j < 8; j++)
        {
            gen_randperm_4bits(ctx->g[r][0][j], ctx->g_inv[r][0][j]);
            gen_randperm_4bits(ctx->g[r][1][j], ctx->g_inv[r][1][j]);
            gen_randperm_4bits(ctx->g[r][2][j], ctx->g_inv[r][2][j]);
        }
    }

    /* t */
    for (r = 0; r < WBWFLEA_ROUNDS; r++)
    {
        gen_randperm_1bits(&(ctx->t[r][0]));
        gen_randperm_1bits(&(ctx->t[r][1]));
        gen_randperm_1bits(&(ctx->t[r][2]));
    }
        
}
