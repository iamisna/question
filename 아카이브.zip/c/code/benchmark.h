#ifndef _BENCHMARK_H_
#define _BENCHMARK_H_

#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <time.h>

#include "randperm.h"
#include "wflea.h"
#include "wbwflea_ext_transform.h"
#include "wbwflea_encodings.h"
#include "wbwflea_tables.h"
#include "wbwflea_encrypt.h"
#include "cbclea.h"
#include "ctrlea.h"
#include "vpmac.h"
#include "wbwfleamac_encoding.h"
#include "common.h"
#include "lea128.h"

#define iteration_num  100
#define blklen     39

void TIME_WBWFL();
void TIME_WBCBC();
void TIME_WBCTR();
void TIME_VPMAC();



#endif