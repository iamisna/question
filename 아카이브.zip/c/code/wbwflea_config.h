#ifndef _WBWFLEA_CONFIG_H_
#define _WBWFLEA_CONFIG_H_

/**
 * @file    wbwflea_config.h
 * @brief   Whitebox WF-LEA C code: configuration for key size: 128 or 192 or 256
 * @author  FDL @ KMU
 * @version 2022.06.06.
 */

/* -- if you want the LEA, define "LEA" below -- */
#if 1
#define _WFLEA_
#else
#define _LEA_
#endif

#define WBWFLEA_KEY_BYTES   16  /*!< choose the key size: 16 or 24 or 32 */

#if WBWFLEA_KEY_BYTES == 32
#define WBWFLEA_ROUNDS  32
#elif WBWFLEA_KEY_BYTES == 24
#define WBWFLEA_ROUNDS  28
#else
#define WBWFLEA_ROUNDS  24
#endif

#define Mac_msg_len  5      // padding block's length is multiple of 5*16.
#define Table1 2            // recommend more than 2.
#define Table2 2            // recommend more than 2.

#define MIDTable (WBWFLEA_ROUNDS-Table1-Table2)  //fixed round in wbwfleaMAC.

#endif /* _WBWFLEA_CONFIG_H_ */
