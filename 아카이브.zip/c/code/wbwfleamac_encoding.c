#include "wbwfleamac_encoding.h"


/* 
 * 기능 : WK1 테이블 생성시 필요한 구조체 생성
 * 입력 : 외부인코딩 2개.
 * 출력 : 없음.
 */
void wbwflea_gen_encodings_for_MACmid(
        WBWFLEA_ENCODINGS_FOR_MACMID* ctx, WBWFLEA_EXT_ENCODING A, WBWFLEA_EXT_ENCODING B)
{
    int r, j;

    /* f */
    /* case: r = 0 */
    memcpy(ctx->f[0],       A.f,    4 * 8 * 16);
    memcpy(ctx->f_inv[0],   A.f_inv,        4 * 8 * 16);        //첫라운드는 외부인코딩

    /* case: r = 1, ..., MIDTable */
    for (r = 1; r < MIDTable-1; r++)
    {
        for (j = 0; j < 8; j++)
        {
            gen_randperm_4bits(ctx->f[r][0][j], ctx->f_inv[r][0][j]);
            gen_randperm_4bits(ctx->f[r][1][j], ctx->f_inv[r][1][j]);
            gen_randperm_4bits(ctx->f[r][2][j], ctx->f_inv[r][2][j]);
        }
        memcpy(ctx->f[r][3],        ctx->f[r-1][0],     8 * 16);        
        memcpy(ctx->f_inv[r][3],    ctx->f_inv[r-1][0], 8 * 16);
    }
    /* case: //ex encoding */
    memcpy(ctx->f[MIDTable - 1][0],       B.f_inv[3],     8 * 16);
    memcpy(ctx->f_inv[MIDTable - 1][0],   B.f[3], 8 * 16);
    for (j = 0; j < 8; j++)
    {
        gen_randperm_4bits(ctx->f[MIDTable - 1][1][j], ctx->f_inv[MIDTable - 1][1][j]);
        gen_randperm_4bits(ctx->f[MIDTable - 1][2][j], ctx->f_inv[MIDTable - 1][2][j]);
    }
    memcpy(ctx->f[MIDTable - 1][3],       ctx->f[MIDTable - 2][0],      8 * 16);
    memcpy(ctx->f_inv[MIDTable - 1][3],   ctx->f_inv[MIDTable - 2][0],  8 * 16);

    /* g */
    for (r = 0; r < MIDTable; r++)
    {
        for (j = 0; j < 8; j++)
        {
            gen_randperm_4bits(ctx->g[r][0][j], ctx->g_inv[r][0][j]);
            gen_randperm_4bits(ctx->g[r][1][j], ctx->g_inv[r][1][j]);
            gen_randperm_4bits(ctx->g[r][2][j], ctx->g_inv[r][2][j]);
        }
    }

    /* h */
    /* case: r = 0, ..., Nr - 2 */
    for (r = 0; r < MIDTable-1; r++)
    {
        memcpy(ctx->h[r][0],        ctx->f_inv[r+1][0],     8 * 16);
        memcpy(ctx->h_inv[r][0],    ctx->f[r+1][0],         8 * 16);

        memcpy(ctx->h[r][1],        ctx->f_inv[r+1][1],     8 * 16);
        memcpy(ctx->h_inv[r][1],    ctx->f[r+1][1],         8 * 16);

        memcpy(ctx->h[r][2],        ctx->f_inv[r+1][2],     8 * 16);
        memcpy(ctx->h_inv[r][2],    ctx->f[r+1][2],         8 * 16);
    }
    /* case: exencoding */
    memcpy(ctx->h[MIDTable - 1],      B.f,    3 * 8 * 16);
    memcpy(ctx->h_inv[MIDTable - 1],  B.f_inv,        3 * 8 * 16);

    /* t */
    for (r = 0; r < MIDTable; r++)
    {
        gen_randperm_1bits(&(ctx->t[r][0]));
        gen_randperm_1bits(&(ctx->t[r][1]));
        gen_randperm_1bits(&(ctx->t[r][2]));
    }
}


/* 
 * 기능 : WK2 테이블 생성시 필요한 구조체 생성 (WK1 이전 라운드 암호화 부분)
 * 입력 : 외부인코딩 2개.
 * 출력 : 없음.
 */
void wbwflea_gen_encodings_for_MACfirst(
        WBWFLEA_ENCODINGS_FOR_MACfirst* ctx, WBWFLEA_EXT_ENCODING*A, WBWFLEA_EXT_ENCODING B)
{
    int r, j;
    //wbwflea_gen_ext_encoding(A);

    /* f */
    /* case: r = 0 */
    memcpy(ctx->f[0],       A->f_inv,    4 * 8 * 16);
    memcpy(ctx->f_inv[0],   A->f,        4 * 8 * 16);
    /* case: r = 1, ..., Nr - 2 */
    for (r = 1; r < Table1 -1; r++)
    {
        for (j = 0; j < 8; j++)
        {
            gen_randperm_4bits(ctx->f[r][0][j], ctx->f_inv[r][0][j]);
            gen_randperm_4bits(ctx->f[r][1][j], ctx->f_inv[r][1][j]);
            gen_randperm_4bits(ctx->f[r][2][j], ctx->f_inv[r][2][j]);
        }
        memcpy(ctx->f[r][3],        ctx->f[r-1][0],     8 * 16);
        memcpy(ctx->f_inv[r][3],    ctx->f_inv[r-1][0], 8 * 16);
    }
    /* case: r = Nr - 1 */
    memcpy(ctx->f[Table1 - 1][0],       B.f[3],     8 * 16);
    memcpy(ctx->f_inv[Table1 - 1][0],   B.f_inv[3], 8 * 16);
    for (j = 0; j < 8; j++)
    {
        gen_randperm_4bits(ctx->f[Table1 - 1][1][j], ctx->f_inv[Table1 - 1][1][j]);
        gen_randperm_4bits(ctx->f[Table1 - 1][2][j], ctx->f_inv[Table1 - 1][2][j]);
    }
    memcpy(ctx->f[Table1 - 1][3],       ctx->f[Table1 - 2][0],      8 * 16);
    memcpy(ctx->f_inv[Table1 - 1][3],   ctx->f_inv[Table1 - 2][0],  8 * 16);

    /* g */
    for (r = 0; r < Table1; r++)
    {
        for (j = 0; j < 8; j++)
        {
            gen_randperm_4bits(ctx->g[r][0][j], ctx->g_inv[r][0][j]);
            gen_randperm_4bits(ctx->g[r][1][j], ctx->g_inv[r][1][j]);
            gen_randperm_4bits(ctx->g[r][2][j], ctx->g_inv[r][2][j]);
        }
    }

    /* h */
    /* case: r = 0, ..., Nr - 2 */
    for (r = 0; r < Table1 - 1; r++)
    {
        memcpy(ctx->h[r][0],        ctx->f_inv[r+1][0],     8 * 16);
        memcpy(ctx->h_inv[r][0],    ctx->f[r+1][0],         8 * 16);

        memcpy(ctx->h[r][1],        ctx->f_inv[r+1][1],     8 * 16);
        memcpy(ctx->h_inv[r][1],    ctx->f[r+1][1],         8 * 16);

        memcpy(ctx->h[r][2],        ctx->f_inv[r+1][2],     8 * 16);
        memcpy(ctx->h_inv[r][2],    ctx->f[r+1][2],         8 * 16);
    }
    /* case: r = Nr - 1 */
    memcpy(ctx->h[Table1 - 1],      B.f_inv,    3 * 8 * 16);
    memcpy(ctx->h_inv[Table1 - 1],  B.f,        3 * 8 * 16);

    /* t */
    for (r = 0; r < Table1; r++)
    {
        gen_randperm_1bits(&(ctx->t[r][0]));
        gen_randperm_1bits(&(ctx->t[r][1]));
        gen_randperm_1bits(&(ctx->t[r][2]));
    }
        
}


/* 
 * 기능 : WK2 테이블 생성시 필요한 구조체 생성 (WK1 이후 라운드 암호화 부분)
 * 입력 : 외부인코딩 2개.
 * 출력 : 없음.
 */

void wbwflea_gen_encodings_for_MACend(
        WBWFLEA_ENCODINGS_FOR_MACend* ctx, WBWFLEA_EXT_ENCODING A, WBWFLEA_EXT_ENCODING* B)
{
    int r, j;

    /* f */
    /* case: r = 0 */
    memcpy(ctx->f[0],       A.f_inv,    4 * 8 * 16);
    memcpy(ctx->f_inv[0],   A.f,        4 * 8 * 16);
    /* case: r = 1, ..., Nr - 2 */
    for (r = 1; r < Table2 -1; r++)
    {
        for (j = 0; j < 8; j++)
        {
            gen_randperm_4bits(ctx->f[r][0][j], ctx->f_inv[r][0][j]);
            gen_randperm_4bits(ctx->f[r][1][j], ctx->f_inv[r][1][j]);
            gen_randperm_4bits(ctx->f[r][2][j], ctx->f_inv[r][2][j]);
        }
        memcpy(ctx->f[r][3],        ctx->f[r-1][0],     8 * 16);
        memcpy(ctx->f_inv[r][3],    ctx->f_inv[r-1][0], 8 * 16);
    }
    /* case: r = Nr - 1 */
    memcpy(ctx->f[Table2 - 1][0],       B->f[3],     8 * 16);
    memcpy(ctx->f_inv[Table2 - 1][0],   B->f_inv[3], 8 * 16);
    for (j = 0; j < 8; j++)
    {
        gen_randperm_4bits(ctx->f[Table2 - 1][1][j], ctx->f_inv[Table2 - 1][1][j]);
        gen_randperm_4bits(ctx->f[Table2 - 1][2][j], ctx->f_inv[Table2 - 1][2][j]);
    }
    memcpy(ctx->f[Table2 - 1][3],       ctx->f[Table2 - 2][0],      8 * 16);
    memcpy(ctx->f_inv[Table2 - 1][3],   ctx->f_inv[Table2 - 2][0],  8 * 16);

    /* g */
    for (r = 0; r < Table2; r++)
    {
        for (j = 0; j < 8; j++)
        {
            gen_randperm_4bits(ctx->g[r][0][j], ctx->g_inv[r][0][j]);
            gen_randperm_4bits(ctx->g[r][1][j], ctx->g_inv[r][1][j]);
            gen_randperm_4bits(ctx->g[r][2][j], ctx->g_inv[r][2][j]);
        }
    }

    /* h */
    /* case: r = 0, ..., Nr - 2 */
    for (r = 0; r < Table2 - 1; r++)
    {
        memcpy(ctx->h[r][0],        ctx->f_inv[r+1][0],     8 * 16);
        memcpy(ctx->h_inv[r][0],    ctx->f[r+1][0],         8 * 16);

        memcpy(ctx->h[r][1],        ctx->f_inv[r+1][1],     8 * 16);
        memcpy(ctx->h_inv[r][1],    ctx->f[r+1][1],         8 * 16);

        memcpy(ctx->h[r][2],        ctx->f_inv[r+1][2],     8 * 16);
        memcpy(ctx->h_inv[r][2],    ctx->f[r+1][2],         8 * 16);
    }
    /* case: r = Nr - 1 */
    memcpy(ctx->h[Table2 - 1],      B->f_inv,    3 * 8 * 16);
    memcpy(ctx->h_inv[Table2 - 1],  B->f,        3 * 8 * 16);

    /* t */
    for (r = 0; r < Table2; r++)
    {
        gen_randperm_1bits(&(ctx->t[r][0]));
        gen_randperm_1bits(&(ctx->t[r][1]));
        gen_randperm_1bits(&(ctx->t[r][2]));
    }
        
}
