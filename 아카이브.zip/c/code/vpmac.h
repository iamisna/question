#ifndef _VPMAC_H_
#define _VPMAC_H_

/**
 * @file    vpmac.h
 * @brief   VPMAC Ver1.0    
 * @author  FDL @ KMU       
 * @version 2022.07.24.     
 */

#include <stdio.h>
#include <stdlib.h>
#include <memory.h>

#include "randperm.h"
#include "wflea.h"
#include "wbwflea_ext_transform.h"
#include "wbwflea_encrypt.h"
#include "wbwflea_encodings.h"
#include "wbwflea_config.h"

#include "cbclea.h"

#define     VALID     1
#define     INVALID     0

int Pad_len(int bytelen);
void Pad_msg(byte** dst, byte* src, int bytelen);

void VPMAC_gen(byte* dst, const int srclen, 
    WBWFLEA_MAC_WK1* enc_mid, WBWFLEA_MAC_WK2* enc_end, byte* src);

int VPMAC_verify( const int srclen,
    byte* key, byte* src, byte* IV, byte* Beseed, byte* tag);

void CBCMAC_LEA(byte* dst, const byte* src, byte* IV, const int srclen, byte* key);

void VPMAC_WK1_KEY_GEN(WBWFLEA_MAC_WK1* wk1_tab, byte* AinSeed, byte* BinSeed, byte* key);
void VPMAC_WK2_KEY_GEN(WBWFLEA_MAC_WK2* wk2_tab, byte* AinSeed, byte* BinSeed, byte* IV, byte* BeSeed, byte* key);


#endif /* _VPMAC_H_ */