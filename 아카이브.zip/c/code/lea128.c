/*
	LEA128 C code
	developer: Dong-Chan Kim, FDL@KMU
	2022.08.01.
*/

#include <stdio.h>
#include <stdlib.h>
#include <memory.h>

#include "lea128.h"
#include "common.h"

/* round constants used in LEA */
word del[8] = {
	0xc3efe9db, 0x44626b02, 0x79e27c8a, 0x78df30ec, 
	0x715ea49e, 0xc785da0a, 0xe04ef22a, 0xe5c40957};

/* -- 32-bit small functions -- */
#define ROL(x, l)	((x << l) | (x >> (32-l)))	/*!< 32-bit l-bit left rotation */
#define ROR(x, l)	((x >> l) | (x << (32-l)))	/*!< 32-bit l-bit right rotation */
#define XOR(x, y)	((x) ^ (y))					/*!< 32-bit xor */
#define ADD(x, y)	((x) + (y))					/*!< 32-bit modular addition */
#define SUB(x, y)	((x) - (y))					/*!< 32-bit modular subtraction */

void lea128_keyschedule(word rndkey[LEA128_NUM_RNDS][LEA128_WORDLEN_RNDKEY], const byte key[LEA128_BYTELEN_KEY])
{
	word T[4];
	memcpy(T, key, LEA128_BYTELEN_KEY);

	int j;
	for (j = 0; j < LEA128_NUM_RNDS; j++)
	{
		T[0] = ROL((T[0] + ROL(del[j%4], ((j+0)%32))), 1);
		T[1] = ROL((T[1] + ROL(del[j%4], ((j+1)%32))), 3);
		T[2] = ROL((T[2] + ROL(del[j%4], ((j+2)%32))), 6);
		T[3] = ROL((T[3] + ROL(del[j%4], ((j+3)%32))), 11);

		rndkey[j][0] = T[0];
		rndkey[j][1] = T[1];
		rndkey[j][2] = T[2];
		rndkey[j][3] = T[1];
		rndkey[j][4] = T[3];
		rndkey[j][5] = T[1];
	}
}
/* 
 * 기능 : lea 라운드 암호 함수
 * 입력 : 라운드 입력, 라운드키
 * 출력 : 없음
 */
void lea_round(word x[LEA128_WORDLEN_BLK], const word rndkey[LEA128_WORDLEN_RNDKEY])
{
	word T;
	T = x[0];
	x[0] = ROL(ADD(XOR(x[0], rndkey[0]), XOR(x[1], rndkey[1])), 9);
	x[1] = ROR(ADD(XOR(x[1], rndkey[2]), XOR(x[2], rndkey[3])), 5);
	x[2] = ROR(ADD(XOR(x[2], rndkey[4]), XOR(x[3], rndkey[5])), 3);
	x[3] = T;
}

/* 
 * 기능 : lea 라운드 복호 함수
 * 입력 : 라운드 입력, 라운드키
 * 출력 : 없음
 */
void lea_round_inv(word x[LEA128_WORDLEN_BLK], const word rndkey[LEA128_WORDLEN_RNDKEY])
{
	word T;
	T = x[3];
	x[0] = XOR(SUB(ROR(x[0], 9), XOR(x[3], rndkey[0])), rndkey[1]);
	x[1] = XOR(SUB(ROL(x[1], 5), XOR(x[0], rndkey[2])), rndkey[3]);
	x[2] = XOR(SUB(ROL(x[2], 3), XOR(x[1], rndkey[4])), rndkey[5]);
	x[3] = x[2]; x[2] = x[1]; x[1] = x[0]; x[0] = T;
}

/* 
 * 기능 : lea 전체 라운드 암호 함수
 * 입력 : 평문, 라운드키
 * 출력 : 없음
 */
void lea128_encryptblk(byte dst[LEA128_BYTELEN_BLK], const byte src[LEA128_BYTELEN_BLK], const word rndkey[LEA128_NUM_RNDS][LEA128_WORDLEN_RNDKEY])
{
	word t[LEA128_WORDLEN_BLK] = {0x0,};
	int j;
	memcpy((byte*)t, src, LEA128_BYTELEN_BLK);
	for (j = 0; j < LEA128_NUM_RNDS; j++)
		lea_round((word*)t, rndkey[j]);
	memcpy((byte*)dst, (word*)t, LEA128_BYTELEN_BLK);
}

/* 
 * 기능 : lea 전체 라운드 복호 함수
 * 입력 : 암호문, 라운드키
 * 출력 : 없음
 */
void lea128_decryptblk(byte dst[LEA128_BYTELEN_BLK], const byte src[LEA128_BYTELEN_BLK], const word rndkey[LEA128_NUM_RNDS][LEA128_WORDLEN_RNDKEY])
{
	int j;
	memcpy(dst, src, LEA128_BYTELEN_BLK);
	for (j = 0; j < LEA128_NUM_RNDS; j++)
		lea_round_inv((word*)dst, rndkey[LEA128_NUM_RNDS - 1 - j]);
}