
#include <stdio.h>
#include <stdlib.h>

#include "randperm.h"
#include "wbwflea_ext_transform.h"

/* 
 * 기능 : x와 y의 자리를 교체
 * 입력파라미터 : 변환한 x,y
 * 출력파라미터 : 없음
 * 함수 출력 : 없음
 */
void swap_byte(byte* x, byte* y)
{
    byte tmp = *x;
    *x = *y;
    *y = tmp;
}

/* 
 * 기능 : 지원 rand를 이용한 fisher yates
 * 입력파라미터 : 변환할 x
 * 출력파라미터 : 변환된 x
 * 함수 출력 : 없음
 */
void shuffle_4bits(byte* x)
{
    int i,j;
    for(i=15; i>0; i--)
    {
        j = rand() % (i+1);     //랜덤한 j 생성
        swap_byte(x + i, x + j); // i,j번째 원소 바꾸기
    }
}

/* 
 * 기능 : 입력된 퍼뮤테이션의 역 퍼뮤테이션 생성
 * 입력파라미터 : 퍼뮤테이션 src
 * 출력파라미터 : src의 역 퍼뮤테이션 dst
 * 함수 출력 : 없음
 */
void get_inv_map_4bits(byte* dst, const byte* src)
{
    int j;
    for(j=0; j<16; j++)
        dst[src[j]] = j;
}

/* 
 * 기능 : 4bit 랜덤 퍼뮤테이션 생성 + 역퍼뮤테이션도 함께생성
 * 입력파라미터 : 없음
 * 출력파라미터 : 퍼뮤테이션 map, map의 역 퍼뮤테이션 map_inv
 * 함수 출력 : 없음
 */
void gen_randperm_4bits(byte* map, byte* map_inv)
{
    int j;
    for(j = 0; j < 16; j++)
        map[j] = j;
    shuffle_4bits(map);      //4bit fisher yates   
    get_inv_map_4bits(map_inv, map);    //역 퍼뮤테이션 생성
}

/* 
 * 기능 : 1bit 랜덤 퍼뮤테이션 생성  (1바이트에 8개의 퍼뮤테이션 저장)
 * 입력파라미터 : 없음
 * 출력파라미터 : 퍼뮤테이션 map
 * 함수 출력 : 없음
 */
void gen_randperm_1bits(byte* map)
{
    *map = rand() & 0xff;
}

/* 
 * 기능 : 4bit 랜덤 퍼뮤테이션 프린트
 * 입력파라미터 : 퍼뮤테이션 map
 * 출력파라미터 : 없음
 * 함수 출력 : 없음
 */
void show_perm_4bits(byte* map)
{
    int j;
    for (j = 0; j < 16; j++)
    {
        printf("%1x ", map[j]);
    }
    printf("\n");
}

/* 
 * 기능 : 4bit 랜덤 퍼뮤테이션 8개로 만든 32bit 퍼뮤테이션 프린트
 * 입력파라미터 : 퍼뮤테이션 map, 역 퍼뮤테이션 map_inv
 * 출력파라미터 : 없음
 * 함수 출력 : 없음
 */
void show_32bit_perm_4bits(byte map[8][16], byte map_inv[8][16])
{
    int j;
    for (j = 0; j < 8; j++)
    {
        printf("[%d] ", j); show_perm_4bits(map[j]);
        printf("    ");    show_perm_4bits(map_inv[j]);
    }
}

/* 
 * 기능 : 4bit 항등 퍼뮤테이션 생성
 * 입력파라미터 : 없음
 * 출력파라미터 : 항등 퍼뮤테이션 map, 역 퍼뮤테이션 map_inv
 * 함수 출력 : 없음
 */
void set_identity_4bits(byte* map, byte* map_inv)
{
    int j;
    for(j = 0; j < 16; j++)
        map[j] = j;         //항등 퍼뮤테이션
    get_inv_map_4bits(map_inv, map);
}

/* 
 * 기능 : 32bit의 치환을 4bit 퍼뮤테이션 8개로 진행 
 * 입력파라미터 : 32bit 워드 X, 퍼뮤테이션 map
 * 출력파라미터 : 없음
 * 함수 출력 : 워드 x의 치환 결과
 */
word transform_by_32bit_perm_4bits(word X, byte map[8][16])
{
    word ret = 0;
    int j;
    for (j = 0; j < 8; j++)
    {
        ret ^= ((map[j][get_jth_nibble(X, j)]) << (4*j));
    }
    return ret;
}

/* 
 * 기능 : 4bit 퍼뮤테이션 기본값 생성(0,1,2,...,f)
 * 입력파라미터 : 없음
 * 출력파라미터 : 4bit 기본 퍼뮤테이션
 * 함수 출력 : 없음
 */
void init_perm_4bits(byte dst[16])
{
    int j;
    for (j = 0; j < 16; j++)
        dst[j] = j;
}

/* 
 * 기능 : 16바이트 원소를 이용한 4bit 랜덤 퍼뮤테이션. 기존에 rand 함수로 생성한 난수를 drbg 생성하여 사용.
 * 입력파라미터 : 랜덤 난수 rdat
 * 출력파라미터 : 4bit 퍼뮤테이션 x, x_int,
 * 함수 출력 : 없음
 */
void gen_randperm_4bits_w_16B(byte rdat[16], byte x[16], byte x_inv[16])
{
    init_perm_4bits(x);

    int j,l,t;
    for(t=4; t>0; t--)
    {
        int u = 1<<t;
        for(l=0; l<(u>>1); l++)
        {
            int i = u-1-l;
    
            int cnt = 0;
            while(cnt <= 8-t)
            {
                int mask = u-1;
                j = (rdat[i] >> cnt) & mask;      //rdat로 난수 생성.  
                if (j <= i)
                    break;
                cnt++;
            }
            j = j%(i+1);
            swap_byte(x + i, x + j);
        }
    }
    get_inv_map_4bits(x_inv, x);

}

/* 
 * 기능 : 배열 값을 정수로 변환하여 1을 더한값을 다시 배열로 출력
 * 입력파라미터 : 배열 x
 * 출력파라미터 : x에 1을 더한 배열 x
 * 함수 출력 : 없음
 */
void add_one(byte x[LEA128_BYTELEN_BLK])
{
    int j;
    for (j = 15; j >= 0; j--)   //배열에 1더했을때 carry계산
    {
        byte t = x[j];
        x[j] = x[j] + 1;
        if (t < x[j])
            return;
    }    
}

/* 
 * 기능 : 128bit
 * 입력파라미터 : 배열 x
 * 출력파라미터 : x에 1을 더한 배열 x
 * 함수 출력 : 없음
 */
void XOR128(word dst[LEA128_WORDLEN_BLK], word src[LEA128_WORDLEN_BLK])
{
    int i;
    for (i = 0; i < LEA128_WORDLEN_BLK; i++)
        dst[i] = dst[i] ^ src[i];
}

void gen_rand_512B(byte dst[512], byte seed[32])
{
    int i;
    byte K[LEA128_BYTELEN_KEY] = {0x0,};
    byte V[LEA128_BYTELEN_BLK] = {0x0,};
    word RK[LEA128_NUM_RNDS][LEA128_WORDLEN_RNDKEY] = {0x0,};

    lea128_keyschedule(RK, K);
    add_one(V);

    // for(int i=0;i<LEA128_BYTELEN_BLK;i++)
    // {
    //     printf("%02x ", V[i]);
    // }
    // printf("\n");
   
    lea128_encryptblk(K, V, RK);

    // for(int i=0;i<LEA128_BYTELEN_BLK;i++)
    // {
    //     printf("%02x ", K[i]);
    // }
    // printf("\n");
    XOR128((word*)K, (word*)seed);
    add_one(V);
    lea128_encryptblk(V, V, RK);
    XOR128((word*)V, (word*)(seed + LEA128_BYTELEN_BLK));

    lea128_keyschedule(RK, K);
    for (i = 0; i < 32; i++)
    {
        add_one(V);
        // for(int i=0;i<LEA128_BYTELEN_BLK;i++)
        // {
        //     printf("%02x ", V[i]);
        // }
        // printf("\n");        
        lea128_encryptblk(dst + LEA128_BYTELEN_BLK*i, V, RK);
    }
}

void gen_randperm_128bits(WBWFLEA_EXT_ENCODING* ctx, byte seed[32])
{
    byte rdat[512] = {0x0,};
    gen_rand_512B(rdat, seed);

    //puts("\n[random 512-byte derived from seed]"); 
    //show_byte((byte*)rdat, 512);
    int i,j;
    for(i = 0; i < 4; i++)
        for(j = 0; j < 8; j++)
            gen_randperm_4bits_w_16B(rdat + 16*(8*i+j), ctx->f[i][j], ctx->f_inv[i][j]);
}


