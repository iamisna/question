#ifndef _CTRLEA_H_
#define _CTRLEA_H_

/**
 * @file    ctrlea.h
 * @brief   Whitebox WF-LEA C code: configuration for key size: 128 or 192 or 256
 * @author  FDL @ KMU
 * @version 2022.07.23.
 */

#include <stdio.h>
#include <stdlib.h>
#include <memory.h>

#include "randperm.h"
#include "wflea.h"
#include "wbwflea_encrypt.h"
#include "wbwflea_encodings.h"
#include "wbwflea_ext_transform.h"
#include "cbclea.h"

void CTRupdate(byte*IV, byte* CTR);


void CTR_XOR_decoding_table(
            XOR_TABLE* tab,
            WBWFLEA_EXT_ENCODING* f,
            WBWFLEA_EXT_ENCODING* g,
            WBWFLEA_EXT_ENCODING* h);

void CTR_LEA(byte* dst, const byte* src, byte* IV, const int srclen, byte* key);
void CTR_KEY_GEN_ENC(WBWFLEA_ENCRYPTION_TABLE* enc_tab, XOR_TABLE* ctr_ex_tab,
                byte* AeSeed, byte* CTRHSeed, byte* CTRGSeed, byte* key);
void CTR_KEY_GEN_DEC(WBWFLEA_ENCRYPTION_TABLE* dec_tab, XOR_TABLE* cbc_de_ex_tab, 
                byte* AeSeed, byte* CTRHSeed, byte* CTRHdSeed, byte* key);
void WBCTR_LEA(const int srclen, WBWFLEA_ENCRYPTION_TABLE* enc_tab, XOR_TABLE* cbc_ex_tab, byte* src, byte* IV);
void CTR_LEA_w_Encoder(byte* dst, const byte* src, byte* IV, const int srclen,  WBWFLEA_EXT_ENCODING* Ae, byte* key);


#endif /* _CTRLEA_H_ */