#include <stdio.h>
#include <stdlib.h>

#include "randperm.h"
#include "wbwflea_ext_transform.h"

/* 
 * 기능 : 외부인코딩 생성함수
 * 입력 : 외부인코딩 구조체
 * 출력 : 없음
 */
void wbwflea_gen_ext_encoding(WBWFLEA_EXT_ENCODING* ctx)
{
    int i,j;
    for(i = 0; i < 4; i++)
        for(j = 0; j < 8; j++)
            gen_randperm_4bits(ctx->f[i][j], ctx->f_inv[i][j]);     //4bit 퍼뮤테이션을 32개 이용하여 128bit 치환
}
/* 
 * 기능 : 외부 항등 퍼뮤테이션 인코딩 생성함수
 * 입력 : 외부인코딩 구조체
 * 출력 : 없음
 */
void wbwflea_gen_ext_identity_encoding(WBWFLEA_EXT_ENCODING* ctx)      
{
    int i,j;
    for(i = 0; i < 4; i++)
        for(j = 0; j < 8; j++)
            set_identity_4bits(ctx->f[i][j], ctx->f_inv[i][j]);     //항등 퍼뮤테이션
}

/* 
 * 기능 : 외부 인코딩 파일에 쓰기
 * 입력 : 외부인코딩 구조체, 파일명
 * 출력 : 없음
 */
void wbwflea_write_ext_encoding(WBWFLEA_EXT_ENCODING* ctx, char* file_name)
{
    FILE* fp = fopen(file_name, "wb");
    if(fp != NULL)
    {
        fwrite(ctx, sizeof(WBWFLEA_EXT_ENCODING), 1, fp);
        fclose(fp);
    }
}

/* 
 * 기능 : 외부 인코딩 파일에서 읽기
 * 입력 : 외부인코딩 구조체, 파일명
 * 출력 : 없음
 */
void wbwflea_read_ext_encoding(WBWFLEA_EXT_ENCODING* ctx, char* file_name)
{
    FILE* fp = fopen(file_name, "rb");
    if(fp != NULL)
    {
        fread(ctx, sizeof(WBWFLEA_EXT_ENCODING), 1, fp);
		fclose(fp);
    }
}

/* 
 * 기능 : 외부 인코딩 콘솔에 프린트
 * 입력 : 외부인코딩 구조체, 파일명
 * 출력 : 없음
 */
void wbwflea_show_ext_encoding(WBWFLEA_EXT_ENCODING* ctx)
{
    int i,j,l;
    for(i = 0; i < 4; i++)
    {
        for(j = 0; j < 8; j++)
        {
            printf("[%d,%d] f    ", i, j);
            for(l = 0; l < 16; l++)
                printf("%1x ", ctx->f[i][j][l]);
            printf("\n");

            printf("      finv ");
            for(l = 0; l < 16; l++)
                printf("%1x ", ctx->f_inv[i][j][l]);
            printf("\n");
        }
    }    
}

/* 
 * 기능 : 외부인코딩 사용. flag에 따라 퍼뮤테이션 혹은 역 퍼뮤테이션 사용(0 or 1)
 * 입력 : 외부인코딩 구조체, 치환한 데이터, flag
 * 출력 : 없음
 */
void wbwflea_ext_transform(WBWFLEA_EXT_ENCODING* ctx, word* X, int flag)
{
    int i,j;
    for(i = 0; i < 4; i++)
    {
        word T = 0;
        for(j = 0; j < 8; j++)
        {
            word tmp;
            if (flag == 0)
                tmp = ctx->f[i][j][(X[i] >> (4*j)) & 0xf];  //flag 0이면 퍼뮤테이션
            else
                tmp = ctx->f_inv[i][j][(X[i] >> (4*j)) & 0xf]; //flag 1이면 역퍼뮤테이션

            T ^= tmp << (4*j);
        }
        X[i] = T;

    }
}