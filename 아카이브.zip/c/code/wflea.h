#ifndef _WFLEA_H_
#define _WFLEA_H_

/**
 * @file    wflea.h
 * @brief   WF-LEA C code
 * @author  FDL @ KMU
 * @version 2022.06.06.
 */

/* -- data type -- */
#include "lea128.h"

//typedef unsigned char   byte; 	/*!<  8-bit data type */
//typedef unsigned int    word; 	/*!< 32-bit data type */

#define WORD_BYTES      4		/*!< number of bytes of 1 word */

#define WFLEA_MAX_KEY_BYTES		32	/*!< number of bytes of a key = 16 or 24 or 32 */
#define WFLEA_MAX_ROUNDS		32	/*!< number of rounds = 24 or 28 or 32 */

/**
 * @brief structure for context of WF-LEA
 */
typedef struct {

	/* fixed parameters */
	int blk_bytes;		/*!< number of bytes of a block = 16 */
	int blk_words;		/*!< number of words of a block = 4 */
	int rndkey_bytes;	/*!< number of bytes of a roundkey = 24 */
	int rndkey_words;	/*!< number of words of a roundkey = 6 */

	/* key */
	int key_bytes;					/*!< number of bytes of a key = 16 or 24 or 32*/
	byte key[WFLEA_MAX_KEY_BYTES];	/*!< key */

	/* number of rounds */
	int num_rounds;					/*!< number of rounds = 24 or 28 or 32*/

	/* round keys */
	word rndkey[WFLEA_MAX_ROUNDS][6];	/*!< Nr roundkeys */

} WFLEA_CTX;

/* -- 32-bit small functions -- */
#define ROL(x, l)	((x << l) | (x >> (32-l)))	/*!< 32-bit l-bit left rotation */
#define ROR(x, l)	((x >> l) | (x << (32-l)))	/*!< 32-bit l-bit right rotation */
#define XOR(x, y)	((x) ^ (y))					/*!< 32-bit xor */
#define ADD(x, y)	((x) + (y))					/*!< 32-bit modular addition */
#define SUB(x, y)	((x) - (y))					/*!< 32-bit modular subtraction */
#define get_jth_nibble(x, j)	(((x) >> (4*(j))) & 0xf)	/*!< get j-th nibble of a word x */

/*
	x, y: 4-bit
	c, b: 1-bit
	l: 1,2,3
	z: output
*/
/* -- 4-bit small functions -- */
#define xor(z, x, y)	(z = ((x) ^ (y)) & 0xf)
#define rol(z, x, y, l)	(z = (((((x) << l) | ((y) >> (4-l)))) & 0xf))
#define ror(z, x, y, l)	(z = (((((x) << (4-l)) | ((y) >> l))) & 0xf))
#define add(z, c, x, y)	(z = (((c) + (x) + (y)) & 0x1f)) /*!< 4-bit modular addition: z <- x + y + c,  z = c||Z */
#define sub(z, b, x, y) {\
	byte t, zz;\
	if (x < y) {zz = (0x10 + x) - y; t = 1;} else {zz = x - y; t = 0;}\
	if (zz < b) {zz = (0x10 + zz) - b; t = t + 1;} else {zz = zz - b;}\
	z = (zz ^ (t << 4)) & 0x1f;\
}  /*!< 4-bit modular subtraction: z <- x - y - b,  z = b||Z */


/**
 * @brief WFLEA context generation (roundkey generation)
 * @param ctx		(output) WFLEA context
 * @param key_bits	(input) 128 or 192 or 256
 * @param key		(input) key
 * @return error message: input invalidation
 */
int  wflea_gen_ctx(WFLEA_CTX* ctx, const int key_bits, const byte* key);

/**
 * @brief show WFLEA context
 * @param ctx		(input) WFLEA context
 */
void wflea_show_ctx(WFLEA_CTX* ctx);

/**
 * @brief WFLEA round function
 * @param x			(input/output) state
 * @param rndkey	(input) 192-bit roundkey
 */
void wflea_round(word* x, const word* rndkey);

/**
 * @brief WFLEA inverse round function
 * @param x			(input/output) state
 * @param rndkey	(input) 192-bit roundkey
 */
void wflea_round_inv(word* x, const word* rndkey);

/**
 * @brief WFLEA 1-block encryption function
 * @param ctx		(input) WFLEA context
 * @param src		(input) input data
 * @param dst		(output) output data
 */
void wflea_encryptblk(byte* dst, const byte* src, const WFLEA_CTX* ctx);
void wflea_encryptblk_debug(byte* dst, const byte* src, const WFLEA_CTX* ctx);

/**
 * @brief WFLEA 1-block decryption function
 * @param ctx		(input) WFLEA context
 * @param src		(input) input data
 * @param dst		(output) output data
 */
void wflea_decryptblk(byte* dst, const byte* src, const WFLEA_CTX* ctx);
void wflea_decryptblk_debug(byte* dst, const byte* src, const WFLEA_CTX* ctx);


/* -- 4-bit based functions -- */
/* -- 32-bit small functions using 4-bit functions -- */
word XOR_4bits(word x, word y);			/*!< 4-bit XOR */
word ADD_4bits(word src1, word src2);	/*!< 4-bit modular addition */
word SUB_4bits(word src1, word src2);	/*!< 4-bit modular subtraction */
word ROR_4bits(word x, int l);			/*!< 4-bit right rotation */
word ROL_4bits(word x, int l);			/*!< 4-bit left rotation */

/**
 * @brief WFLEA round function (4-bit version)
 * @param x			(input/output) state
 * @param rndkey	(input) 192-bit roundkey
 */
void wflea_round_4bits(word* x, const word* rndkey);

/**
 * @brief WFLEA inverse round function (4-bit version)
 * @param x			(input/output) state
 * @param rndkey	(input) 192-bit roundkey
 */
void wflea_round_inv_4bits(word* x, const word* rndkey);

/**
 * @brief WFLEA 1-block encryption function (4-bit version)
 * @param ctx		(input) WFLEA context
 * @param src		(input) input data
 * @param dst		(output) output data
 */
void wflea_encryptblk_4bits(byte* dst, const byte* src, const WFLEA_CTX* ctx);

/**
 * @brief WFLEA 1-block decryption function (4-bit version)
 * @param ctx		(input) WFLEA context
 * @param src		(input) input data
 * @param dst		(output) output data
 */
void wflea_decryptblk_4bits(byte* dst, const byte* src, const WFLEA_CTX* ctx);

#endif /* _WFLEA_H_ */