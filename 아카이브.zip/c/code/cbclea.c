#include "cbclea.h"

/* 
 * 기능 : 입력받은 메시지를 패딩하고(PKCS#7), 인코딩 적용.
 * 입력 : 패딩전 메시지, 패딩전 메시지 길이, 인코딩.  인코딩한 메시지와 인코딩 메시지의 길이 생성.
 * 출력 : 없음
 */
void Encode(byte** dst, byte* wbe_dat, int* data_len, byte* CBCAeSeed){
    WBWFLEA_EXT_ENCODING CBCAe;             
    gen_randperm_128bits(&CBCAe, CBCAeSeed);    
    
    CBC_PAD(dst, wbe_dat, data_len);     // 메시지 패딩   

    int blk_len = (*data_len)/16;
    for (int i=0; i<blk_len;i++ ){
        wbwflea_ext_transform(&CBCAe, (word*)((*dst)+(16*i)), 0);  //CBCAeSeed를 이용하여 인코딩 생성
    }

}

/* 
 * 기능 : 입력받은 메시지를 디코딩하고, 패딩 정보를 이용하여 패딩제거.
 * 입력 : 메시지, 메시지 길이, 인코딩을 입력받아  디코딩한 메시지와 디코딩 메시지의 길이 생성.
 * 출력 : 없음
 */
void Decode(byte** msg, byte* encoded_msg, int* data_len, byte* CBCBeSeed){

    WBWFLEA_EXT_ENCODING CBCBe;             
    gen_randperm_128bits(&CBCBe, CBCBeSeed);


    for (int i=0; i<(*data_len)/16;i++ ){
        wbwflea_ext_transform(&CBCBe, (word*)(encoded_msg+(16*i)), 0);  //CBCAeSeed를 이용하여 인코딩 생성
    }
    Remove_Pad(msg, encoded_msg, data_len);     //패딩 정보 이용 메시지 복원
} 


/* 
 * 기능 : CBC 암호화 에서 사용하는 키테이블(wblea, xor) 생성
 * 입력 : 외부인코딩 시드, 키를 입력받아 테이블 생성
 * 출력 : 없음
 */
void CBC_KEY_GEN_ENC(WBWFLEA_ENCRYPTION_TABLE* enc_tab,XOR_TABLE* cbc_ex_tab, 
                        byte* CBCAeSeed, byte* BeSeed, byte* key){

    /* setup: WFLEA context (roundkey generation) */
    WFLEA_CTX wflea_ctx;
    wflea_gen_ctx(&wflea_ctx, WBWFLEA_KEY_BYTES*8, key);
    
    /* external encoding generation (for encryption) */
    WBWFLEA_EXT_ENCODING Ae,Be;       
    wbwflea_gen_ext_encoding(&Ae);      //Ae는 내장 랜덤함수이용.
    gen_randperm_128bits(&Be, BeSeed);  //Be는 시드를 통한 drbg이용.

    /* random networked encodings generation (for encryption) */
    WBWFLEA_ENCODINGS_FOR_ENCRYPTION enc_ctx;
    wbwflea_gen_encodings_for_encryption_notable(&enc_ctx, &Ae, &Be);       //Ae, Be를 이용하여 구조체 생성
    
    /* encryption table generation with external encoding, random networked encodings, roundkey */
    wbwflea_gen_encryption_table(enc_tab, &enc_ctx, &wflea_ctx);    //구조체와 키정보 이용하여 테이블 생성

    /*Xor encoding (for encryption) */
    WBWFLEA_EXT_ENCODING CBCAe;       
    gen_randperm_128bits(&CBCAe, CBCAeSeed);

    /*Xor table (for encryption) */
    XOR_encoding_table(cbc_ex_tab, &CBCAe, &Be, &Ae);       //외부 인코딩 3개를 이용하여 xor 테이블 생성.

}   

/* 
 * 기능 : CBC 복호화 에서 사용하는 키테이블(wblea, xor) 생성
 * 입력 : 외부인코딩 시드, 키를 입력받아 테이블 생성
 * 출력 : 없음
 */
void CBC_KEY_GEN_DEC(WBWFLEA_DECRYPTION_TABLE* dec_tab, XOR_TABLE* cbc_de_ex_tab, 
                  byte* CBCBeSeed, byte* BeSeed, byte* key){

    /* setup: WFLEA context (roundkey generation) */
    WFLEA_CTX wflea_ctx;
    wflea_gen_ctx(&wflea_ctx, WBWFLEA_KEY_BYTES*8, key);
    
    /* external encoding generation (for encryption) */
    WBWFLEA_EXT_ENCODING Be;                
    gen_randperm_128bits(&Be, BeSeed);  //시드를 입력하는 drbg로 난수 생성

    /* external encoding generation (for decryption) */
    WBWFLEA_EXT_ENCODING Bd,Bep;        //Bep is inverse of Be
    wbwflea_gen_ext_encoding(&Bd);

    memcpy(Bep.f,Be.f_inv,4*8*16);      //Be의 역 퍼뮤테이션 생성
    memcpy(Bep.f_inv,Be.f,4*8*16);

    /* random networked encodings generation (for decryption) */
    WBWFLEA_ENCODINGS_FOR_DECRYPTION dec_ctx;
    wbwflea_gen_encodings_for_decryption_notable(&dec_ctx,  &Bep, &Bd);     // 외부인코딩 이용하여 구조체 생성

    /* decryption table generation with external encoding, random networked encodings, roundkey */
    wbwflea_gen_decryption_table(dec_tab, &dec_ctx, &wflea_ctx);        //구조체와 키정보 이용하여 테이블 생성
    
    /*Xor encoding (for decryption) */
    WBWFLEA_EXT_ENCODING CBCBe;       
    gen_randperm_128bits(&CBCBe, CBCBeSeed);        //시드를 통해 난수 생성

    /*Xor table (for decryption) */
    XOR_decoding_table(cbc_de_ex_tab, &Bd, &Be, &CBCBe);    //외부 인코딩을 이용하여 xor 테이블 생성
}   

/* 
 * 기능 : WBCBC 에서 사용하는 PKCS #7 패딩
 * 입력 : 패딩전 메시지, 메시지 길이를 입력하여 패딩된 메시지와 패딩 메시지 길이 생성.
 * 출력 : 없음
 */
void CBC_PAD(byte** dst,  byte* src, int* srclen)
{
    byte *padded_msg;
    int pad_len = (*srclen);
    int padnum = 16- (pad_len%16);   // 블록에 맞게 끝나는 경우 1블럭 더 패딩 바이트 생성. (패딩 길이 범위가 1-16)
    
    pad_len = pad_len + padnum;     //패딩후의 메시지 길이

    padded_msg = calloc(pad_len, sizeof(int));
    *dst = calloc(pad_len , sizeof(int));

    memcpy((*dst),src,(*srclen));

    for(int i =0; i<padnum;i++){
        (*dst)[(*srclen) + i] = padnum&0xff;    // 패딩한 길이를 바이트로 저장하여 패딩.
    }

    (*srclen)=pad_len;  //패딩 길이로 메시지 길이 갱신
    
    free(padded_msg);
}

/* 
 * 기능 : WBCBC 에서 사용하는 패딩 제거
 * 입력 : 패딩된 메시지, 메시지 길이를 입력하여 패딩제거한 메시지와 패딩 메시지 길이 생성.
 * 출력 : 없음
 */
void Remove_Pad(byte** dst, byte* src, int* srclen)
{
    int msg_len = src[(*srclen)-1];   //맨 뒤에있는 블록은 무조건 패딩길이 정보를 가지고 있으므로 그만큼을 제외한 바이트를 출력.
    (* srclen)= (*srclen)-msg_len;      
    (*dst) = calloc((*srclen) , sizeof(int));   
    memcpy(*dst, src,(*srclen));
}

/* 
 * 기능 : CBC LEA 암호화 (non wb)
 * 입력 : 메시지, IV, 메시지 길이, 키를 입력받아 CBC LEA 암호화 진행
 * 출력 : 없음
 */
void CBC_LEA(byte** dst,  byte* src, byte* IV, const int  srclen, byte* key)
{
    WFLEA_CTX ctx;
    wflea_gen_ctx(&ctx, 128, key); 
    
    int blklen = srclen/16;

    byte enc[16] = {0x0,};  
    byte dec[16] = {0x0,}; 
    byte inIV[16] = {0x0,};

    memcpy(inIV,IV,16);

    for(int i=0;i<blklen;i++)    /* i = 0,...,blklen-1 */
    {
        for(int j=0;j<16;j++)
        {
            enc[j] = src[16 * i + j] ^ inIV[j];     //lea 입력전 IV 와 xor
        }
        wflea_encryptblk_4bits(dec, enc, &ctx);     //암호화
        for(int j=0;j<16;j++)
        {
            (*dst)[16 * i + j] = dec[j];       
            inIV[j]= dec[j];                  //IV 갱신
        }
    }
}

/* 
 * 기능 : CBC LEA 복호화 (non wb)
 * 입력 : 메시지, IV, 메시지 길이, 키를 입력받아 CBC LEA 복호화 진행
 * 출력 : 없음
 */
void IN_CBC_LEA(byte* dst, const byte* src, byte* IV, const int srclen, byte* key)
{
    WFLEA_CTX ctx;
    wflea_gen_ctx(&ctx, 128, key); 

    int blklen = srclen/16;

    byte dec[16] = {0x0,};  
    byte rec[16] = {0x0,}; 
    byte IV_in[16] = {0x0,};

    memcpy(IV_in,IV,16);

    for(int i=0;i<blklen;i++)    /* i = 0,...,blklen-1 */
    {
        for(int j=0;j<16;j++)
        {
            dec[j] = src[16 * i + j] ;  // 현재 암호문이 다음 라운드 iv가 되므로  
        }
        
        wflea_decryptblk_4bits(rec, dec, &ctx); //lea 복호화
        for(int j=0;j<16;j++)
        {
            dst[16 * i + j] = rec[j] ^ IV_in[j];      //IV와 xor 
            IV_in[j]= src[16 * i + j];                  //IV update
        }
    }
}

/* 
 * 기능 : 암호화에서 사용하는 8bit 입력 4bit 출력 xor 함수에 대한 테이블 생성
 * 입력 : 입력 인코더(4bit 치환 2개), 출력 인코더 (4bit 치환 1개) 를 이용하여 테이블 생성
 * 출력 : 없음
 */
void XOR_encoding_table(
            XOR_TABLE* tab,
            WBWFLEA_EXT_ENCODING* f,
            WBWFLEA_EXT_ENCODING* g,
            WBWFLEA_EXT_ENCODING* h)
{
    int i, j, l;
    
    for(i = 0; i < 4; i++)          //128bit는 32bit가 4개
    {   
        for(j = 0; j < 8; j++)      //32bit는 4bit 가 8개
        {
            for (l = 0; l < 256; l++)       //입력이 8bit이므로 256가지 경우
            {
                byte X = (l >> 4) & 0xf;
                byte Y = (l) & 0xf;
                byte Z = (f->f_inv[i][j][X])^(g->f[i][j][Y]);   //입력 인코더 적용

                tab->XOR[i][j][l] = h->f[i][j][Z];               //출력 인코더 적용
            }
        }
    }
}

/* 
 * 기능 : 복호화에서 사용하는 8bit 입력 4bit 출력 xor 함수에 대한 테이블 생성
 * 입력 : 입력 인코더(4bit 치환 2개), 출력 인코더 (4bit 치환 1개) 를 이용하여 테이블 생성
 * 출력 : 없음
 */
void XOR_decoding_table(
            XOR_TABLE* tab,
            WBWFLEA_EXT_ENCODING* f,
            WBWFLEA_EXT_ENCODING* g,
            WBWFLEA_EXT_ENCODING* h)
{
    int i, j, l;
    
    for(i = 0; i < 4; i++)      //128bit는 32bit가 4개
    {
        for(j = 0; j < 8; j++)  //32bit는 4bit 가 8개
        {
            for (l = 0; l < 256; l++)   //입력이 8bit이므로 256가지 경우
            {
                byte X = (l >> 4) & 0xf;
                byte Y = (l) & 0xf;
                byte Z = (f->f[i][j][X])^(g->f[i][j][Y]);   //입력 인코더 적용

                tab->XOR[i][j][l] = h->f_inv[i][j][Z];      //출력 인코더 적용            
            }
        }
    }
}


/* 
 * 기능 : vpmac에서 입력 인코더를 inverse로 넣기위해 만든 xor 테이블
 * 입력 : 입력 인코더(4bit 치환 2개), 출력 인코더 (4bit 치환 1개) 를 이용하여 테이블 생성
 * 출력 : 없음
 */
void cbc_gen_encoding_table(
            WBWFLEA_MAC_WK2* tab,
            WBWFLEA_EXT_ENCODING* f,
            WBWFLEA_EXT_ENCODING* g,
            WBWFLEA_EXT_ENCODING* h)
{
    int i, j, l;
    
    for(i = 0; i < 4; i++)
    {
        for(j = 0; j < 8; j++)
        {
            for (l = 0; l < 256; l++)
            {
                byte X = (l >> 4) & 0xf;
                byte Y = (l) & 0xf;
                byte Z = (f->f_inv[i][j][X])^(g->f[i][j][Y]);   //입력인코더의 역연산을 써야함.

                tab->XOR[i][j][l] = h->f[i][j][Z];                
            }
        }
    }

}

/* 
 * 기능 : WBCBC LEA 암호화  
 * 입력 : 메시지, wblea 테이블, xor 테이블, iv를 입력하여 wbcbc암호화
 * 출력 : 없음
 */
void WBCBC_LEA(int srclen, WBWFLEA_ENCRYPTION_TABLE* enc_tab, XOR_TABLE* cbc_ex_tab, byte* data, byte* IV)
{
    byte inIV[16]={0,};
    memcpy(inIV,IV,16);
    int blklen = srclen/16;                 // block length

    byte enc[16] = {0x0,};  

    for(int i=0;i<blklen;i++)    
    {
        for(int j=0;j<16;j++)
        {
            byte tmp = cbc_ex_tab->XOR[j/4][(2*j+1)%8   ][((( (data[16*i+j] >>4)&0xf)<<4 )^ ((inIV[j] >>4)&0xf) )];

            enc[j] = ((tmp & 0xf) << 4);

            enc[j] ^= cbc_ex_tab->XOR[j/4][(2*j)%8 ][(( (data[16*i+j]&0xf)<<4 )^ (inIV[j]&0xf)) ];  //xor 연산 테이블 처리
        }

        wbwflea_encryptwb(enc_tab, (byte*)enc);     //wblea

        for(int j=0;j<16;j++)
        {
            data[16*i+j] = enc[j];
            inIV[j]= enc[j];        //다음 블럭 iv 갱신
        }
    }

}

/* 
 * 기능 : WBCBC LEA 복호화  
 * 입력 : 메시지, wblea 테이블, xor 테이블, iv를 입력하여 wbcbc복호화
 * 출력 : 없음
 */
void Inv_WBCBC_LEA(const int srclen, WBWFLEA_DECRYPTION_TABLE* dec_tab, XOR_TABLE* cbc_ex_tab, byte* src, byte* IV)
{
    int blklen = srclen/16;                 // block length
    byte data[16] = {0x0,};  
    byte inIV[16]={0x0,};
    byte next_IV[16] = {0x0,};

    memcpy(inIV,IV,16);
    
    for(int i=0;i<blklen;i++)     // N-1 blk
    {
        for(int j=0;j<16;j++)
        {
            data[j]=src[16*i+j];        //다음 블럭 iv 갱신을 위함
            next_IV[j]=src[16*i+j];
        }
        wbwflea_decryptwb(dec_tab, (byte*)data);    //복호화
     
        for(int j=0;j<16;j++)
        {
            byte tmp = cbc_ex_tab->XOR[j/4][(2*j+1)%8   ][((( (data[j] >>4)&0xf)<<4 )^ ((inIV[j] >>4)&0xf) )];

            src[16*i+j] = ((tmp & 0xf) << 4);

            src[16*i+j] ^= cbc_ex_tab->XOR[j/4][(2*j)%8 ][(( (data[j]&0xf)<<4 )^ (inIV[j]&0xf)) ]; //xor 테이블 처리
        }

        for(int j=0;j<16;j++)
        {
            inIV[j]= next_IV[j];          //iv 갱신  
        }
    }
}
