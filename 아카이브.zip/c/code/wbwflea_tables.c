#include "wbwflea_tables.h"

/* 
 * 기능 : 암호화 키 테이블 파일에 쓰기
 * 입력 : 암호화 키 테이블 
 * 출력 : 없음
 */
void wbwflea_write_encryption_table(WBWFLEA_ENCRYPTION_TABLE* ctx, char* file_name)
{
    FILE* fp = fopen(file_name, "wb");
    if(fp != NULL)
    {
        fwrite(ctx, sizeof(WBWFLEA_ENCRYPTION_TABLE), 1, fp);
        fclose(fp);
    }
}

/* 
 * 기능 : 암호화 키 테이블 파일에서 읽기
 * 입력 : 암호화 키 테이블, 파일명
 * 출력 : 없음
 */
void wbwflea_read_encryption_table(WBWFLEA_ENCRYPTION_TABLE* ctx, char* file_name)
{
    FILE* fp = fopen(file_name, "rb");
    if(fp != NULL)
    {
        fread(ctx, sizeof(WBWFLEA_ENCRYPTION_TABLE), 1, fp);
		fclose(fp);
    }
}

/* 
 * 기능 : 복호화 키 테이블 파일에서 쓰기
 * 입력 : 복호화 키 테이블, 파일명
 * 출력 : 없음
 */
void wbwflea_write_decryption_table(WBWFLEA_DECRYPTION_TABLE* ctx, char* file_name)
{
    FILE* fp = fopen(file_name, "wb");
    if(fp != NULL)
    {
        fwrite(ctx, sizeof(WBWFLEA_DECRYPTION_TABLE), 1, fp);
        fclose(fp);
    }
}

/* 
 * 기능 : 복호화 키 테이블 파일에서 읽기
 * 입력 : 복호화 키 테이블, 파일명
 * 출력 : 없음
 */
void wbwflea_read_decryption_table(WBWFLEA_DECRYPTION_TABLE* ctx, char* file_name)
{
    FILE* fp = fopen(file_name, "rb");
    if(fp != NULL)
    {
        fread(ctx, sizeof(WBWFLEA_DECRYPTION_TABLE), 1, fp);
		fclose(fp);
    }
}

/* 
 * 기능 : 암호화 키 테이블 콘솔창에 프린트
 * 입력 : 암호화 키 테이블
 * 출력 : 없음
 */
void wbwflea_show_encryption_table(WBWFLEA_ENCRYPTION_TABLE* tab)
{
    int r, i, j, l;
    for(r = 0; r < WBWFLEA_ROUNDS; r++)
    {
        for(i = 0; i < 3; i++)
        {
            for(j = 0; j < 8; j++)
            {
                printf("ETA[%d][%d][%d]\n", r, i, j);   //ETA 먼저 출력
                for(l = 0; l < 512; l++)
                {
                    printf("%02x ", tab->ETA[r][i][j][l]);
                    if ((l+1)%16 == 0)
                        printf("\n");
                }

                printf("ETR[%d][%d][%d]\n", r, i, j);   //두번째 ETR 출력  
                for(l = 0; l < 256; l++)
                {
                    printf("%1x ", tab->ETR[r][i][j][l]);
                    if ((l+1)%16 == 0)
                        printf("\n");
                }
            }
        }
    }
}

/* 
 * 기능 : 복호화 키 테이블 콘솔창에 프린트
 * 입력 : 복호화 키 테이블
 * 출력 : 없음
 */
void wbwflea_show_decryption_table(WBWFLEA_DECRYPTION_TABLE* tab)
{
    int r, i, j, l;
    for(r = 0; r < WBWFLEA_ROUNDS; r++)
    {
        for(i = 0; i < 3; i++)
        {
            for(j = 0; j < 8; j++)
            {
                printf("DTR[%d][%d][%d]\n", r, i, j);
                for(l = 0; l < 256; l++)
                {
                    printf("%1x ", tab->DTR[r][i][j][l]);
                    if ((l+1)%16 == 0)
                        printf("\n");
                }

                printf("DTS[%d][%d][%d]\n", r, i, j);
                for(l = 0; l < 512; l++)
                {
                    printf("%02x ", tab->DTS[r][i][j][l]);
                    if ((l+1)%16 == 0)
                        printf("\n");
                }

            }
        }
    }
}

/* 
 * 기능 : 화이트박스 덧셈 연산
 * 입력 : 4bit 퍼뮤테이션, 1bit 퍼뮤테이션 , 키, 덧셈할 두 32bit 배열
 * 출력 : 없음
 */
void wbwflea_addwb(
        byte* cZ,
        byte u, byte v,
        byte* f0, byte* f1,
        byte* g,
        byte K0, byte K1,
        byte y, byte X0, byte X1)
{
    add(*cZ, (y ^ u), (f0[X0] ^ K0), (f1[X1] ^ K1));    //덧셈 입력전 인코딩
    *cZ = (((*cZ >> 4) ^ v) << 4) ^ g[(*cZ) & 0xf];     //덧셈 출력에 대해 인코딩
}

/* 
 * 기능 : 화이트박스 뺄셈 연산
 * 입력 : 4bit 퍼뮤테이션, 1bit 퍼뮤테이션 , 키, 뺄셈할 두 32bit 배열
 * 출력 : 없음
 */
void wbwflea_subwb(
        byte* bZ,
        byte u, byte v,
        byte* f0, byte* f1,
        byte* g,
        byte K0, byte K1,
        byte y, byte X0, byte X1)
{
    sub(*bZ, (y ^ u), f0[X0], (f1[X1] ^ K0));                   //뺄셈 전 인코딩하여 함수 입력
    *bZ = (((*bZ >> 4) ^ v) << 4) ^ (g[((*bZ) & 0xf) ^ K1]);     //뺄셈후 인코딩
}

/* 
 * 기능 : 화이트박스 왼쪽 회전
 * 입력 : 4bit 퍼뮤테이션, 키, 로테이션할 32bit 배열
 * 출력 : 없음
 */
void wbwflea_rolwb(byte* Z, byte l, byte* f, byte* g, byte* h, byte X, byte Y)
{
    rol(*Z, f[X], g[Y], l);
    *Z = h[*Z];
}

/* 
 * 기능 : 화이트박스 오른쪽 회전
 * 입력 : 4bit 퍼뮤테이션, 키, 로테이션할 32bit 배열
 * 출력 : 없음
 */
void wbwflea_rorwb(byte* Z, byte l, byte* f, byte* g, byte* h, byte X, byte Y)
{
    ror(*Z, f[X], g[Y], l);
    *Z = h[*Z];
}

/* 
 * 기능 : 암호화 테이블 생성
 * 입력 : 퍼뮤테이션 정보담은 구조체, 키정보 담은 구조체
 * 출력 : 없음
 */
void wbwflea_gen_encryption_table(
            WBWFLEA_ENCRYPTION_TABLE* tab,
            WBWFLEA_ENCODINGS_FOR_ENCRYPTION* enc_ctx, 
            WFLEA_CTX* wflea_ctx)
{
    int r, i, j, l;
    for (r = 0; r < WBWFLEA_ROUNDS; r++)
    {
        for(j = 0; j < 8; j++)
        {
            /* ETA */
            for(i = 0; i < 3; i++)
            {
                for (l = 0; l < 512; l++)       //덧셈은 9bit 입력
                {
                    byte c = (l >> 8) & 0x1;
                    byte X = (l >> 4) & 0xf;
                    byte Y = (l) & 0xf;
                    wbwflea_addwb(
                        &(tab->ETA[r][i][j][l]),
                        (j == 0) ? 0 : (enc_ctx->t[r][i] >> (j-1)) & 0x1,
                        (enc_ctx->t[r][i] >> j) & 0x1,
                        enc_ctx->f[r][i][j],
                        enc_ctx->f[r][i+1][j],
                        enc_ctx->g_inv[r][i][j],
                        (wflea_ctx->rndkey[r][2*i]     >> (4*j)) & 0xf,
                        (wflea_ctx->rndkey[r][2*i + 1] >> (4*j)) & 0xf,
                        c, X, Y);
                }
                
            }

            /* ETR */
            for (l = 0; l < 256; l++)       //회전은 8bit 입력
            {
                byte X = (l >> 4) & 0xf;
                byte Y = (l) & 0xf;

                wbwflea_rolwb(
                    &(tab->ETR[r][0][j][l]),
                    1,
                    enc_ctx->g[r][0][(j+6)%8],
                    enc_ctx->g[r][0][(j+5)%8],
                    enc_ctx->h[r][0][j],
                    X, Y);

                wbwflea_rorwb(
                    &(tab->ETR[r][1][j][l]),
                    1,
                    enc_ctx->g[r][1][(j+2)%8],
                    enc_ctx->g[r][1][(j+1)%8],
                    enc_ctx->h[r][1][j],
                    X, Y);

                wbwflea_rorwb(
                    &(tab->ETR[r][2][j][l]),
                    3,
                    enc_ctx->g[r][2][(j+1)%8],
                    enc_ctx->g[r][2][j],
                    enc_ctx->h[r][2][j],
                    X, Y);

            }
        }
    }
}

/* 
 * 기능 : 복호화 테이블 생성
 * 입력 : 퍼뮤테이션 정보담은 구조체, 키정보 담은 구조체
 * 출력 : 없음
 */

void wbwflea_gen_decryption_table(
            WBWFLEA_DECRYPTION_TABLE* tab,
            WBWFLEA_ENCODINGS_FOR_DECRYPTION* dec_ctx, 
            WFLEA_CTX* wflea_ctx)
{
    int r, j, l;
    for (r = 0; r < WBWFLEA_ROUNDS; r++)
    {
        for(j = 0; j < 8; j++)
        {
            /* DTR */
            for (l = 0; l < 256; l++)       //회전은 8bit 입력
            {   
                byte X = (l >> 4) & 0xf;
                byte Y = (l) & 0xf;

                wbwflea_rorwb(
                    &(tab->DTR[r][0][j][l]),
                    1,
                    dec_ctx->f[r][0][(j+3)%8],
                    dec_ctx->f[r][0][(j+2)%8],
                    dec_ctx->g_inv[r][0][j],
                    X, Y);

                wbwflea_rolwb(
                    &(tab->DTR[r][1][j][l]),
                    1,
                    dec_ctx->f[r][1][(j+7)%8],
                    dec_ctx->f[r][1][(j+6)%8],
                    dec_ctx->g_inv[r][1][j],
                    X, Y);

                wbwflea_rolwb(
                    &(tab->DTR[r][2][j][l]),
                    3,
                    dec_ctx->f[r][2][j],
                    dec_ctx->f[r][2][(j+7)%8],
                    dec_ctx->g_inv[r][2][j],
                    X, Y);

            }

            /* DTS */
            for (l = 0; l < 512; l++)       //뺄셈은 9bit 입력
            {
                byte b = (l >> 8) & 0x1;
                byte X = (l >> 4) & 0xf;
                byte Y = (l) & 0xf;

                wbwflea_subwb(
                    &(tab->DTS[r][0][j][l]),
                    (j == 0) ? 0 : (dec_ctx->t[r][0] >> (j-1)) & 0x1,
                    (dec_ctx->t[r][0] >> j) & 0x1,
                    dec_ctx->g[r][0][j],
                    dec_ctx->h[r][0][j],
                    dec_ctx->h[r][1][j],
                    (wflea_ctx->rndkey[WBWFLEA_ROUNDS - 1 - r][0] >> (4*j)) & 0xf,
                    (wflea_ctx->rndkey[WBWFLEA_ROUNDS - 1 - r][1] >> (4*j)) & 0xf,
                    b, X, Y);


                wbwflea_subwb(
                    &(tab->DTS[r][1][j][l]),
                    (j == 0) ? 0 : (dec_ctx->t[r][1] >> (j-1)) & 0x1,
                    (dec_ctx->t[r][1] >> j) & 0x1,
                    dec_ctx->g[r][1][j],
                    dec_ctx->h_inv[r][1][j],
                    dec_ctx->h[r][2][j],
                    (wflea_ctx->rndkey[WBWFLEA_ROUNDS - 1 - r][2] >> (4*j)) & 0xf,
                    (wflea_ctx->rndkey[WBWFLEA_ROUNDS - 1 - r][3] >> (4*j)) & 0xf,
                    b, X, Y);


                wbwflea_subwb(
                    &(tab->DTS[r][2][j][l]),
                    (j == 0) ? 0 : (dec_ctx->t[r][2] >> (j-1)) & 0x1,
                    (dec_ctx->t[r][2] >> j) & 0x1,
                    dec_ctx->g[r][2][j],
                    dec_ctx->h_inv[r][2][j],
                    dec_ctx->h[r][3][j],
                    (wflea_ctx->rndkey[WBWFLEA_ROUNDS - 1 - r][4] >> (4*j)) & 0xf,
                    (wflea_ctx->rndkey[WBWFLEA_ROUNDS - 1 - r][5] >> (4*j)) & 0xf,
                    b, X, Y);
            }
        }
    }
}



/* 
 * 기능 : VPMAC에서 WK2 생성. enctable 생성과 구조는 같으나 라운드수가 다름.
 * 입력 : 퍼뮤테이션 정보담은 구조체, 키정보 담은 구조체
 * 출력 : 없음
 */

void wbwflea_gen_MAC_enc_tablefirst(
            WBWFLEA_MAC_WK2* tab,
            WBWFLEA_ENCODINGS_FOR_MACfirst* enc_ctx, 
            WFLEA_CTX* wflea_ctx)
{
    int r, i, j, l;
    for (r = 0; r < Table1; r++)
    {
        for(j = 0; j < 8; j++)
        {
            /* ETA */
            for(i = 0; i < 3; i++)
            {
                for (l = 0; l < 512; l++)
                {
                    byte c = (l >> 8) & 0x1;
                    byte X = (l >> 4) & 0xf;
                    byte Y = (l) & 0xf;
                    wbwflea_addwb(
                        &(tab->ETA[r][i][j][l]),
                        (j == 0) ? 0 : (enc_ctx->t[r][i] >> (j-1)) & 0x1,
                        (enc_ctx->t[r][i] >> j) & 0x1,
                        enc_ctx->f[r][i][j],
                        enc_ctx->f[r][i+1][j],
                        enc_ctx->g_inv[r][i][j],
                        (wflea_ctx->rndkey[r][2*i]     >> (4*j)) & 0xf,
                        (wflea_ctx->rndkey[r][2*i + 1] >> (4*j)) & 0xf,
                        c, X, Y);
                }
                
            }

            /* ETR */
            for (l = 0; l < 256; l++)
            {
                byte X = (l >> 4) & 0xf;
                byte Y = (l) & 0xf;

                wbwflea_rolwb(
                    &(tab->ETR[r][0][j][l]),
                    1,
                    enc_ctx->g[r][0][(j+6)%8],
                    enc_ctx->g[r][0][(j+5)%8],
                    enc_ctx->h[r][0][j],
                    X, Y);

                wbwflea_rorwb(
                    &(tab->ETR[r][1][j][l]),
                    1,
                    enc_ctx->g[r][1][(j+2)%8],
                    enc_ctx->g[r][1][(j+1)%8],
                    enc_ctx->h[r][1][j],
                    X, Y);

                wbwflea_rorwb(
                    &(tab->ETR[r][2][j][l]),
                    3,
                    enc_ctx->g[r][2][(j+1)%8],
                    enc_ctx->g[r][2][j],
                    enc_ctx->h[r][2][j],
                    X, Y);

            }
        }
    }
}

/* 
 * 기능 : VPMAC에서 WK1 생성. enctable 생성과 구조는 같으나 라운드수가 다름.
 * 입력 : 퍼뮤테이션 정보담은 구조체, 키정보 담은 구조체
 * 출력 : 없음
 */
void wbwflea_gen_MAC_enc_tablemid(
            WBWFLEA_MAC_WK1* tab,
            WBWFLEA_ENCODINGS_FOR_MACMID* enc_ctx, 
            WFLEA_CTX* wflea_ctx)
{
    int r, i, j, l;
    for (r = 0; r < WBWFLEA_ROUNDS-Table2-Table1; r++)
    {
        for(j = 0; j < 8; j++)
        {
            /* ETA */
            for(i = 0; i < 3; i++)
            {
                for (l = 0; l < 512; l++)
                {
                    byte c = (l >> 8) & 0x1;
                    byte X = (l >> 4) & 0xf;
                    byte Y = (l) & 0xf;
                    wbwflea_addwb(
                        &(tab->ETA[r][i][j][l]),
                        (j == 0) ? 0 : (enc_ctx->t[r][i] >> (j-1)) & 0x1,
                        (enc_ctx->t[r][i] >> j) & 0x1,
                        enc_ctx->f[r][i][j],
                        enc_ctx->f[r][i+1][j],
                        enc_ctx->g_inv[r][i][j],
                        (wflea_ctx->rndkey[r+Table1][2*i]     >> (4*j)) & 0xf,
                        (wflea_ctx->rndkey[r+Table1][2*i + 1] >> (4*j)) & 0xf,
                        c, X, Y);
                }
                
            }

            /* ETR */
            for (l = 0; l < 256; l++)
            {
                byte X = (l >> 4) & 0xf;
                byte Y = (l) & 0xf;

                wbwflea_rolwb(
                    &(tab->ETR[r][0][j][l]),
                    1,
                    enc_ctx->g[r][0][(j+6)%8],
                    enc_ctx->g[r][0][(j+5)%8],
                    enc_ctx->h[r][0][j],
                    X, Y);

                wbwflea_rorwb(
                    &(tab->ETR[r][1][j][l]),
                    1,
                    enc_ctx->g[r][1][(j+2)%8],
                    enc_ctx->g[r][1][(j+1)%8],
                    enc_ctx->h[r][1][j],
                    X, Y);

                wbwflea_rorwb(
                    &(tab->ETR[r][2][j][l]),
                    3,
                    enc_ctx->g[r][2][(j+1)%8],
                    enc_ctx->g[r][2][j],
                    enc_ctx->h[r][2][j],
                    X, Y);

            }
        }
    }
}


/* 
 * 기능 : VPMAC에서 WK1 생성. enctable 생성과 구조는 같으나 라운드수가 다름.
 * 입력 : 퍼뮤테이션 정보담은 구조체, 키정보 담은 구조체
 * 출력 : 없음
 */

void wbwflea_gen_MAC_enc_tableend(
            WBWFLEA_MAC_WK2* tab,
            WBWFLEA_ENCODINGS_FOR_MACend* enc_ctx, 
            WFLEA_CTX* wflea_ctx)
{
    int r, i, j, l;
    for (r = 0; r < Table2; r++)
    {
        for(j = 0; j < 8; j++)
        {
            /* ETA */
            for(i = 0; i < 3; i++)
            {
                for (l = 0; l < 512; l++)
                {
                    byte c = (l >> 8) & 0x1;
                    byte X = (l >> 4) & 0xf;
                    byte Y = (l) & 0xf;
                    wbwflea_addwb(
                        &(tab->ETA[r+Table1][i][j][l]),
                        (j == 0) ? 0 : (enc_ctx->t[r][i] >> (j-1)) & 0x1,
                        (enc_ctx->t[r][i] >> j) & 0x1,
                        enc_ctx->f[r][i][j],
                        enc_ctx->f[r][i+1][j],
                        enc_ctx->g_inv[r][i][j],
                        (wflea_ctx->rndkey[r+MIDTable+Table1][2*i]     >> (4*j)) & 0xf,
                        (wflea_ctx->rndkey[r+MIDTable+Table1][2*i + 1] >> (4*j)) & 0xf,
                        c, X, Y);

                }
                
            }

            /* ETR */
            for (l = 0; l < 256; l++)
            {
                byte X = (l >> 4) & 0xf;
                byte Y = (l) & 0xf;

                wbwflea_rolwb(
                    &(tab->ETR[r+Table1][0][j][l]),
                    1,
                    enc_ctx->g[r][0][(j+6)%8],
                    enc_ctx->g[r][0][(j+5)%8],
                    enc_ctx->h[r][0][j],
                    X, Y);

                wbwflea_rorwb(
                    &(tab->ETR[r+Table1][1][j][l]),
                    1,
                    enc_ctx->g[r][1][(j+2)%8],
                    enc_ctx->g[r][1][(j+1)%8],
                    enc_ctx->h[r][1][j],
                    X, Y);

                wbwflea_rorwb(
                    &(tab->ETR[r+Table1][2][j][l]),
                    3,
                    enc_ctx->g[r][2][(j+1)%8],
                    enc_ctx->g[r][2][j],
                    enc_ctx->h[r][2][j],
                    X, Y);

            }
        }
    }
}