#ifndef _RANDOM_PERMUTATION_H_
#define _RANDOM_PERMUTATION_H_

/**
 * @file    randperm.h
 * @brief   4-bit/1-bit random permutation generation
 * @author  FDL @ KMU
 * @version 2022.06.06.
 */

#include "wflea.h"
#include "lea128.h"
#include "wbwflea_ext_transform.h"

/**
 * @brief 4-bit shuffle (Fisher-Yates shuffling)
 * @param x     (output/input) 16-byte array
 */
void shuffle_4bits(byte* x);

void get_inv_map_4bits(byte* dst, const byte* src);

/**
 * @brief generate random 4-bit permutation and its inverse
 * @param map       (output) 16-byte array
 * @param map_inv   (output) 16-byte array
 */
void gen_randperm_4bits(byte* map, byte* map_inv);
/**
 * @brief generate 8 random 1-bit permutations (equivalently gnerate random 8-bit)
 * @param map       (output) 1-byte array
 */
void gen_randperm_1bits(byte* map);

void show_perm_4bits(byte* map);
void show_32bit_perm_4bits(byte map[8][16], byte map_inv[8][16]);

void set_identity_4bits(byte* map, byte* map_inv);
word transform_by_32bit_perm_4bits(word X, byte map[8][16]);

void init_perm_4bits(byte dst[16]);
void gen_randperm_4bits_w_16B(byte rdat[16], byte x[16], byte x_inv[16]);
void add_one(byte x[LEA128_BYTELEN_BLK]);
void XOR128(word dst[LEA128_WORDLEN_BLK], word src[LEA128_WORDLEN_BLK]);

void gen_rand_512B(byte dst[512], byte seed[32]);
void gen_randperm_128bits(WBWFLEA_EXT_ENCODING* ctx, byte seed[32]);



#endif   // _RANDOM_PERMUTATION_H_