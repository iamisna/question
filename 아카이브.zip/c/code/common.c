#include "common.h"


/* 
 * 기능 : 입력받은 word를 int로 변환
 * 입력파라미터 : word (4바이트열)
 * 함수 출력 : 바이트열을 int 변환한 값
 */
int Word_to_Int(byte *b)
{
    return ((((word)b[0])<<24)^(((word)b[1])<<16)^(((word)b[2])<<8)^(((word)b[3])));
}

/* 
 * 기능 : 입력받은 int를 word로 변환
 * 입력파라미터 : 정수 i
 * 출력파라미터 : int를 변환한 byte 값
 * 함수 출력 : 없음
 */
void Int_to_Word(byte *b,int i) 
{
    b[0] = (i>>24)&0xff;
    b[1] = (i>>16)&0xff;
    b[2] = (i>>8)&0xff;
    b[3] = i&0xff;    
}

/**
 * @brief Check if given two arrays are same.
 * @param src1  source1
 * @param src2  source2
 * @param size  byte size
 * @return  YES if equal, NO if not equal
 */
int is_equal_bytes(byte* src1, byte* src2, int size)
{
    int j;
    for (j = 0; j < size; j++)
    {
        if(src1[j] != src2[j])
        {
            //printf("not equal.\n");
            return NO;
        }
    }
    //printf("equal.\n");
    return YES;
}

/**
 * @brief generate random bytes with size using rand() function
 * @param dst   (output) byte array
 * @param size  (input) array size
 */
void gen_rand_bytes_using_randf(byte* dst, int size)
{
    int j;
    for (j = 0; j < size; j++)
        dst[j] = rand() & 0xff;
}

/**
 * @brief generate random bytes with size using drbg
 * @param dst   (output) byte array
 * @param size  (input) array size
 */
void gen_rand_bytes(byte* dst, int size)
{
    int j;
    for (j = 0; j < size; j++)
        //dst[j] = (214+j) & 0xff;        

        //dst[j] = drbg_get_randbyte() & 0xff;        
        dst[j] = rand() & 0xff;
}

/* 
 * 기능 : 입력받은 바이트를 프린트
 * 입력파라미터 : 배열, 배열의 크기
 * 출력파라미터 : 없음
 * 함수 출력 : 없음
 */
void show_bytes(byte* x, int size)
{
    int j;
	for (j = 0; j < size; j++)
        printf("%02x:", *(x + j));
    printf("\n");
}

/* 
 * 기능 : 입력받은 워드를 프린트
 * 입력파라미터 : 배열, 배열의 크기
 * 출력파라미터 : 없음
 * 함수 출력 : 없음
 */
void show_words(word* x, int size)
{
    int j;
	for (j = 0; j < size; j++)
        printf("%08x:", *(x + j));
    printf("\n");
}
