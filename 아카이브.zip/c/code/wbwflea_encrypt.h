#ifndef _WBWFLEA_ENCRYPT_H_
#define _WBWFLEA_ENCRYPT_H_

/**
 * @file    wbwflea_encrypt.h
 * @brief   Whitebox WF-LEA C code: Encryption/Decryption
 * @author  FDL @ KMU
 * @version 2022.06.06.
 */

#include "wbwflea_config.h"
#include "wbwflea_tables.h"

/* whitebox maps used in round function */
void wbwflea_ADDwb(word* Z, WBWFLEA_ENCRYPTION_TABLE* enc_tab, int r, int i, word X, word Y);
void wbwflea_SUBwb(word* Z, WBWFLEA_DECRYPTION_TABLE* dec_tab, int r, int i, word X, word Y);

void wbwflea_ROL9wb(word* Y, WBWFLEA_ENCRYPTION_TABLE* enc_tab, int r, word X);
void wbwflea_ROR9wb(word* Y, WBWFLEA_DECRYPTION_TABLE* dec_tab, int r, word X);

void wbwflea_ROR5wb(word* Y, WBWFLEA_ENCRYPTION_TABLE* enc_tab, int r, word X);
void wbwflea_ROL5wb(word* Y, WBWFLEA_DECRYPTION_TABLE* dec_tab, int r, word X);

void wbwflea_ROR3wb(word* Y, WBWFLEA_ENCRYPTION_TABLE* enc_tab, int r, word X);
void wbwflea_ROL3wb(word* Y, WBWFLEA_DECRYPTION_TABLE* dec_tab, int r, word X);

/**
 * @brief Whitebox WFLEA round function for encryption
 * @param enc_tab   (input) encryption table
 * @param r     	(input) round
 * @param X     	(input/output) 4-word data
 */
void wbwflea_roundwb(WBWFLEA_ENCRYPTION_TABLE* enc_tab, int r, word* X);
/**
 * @brief Whitebox WFLEA round function for decryption
 * @param dec_tab   (input) decryption table
 * @param r     	(input) round
 * @param X     	(input/output) 4-word data
 */
void wbwflea_invroundwb(WBWFLEA_DECRYPTION_TABLE* dec_tab, int r, word* X);

/**
 * @brief Whitebox WFLEA encryption
 * @param enc_tab   (input) encryption table
 * @param x     	(input/output) 16-byte data
 */
void wbwflea_encryptwb(WBWFLEA_ENCRYPTION_TABLE* enc_tab, byte* x);
/**
 * @brief Whitebox WFLEA decryption
 * @param enc_tab   (input) decryption table
 * @param x     	(input/output) 16-byte data
 */
void wbwflea_decryptwb(WBWFLEA_DECRYPTION_TABLE* dec_tab, byte* x);

/**
 * @brief Whitebox WFLEA encryption (debug mode: show each round state)
 * @param enc_tab   (input) encryption table
 * @param enc_ctx   (input) random encoding for encryption
 * @param x     	(input/output) 16-byte data
 */
void wbwflea_encryptwb_debug(
    WBWFLEA_ENCRYPTION_TABLE* enc_tab,
    WBWFLEA_ENCODINGS_FOR_ENCRYPTION* enc_ctx,
    byte* x);
/**
 * @brief Whitebox WFLEA decryption (debug mode: show each round state)
 * @param dec_tab   (input) decryption table
 * @param dec_ctx   (input) random encoding for decryption
 * @param x     	(input/output) 16-byte data
 */
void wbwflea_decryptwb_debug(
    WBWFLEA_DECRYPTION_TABLE* dec_tab, 
    WBWFLEA_ENCODINGS_FOR_DECRYPTION* dec_ctx,
    byte* x);

void wbwflea_show_words(word* x, int size);

void wbwflea_sep_encryptwb(WBWFLEA_MAC_WK1* wk1_tab, WBWFLEA_MAC_WK2* wk2_tab, byte* x);

void wbwflea_byte_roundwb(byte ETA[3][8][512], byte ETR[3][8][256], word* X);
void wbwflea_byte_ADDwb(word* Z, byte ETA[3][8][512],int i, word X, word Y);
void wbwflea_byte_ROL9wb(word* Y,byte ETR[3][8][256], word X);
void wbwflea_byte_ROR5wb(word* Y,  byte ETR[3][8][256], word X);
void wbwflea_byte_ROR3wb(word* Y,  byte ETR[3][8][256], word X);


#endif /* _WBWFLEA_ENCRYPT_H_ */