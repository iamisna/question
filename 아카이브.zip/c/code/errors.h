#ifndef _ERRORS_H_
#define _ERRORS_H_

/**
 * @file    errors.h
 * @brief   error messages
 * @author  FDL, RASE, X-Force
 * @version 2022.06.06.
 */

#define ERROR		0x00000000
#define NO_ERROR	0x00000001

#define ERR_INPUT	0x00010000
#define ERR_MEMORY	0x00020000

#define WBWFL_EXEC_0001    0x00000010
#define WBWFL_EXEC_0002    0x00000011
#define WBWFL_EXEC_0003    0x00000012
#define WBWFL_EXEC_0000    NO_ERROR

#define WBCBC_EXEC_0001    0x00000013
#define WBCBC_EXEC_0002    0x00000014
#define WBCBC_EXEC_0003    0x00000015
#define WBCBC_EXEC_0000    NO_ERROR

#define WBCTR_EXEC_0001    0x00000016
#define WBCTR_EXEC_0002    0x00000017
#define WBCTR_EXEC_0003    0x00000018
#define WBCTR_EXEC_0000    NO_ERROR

#define VPMAC_EXEC_0001    0x00000019
#define VPMAC_EXEC_0002    0x0000001a
#define VPMAC_EXEC_0003    0x0000001b
#define VPMAC_EXEC_0000    NO_ERROR

#endif   // _ERRORS_H_
