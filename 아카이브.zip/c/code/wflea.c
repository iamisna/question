#include <stdio.h>
#include <stdlib.h>
#include <memory.h>

#include "wflea.h"
#include "errors.h"
#include "sha256.h"

/* round constants used in LEA */
word delta[8] = {
	0xc3efe9db, 0x44626b02, 0x79e27c8a, 0x78df30ec, 
	0x715ea49e, 0xc785da0a, 0xe04ef22a, 0xe5c40957};

/* 
 * 기능 : 32bit 원소간 XOR를 4bit 단위로 진행   
 * 입력 : 두 32bit 원소
 * 출력 : 입력 원소간 xor 결과
 */
word XOR_4bits(word x, word y)
{
	word val = 0;
	int j;

	byte z = 0;
	for(j = 0; j < 8; j++)
	{
		xor(z, get_jth_nibble(x, j), get_jth_nibble(y, j));	
		val ^= (z << (4*j));
	}
	return val;
}

/* 
 * 기능 : 32bit 원소의 l비트 왼쪽 회전을 4bit 단위로 처리 
 * 입력 : 32bit 원소, 회전할 비트 수
 * 출력 : 입력 원소의 l비트 왼쪽 회전
 */
word ROL_4bits(word x, int l)
{
	word val = 0;
	int j;

	int q = l >> 2;
	int r = l & 0x3;

	byte z = 0;
	for(j = 0; j < 8; j++)
	{
		rol(z, get_jth_nibble(x, (8+j-q)%8), get_jth_nibble(x, (8+j-q-1)%8), r);
		val ^= (z << (4*j));
	}
	return val;
}


/* 
 * 기능 : 32bit 원소의 l비트 오른쪽 회전을 4bit 단위로 처리 
 * 입력 : 32bit 원소, 회전할 비트 수
 * 출력 : 입력 원소의 l비트 오른쪽 회전
 */
word ROR_4bits(word x, int l)
{
	word val = 0;
	int j;

	int q = l >> 2;
	int r = l & 0x3;

	byte z = 0;
	for(j = 0; j < 8; j++)
	{
		ror(z, get_jth_nibble(x, (j+q+1)%8), get_jth_nibble(x, (j+q)%8), r);
		val ^= (z << (4*j));
	}
	return val;
}

/* 
 * 기능 : 32bit 원소간 덧셈을 4bit 단위로 처리 
 * 입력 : 두 32bit 원소
 * 출력 : 입력 원소의 합
 */
word ADD_4bits(word src1, word src2)
{
	word val = 0;
	int j;

	byte z = 0;
	for (j = 0; j < 8; j++)
	{
		add(z, (z >> 4), get_jth_nibble(src1, j), get_jth_nibble(src2, j));
		val ^= ((z&0xf) << (4*j));
	}
	return val;
}

/* 
 * 기능 : 32bit 원소간 뺄셈을 4bit 단위로 처리 
 * 입력 : 두 32bit 원소
 * 출력 : 입력 원소의 차
 */
word SUB_4bits(word src1, word src2)
{
	word val = 0;
	int j;

	byte z = 0;
	for (j = 0; j < 8; j++)
	{
		sub(z, (z >> 4), get_jth_nibble(src1, j), get_jth_nibble(src2, j));
		val ^= ((z&0xf) << (4*j));
	}
	return val;
}

/* 
 * 기능 : wflea 동작에 필요한 정보를 담은 구조체 출력
 * 입력 : wflea 정보 담은 구조체
 * 출력 : 없음.
 */
void wflea_show_ctx(WFLEA_CTX* ctx)
{
	int j, r;

	printf("block bit length = %d\n", (ctx->blk_bytes)*8);
	printf("key bit length = %d\n", (ctx->key_bytes)*8);

	puts("[key]");
	for (j = 0; j < ctx->key_bytes; j++)
		printf("%02x:", *((ctx->key) + j));
	printf("\n");

	puts("[roundkeys]");
	for (r = 0; r < ctx->num_rounds; r++)
	{
		printf("[%02d] ", r);
		for (j = 0; j < ctx->rndkey_words; j++)
			printf("%08x:", *((ctx->rndkey[r]) + j));
		printf("\n");
	}
	/* Use the link below for correctness:
		http://extranet.cryptomathic.com/hashcalc/index
	*/
}

/* 
 * 기능 : wflea 동작에 필요한 정보를 담은 구조체 생성
 * 입력 : 키 길이, 키
 * 출력 : 잘못된 키길이 입력시 오류 메시지
 */
int wflea_gen_ctx(WFLEA_CTX* ctx, const int key_bits, const byte* key)
{
	/* fixed parameters */
	ctx->blk_bytes = 16;
	ctx->blk_words = 4;
	ctx->rndkey_bytes = 24;
	ctx->rndkey_words = 6;

	/* key set-up */
	switch(key_bits)
	{
		case 128:
			ctx->key_bytes = 16;
			ctx->num_rounds = 24;
			break;
		case 192:
			ctx->key_bytes = 24;
			ctx->num_rounds = 28;
			break;
		case 256:
			ctx->key_bytes = 32;
			ctx->num_rounds = 32;
			break;

		default:
			return ERR_INPUT;
	}
	memcpy(ctx->key, key, ctx->key_bytes);

#ifndef _WFLEA_			//wbwflea_config.h에서 설정. wflea로 설정한경우 키생성시 hash이용
	/* roundkey set-up */
	SHA256_CTX ct;
	int data_bytes = (ctx->key_bytes) + 1;
	byte data[WFLEA_MAX_KEY_BYTES + 1];

	byte digest[32]; /* hash value */

	int j;
	for (j = 0; j < ctx->num_rounds; j++)
	{
		memcpy(data, ctx->key, ctx->key_bytes);

		data[data_bytes - 1] = j + 1;

		sha256_init(&ct);
		sha256_update(&ct, data, data_bytes);
		sha256_final(&ct, digest);
		
		memcpy((byte*)(ctx->rndkey[j]), digest, ctx->rndkey_bytes);

	}
#endif

#ifndef _LEA_		//wbwflea_config.h에서 설정. lea로 설정한경우 키생성시 lea의 키생성 함수
	if(key_bits == 128)
	{
		word T[4];
		memcpy(T, ctx->key, ctx->key_bytes);

		int j;
		for (j = 0; j < ctx->num_rounds; j++)
		{
			T[0] = ROL((T[0] + ROL(delta[j%4], ((j+0)%32))), 1);
			T[1] = ROL((T[1] + ROL(delta[j%4], ((j+1)%32))), 3);
			T[2] = ROL((T[2] + ROL(delta[j%4], ((j+2)%32))), 6);
			T[3] = ROL((T[3] + ROL(delta[j%4], ((j+3)%32))), 11);

			ctx->rndkey[j][0] = T[0];
			ctx->rndkey[j][1] = T[1];
			ctx->rndkey[j][2] = T[2];
			ctx->rndkey[j][3] = T[1];
			ctx->rndkey[j][4] = T[3];
			ctx->rndkey[j][5] = T[1];
			
		}
	}

	if(key_bits == 192)
	{
		word T[6];
		memcpy(T, ctx->key, ctx->key_bytes);

		int j;
		for (j = 0; j < ctx->num_rounds; j++)
		{
			T[0] = ROL((T[0] + ROL(delta[j%6], ((j+0)%32))), 1);
			T[1] = ROL((T[1] + ROL(delta[j%6], ((j+1)%32))), 3);
			T[2] = ROL((T[2] + ROL(delta[j%6], ((j+2)%32))), 6);
			T[3] = ROL((T[3] + ROL(delta[j%6], ((j+3)%32))), 11);
			T[4] = ROL((T[4] + ROL(delta[j%6], ((j+4)%32))), 13);
			T[5] = ROL((T[5] + ROL(delta[j%6], ((j+5)%32))), 17);

			ctx->rndkey[j][0] = T[0];
			ctx->rndkey[j][1] = T[1];
			ctx->rndkey[j][2] = T[2];
			ctx->rndkey[j][3] = T[3];
			ctx->rndkey[j][4] = T[4];
			ctx->rndkey[j][5] = T[5];
		}
	}

	if(key_bits == 256)
	{
		word T[8];
		memcpy(T, ctx->key, ctx->key_bytes);

		int j;
		for (j = 0; j < ctx->num_rounds; j++)
		{
			T[(6*j+0)%8] = ROL((T[(6*j+0)%8] + ROL(delta[j%8], ((j+0)%32))), 1);
			T[(6*j+1)%8] = ROL((T[(6*j+1)%8] + ROL(delta[j%8], ((j+1)%32))), 3);
			T[(6*j+2)%8] = ROL((T[(6*j+2)%8] + ROL(delta[j%8], ((j+2)%32))), 6);
			T[(6*j+3)%8] = ROL((T[(6*j+3)%8] + ROL(delta[j%8], ((j+3)%32))), 11);
			T[(6*j+4)%8] = ROL((T[(6*j+4)%8] + ROL(delta[j%8], ((j+4)%32))), 13);
			T[(6*j+5)%8] = ROL((T[(6*j+5)%8] + ROL(delta[j%8], ((j+5)%32))), 17);

			ctx->rndkey[j][0] = T[(6*j+0)%8];
			ctx->rndkey[j][1] = T[(6*j+1)%8];
			ctx->rndkey[j][2] = T[(6*j+2)%8];
			ctx->rndkey[j][3] = T[(6*j+3)%8];
			ctx->rndkey[j][4] = T[(6*j+4)%8];
			ctx->rndkey[j][5] = T[(6*j+5)%8];
		}
	}

#endif

	return NO_ERROR;
}

/* 
 * 기능 : 배열의 원소를 프린트
 * 입력 : 배열, 배열의 크기
 * 출력 : 없음
 */
void wflea_show_words(word* x, int size)
{
    int j;
	for (j = 0; j < size; j++)
        printf("%08x:", *(x + j));
    printf("\n");
}

/* 
 * 기능 : 입력받은 라운드키를 이용하여 wflea의 암호화 라운드 함수 진행
 * 입력 : 128bit 원소, 라운드 키
 * 출력 : 없음
 */
void wflea_round(word* x, const word* rndkey)
{
	word T;
	T = x[0];
	x[0] = ROL(ADD(XOR(x[0], rndkey[0]), XOR(x[1], rndkey[1])), 9);
	x[1] = ROR(ADD(XOR(x[1], rndkey[2]), XOR(x[2], rndkey[3])), 5);
	x[2] = ROR(ADD(XOR(x[2], rndkey[4]), XOR(x[3], rndkey[5])), 3);
	x[3] = T;
	//printf("[] " ); wflea_show_words((word*)x, 4);

}


/* 
 * 기능 : 입력받은 라운드키를 이용하여 wflea의 암호화 라운드 함수를 4bit단위 연산 함수로 진행
 * 입력 : 128bit 원소, 라운드 키
 * 출력 : 없음
 */
void wflea_round_4bits(word* x, const word* rndkey)
{
	word T;
	T = x[0];
	x[0] = ROL_4bits(ADD_4bits(XOR_4bits(x[0], rndkey[0]), XOR_4bits(x[1], rndkey[1])), 9);
	x[1] = ROR_4bits(ADD_4bits(XOR_4bits(x[1], rndkey[2]), XOR_4bits(x[2], rndkey[3])), 5);
	x[2] = ROR_4bits(ADD_4bits(XOR_4bits(x[2], rndkey[4]), XOR_4bits(x[3], rndkey[5])), 3);
	x[3] = T;
}


/* 
 * 기능 : 입력받은 라운드키를 이용하여 wflea의 복호화 라운드 함수 진행
 * 입력 : 128bit 원소, 라운드 키
 * 출력 : 없음
 */
void wflea_round_inv(word* x, const word* rndkey)
{
	word T;
	T = x[3];
	x[0] = XOR(SUB(ROR(x[0], 9), XOR(x[3], rndkey[0])), rndkey[1]);
	x[1] = XOR(SUB(ROL(x[1], 5), XOR(x[0], rndkey[2])), rndkey[3]);
	x[2] = XOR(SUB(ROL(x[2], 3), XOR(x[1], rndkey[4])), rndkey[5]);
	x[3] = x[2]; x[2] = x[1]; x[1] = x[0]; x[0] = T;
}

/* 
 * 기능 : 입력받은 라운드키를 이용하여 wflea의 복호화 라운드 함수를 4bit단위 연산 함수로 진행
 * 입력 : 128bit 원소, 라운드 키
 * 출력 : 없음
 */
void wflea_round_inv_4bits(word* x, const word* rndkey)
{
	word T;
	T = x[3];
	x[0] = XOR_4bits(SUB_4bits(ROR_4bits(x[0], 9), XOR_4bits(x[3], rndkey[0])), rndkey[1]);
	x[1] = XOR_4bits(SUB_4bits(ROL_4bits(x[1], 5), XOR_4bits(x[0], rndkey[2])), rndkey[3]);
	x[2] = XOR_4bits(SUB_4bits(ROL_4bits(x[2], 3), XOR_4bits(x[1], rndkey[4])), rndkey[5]);
	x[3] = x[2]; x[2] = x[1]; x[1] = x[0]; x[0] = T;
}

/* 
 * 기능 : wflea의 전체 암호연산
 * 입력 : 평문, wflea 구조체
 * 출력 : 없음
 */
void wflea_encryptblk(byte* dst, const byte* src, const WFLEA_CTX* ctx)
{
	int j;
	memcpy(dst, src, ctx->blk_bytes);
	for (j = 0; j < ctx->num_rounds; j++)
		wflea_round((word*)dst, ctx->rndkey[j]);
}

/* 
 * 기능 : wflea의 전체 암호연산 및 라운드별 출력 프린트
 * 입력 : 평문, wflea 구조체
 * 출력 : 없음
 */
void wflea_encryptblk_debug(byte* dst, const byte* src, const WFLEA_CTX* ctx)
{
	int j;
	memcpy(dst, src, ctx->blk_bytes);
	for (j = 0; j < ctx->num_rounds; j++)
	{
		wflea_round((word*)dst, ctx->rndkey[j]);
		printf("[%2d] ", j); wflea_show_words((word*)dst, 4);
	}
}

/* 
 * 기능 : wflea의 전체 암호연산을 4bit 연산 함수로 수행
 * 입력 : 평문, wflea 구조체
 * 출력 : 없음
 */
void wflea_encryptblk_4bits(byte* dst, const byte* src, const WFLEA_CTX* ctx)
{
	int j;
	memcpy(dst, src, ctx->blk_bytes);
	for (j = 0; j < ctx->num_rounds; j++)
	{
		wflea_round_4bits((word*)dst, ctx->rndkey[j]);
		//printf("[%2d] ", j); wflea_show_words((word*)dst, 4);
	}
}

/* 
 * 기능 : wflea의 전체 복호연산
 * 입력 : 평문, wflea 구조체
 * 출력 : 없음
 */
void wflea_decryptblk(byte* dst, const byte* src, const WFLEA_CTX* ctx)
{
	int j;
	memcpy(dst, src, ctx->blk_bytes);
	for (j = 0; j < ctx->num_rounds; j++)
		wflea_round_inv((word*)dst, ctx->rndkey[ctx->num_rounds - 1 - j]);
}

/* 
 * 기능 : wflea의 전체 복호연산 및 라운드별 출력 프린트
 * 입력 : 평문, wflea 구조체
 * 출력 : 없음
 */
void wflea_decryptblk_debug(byte* dst, const byte* src, const WFLEA_CTX* ctx)
{
	int j;
	memcpy(dst, src, ctx->blk_bytes);
	for (j = 0; j < ctx->num_rounds; j++)
	{
		wflea_round_inv((word*)dst, ctx->rndkey[ctx->num_rounds - 1 - j]);
		printf("[%2d] ", j); wflea_show_words((word*)dst, 4);
	}
}

/* 
 * 기능 : wflea의 전체 복호연산을 4bit 연산 함수로 수행
 * 입력 : 평문, wflea 구조체
 * 출력 : 없음
 */
void wflea_decryptblk_4bits(byte* dst, const byte* src, const WFLEA_CTX* ctx)
{
	int j;
	memcpy(dst, src, ctx->blk_bytes);
	for (j = 0; j < ctx->num_rounds; j++)
	{
		wflea_round_inv_4bits((word*)dst, ctx->rndkey[ctx->num_rounds - 1 - j]);
		//printf("[%2d] ", j); wflea_show_words((word*)dst, 4);
	}
}