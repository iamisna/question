#ifndef _WBWFLEA_EXT_TRANSFORM_H_
#define _WBWFLEA_EXT_TRANSFORM_H_

/**
 * @file    wbwflea_ext_transform.h
 * @brief   Whitebox WF-LEA C code: External encoding
 * @author  FDL @ KMU
 * @version 2022.06.06.
 */

#include "wflea.h"

typedef struct {
    /*
        f: input(or output) encoding
            f = (f[0], f[1], f[2], f[3])
            f[i] = diag(f[i][7],...,f[i][0])    i = 0,1,2,3
            f[i][j]: 4-bit permutation          j = 0,1,2,3,4,5,6,7
    */
    byte f[4][8][16];
    byte f_inv[4][8][16];
} WBWFLEA_EXT_ENCODING;

/**
 * @brief generate external encoding
 * @param ctx	(output) external encoding
 */
void wbwflea_gen_ext_encoding(WBWFLEA_EXT_ENCODING* ctx);

void wbwflea_gen_ext_identity_encoding(WBWFLEA_EXT_ENCODING* ctx);        //TEST

void wbwflea_show_ext_encoding(WBWFLEA_EXT_ENCODING* ctx);

/**
 * @brief Whitebox WFLEA external encoding
 * @param x     (input/output) state
 * @param ctx	(input) external encoding
 * @param flag	(input) do f if flag = 0, do f_inv if flag != 0
 */
void wbwflea_ext_transform(WBWFLEA_EXT_ENCODING* ctx, word* X, int flag);

/**
 * @brief generate binary file of Whitebox WFLEA external encoding
 * @param ctx	    (input) external encoding
 * @param file_name	(input) target binary file name
 */
void wbwflea_write_ext_encoding(WBWFLEA_EXT_ENCODING* ctx, char* file_name);
/**
 * @brief load binary file of Whitebox WFLEA external encoding
 * @param ctx	    (output) external encoding
 * @param file_name	(input) target binary file name
 */
void wbwflea_read_ext_encoding(WBWFLEA_EXT_ENCODING* ctx, char* file_name);

#endif /* _WBWFLEA_EXT_TRANSFORM_H_ */