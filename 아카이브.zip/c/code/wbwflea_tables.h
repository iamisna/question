#ifndef _WBWFLEA_TABLES_H_
#define _WBWFLEA_TABLES_H_

/**
 * @file    wbwflea_tables.h
 * @brief   Whitebox WF-LEA C code: Table generation
 * @author  FDL @ KMU
 * @version 2022.06.06. (<-2020.02.10.)
 */

#include "wflea.h"
#include "wbwflea_config.h"
#include "wbwflea_encodings.h"
#include "wbwfleamac_encoding.h"

typedef struct {
    byte ETA[WBWFLEA_ROUNDS][3][8][512];
    byte ETR[WBWFLEA_ROUNDS][3][8][256];
} WBWFLEA_ENCRYPTION_TABLE;

typedef struct {
    byte DTR[WBWFLEA_ROUNDS][3][8][256];
    byte DTS[WBWFLEA_ROUNDS][3][8][512];
} WBWFLEA_DECRYPTION_TABLE;

typedef struct {
    byte ETA[Table1][3][8][512];
    byte ETR[Table1][3][8][256];
} WBWFLEA_MAC_FIRST_TABLE;

typedef struct {
    byte ETA[MIDTable][3][8][512];
    byte ETR[MIDTable][3][8][256];
} WBWFLEA_MAC_WK1;          //�̸����� cnrk

typedef struct {
    byte ETA[Table1+Table2][3][8][512];
    byte ETR[Table1+Table2][3][8][256];  
    byte XOR[4][8][256];            //XOR 
    byte IV[16];                    //IV > WK2
} WBWFLEA_MAC_WK2;

/**
 * @brief Whiteboxed 4-bit modular addition
 * @param cZ    (output) c||Z
 * @param u     (input) input carry random encoding map (1-bit)
 * @param v     (input) output carry random encoding map (1-bit)
 * @param f0    (input) X0 random encoding map (4-bit)
 * @param f1    (input) X1 random encoding map (4-bit)
 * @param g     (input) output random encoding map (4-bit)
 * @param K0    (input) 4-bit roundkey
 * @param K1    (input) 4-bit roundkey
 * @param y     (input) 1-bit carry
 * @param X0    (input) 4-bit data
 * @param X1    (input) 4-bit data
 */
void wbwflea_addwb(
        byte* cZ,
        byte u, byte v,
        byte* f0, byte* f1,
        byte* g,
        byte K0, byte K1,
        byte y, byte X0, byte X1);

/**
 * @brief Whiteboxed 4-bit modular subtraction
 * @param bZ    (output) b||Z
 * @param u     (input) input borrow random encoding map (1-bit)
 * @param v     (input) output borrow random encoding map (1-bit)
 * @param f0    (input) X0 random encoding map (4-bit)
 * @param f1    (input) X1 random encoding map (4-bit)
 * @param g     (input) output random encoding map (4-bit)
 * @param K0    (input) 4-bit roundkey
 * @param K1    (input) 4-bit roundkey
 * @param y     (input) 1-bit borrow
 * @param X0    (input) 4-bit data
 * @param X1    (input) 4-bit data
 */
void wbwflea_subwb(
        byte* bZ,
        byte u, byte v,
        byte* f0, byte* f1,
        byte* g,
        byte K0, byte K1,
        byte y, byte X0, byte X1);

/**
 * @brief Whiteboxed 4-bit left rotation
 * @param Z     (output) b||Z
 * @param l     (input) rotation constant: l = 1 or 2 or 3
 * @param f     (input) X random encoding map (4-bit)
 * @param g     (input) Y random encoding map (4-bit)
 * @param h     (input) output random encoding map (4-bit)
 * @param X     (input) 4-bit data
 * @param Y     (input) 4-bit data
 */
void wbwflea_rolwb(byte* Z, byte l, byte* f, byte* g, byte* h, byte X, byte Y);
/**
 * @brief Whiteboxed 4-bit right rotation
 * @param Z     (output) b||Z
 * @param l     (input) rotation constant: l = 1 or 2 or 3
 * @param f     (input) X random encoding map (4-bit)
 * @param g     (input) Y random encoding map (4-bit)
 * @param h     (input) output random encoding map (4-bit)
 * @param X     (input) 4-bit data
 * @param Y     (input) 4-bit data
 */
void wbwflea_rorwb(byte* Z, byte l, byte* f, byte* g, byte* h, byte X, byte Y);

/**
 * @brief Encryption table generation for Whitebox WFLEA
 * @param tab       (output) encryption table
 * @param enc_ctx   (input) random encodings
 * @param wflea_ctx (input) WFLEA context (roundkeys)
 */
void wbwflea_gen_encryption_table(
            WBWFLEA_ENCRYPTION_TABLE* tab,
            WBWFLEA_ENCODINGS_FOR_ENCRYPTION* enc_ctx, 
            WFLEA_CTX* wflea_ctx);
/**
 * @brief Decryption table generation for Whitebox WFLEA
 * @param tab       (output) decryption table
 * @param enc_ctx   (input) random encodings
 * @param wflea_ctx (input) WFLEA context (roundkeys)
 */
void wbwflea_gen_decryption_table(
            WBWFLEA_DECRYPTION_TABLE* tab,
            WBWFLEA_ENCODINGS_FOR_DECRYPTION* dec_ctx, 
            WFLEA_CTX* wflea_ctx);

/**
 * @brief write encryption table as binary
 * @param ctx       (input) encryption table
 * @param file_name (input) target file name
 */
void wbwflea_write_encryption_table(WBWFLEA_ENCRYPTION_TABLE* ctx, char* file_name);
/**
 * @brief load encryption table from binary
 * @param ctx       (output) encryption table
 * @param file_name (input) target file name
 */
void wbwflea_read_encryption_table(WBWFLEA_ENCRYPTION_TABLE* ctx, char* file_name);

/**
 * @brief write decryption table as binary
 * @param ctx       (input) decryption table
 * @param file_name (input) target file name
 */
void wbwflea_write_decryption_table(WBWFLEA_DECRYPTION_TABLE* ctx, char* file_name);
/**
 * @brief load decryption table from binary
 * @param ctx       (output) decryption table
 * @param file_name (input) target file name
 */
void wbwflea_read_decryption_table(WBWFLEA_DECRYPTION_TABLE* ctx, char* file_name);

void wbwflea_show_encryption_table(WBWFLEA_ENCRYPTION_TABLE* tab);
void wbwflea_show_decryption_table(WBWFLEA_DECRYPTION_TABLE* tab);



void wbwflea_gen_MAC_enc_tablefirst(
            WBWFLEA_MAC_WK2* tab,
            WBWFLEA_ENCODINGS_FOR_MACfirst* enc_ctx, 
            WFLEA_CTX* wflea_ctx);


void wbwflea_gen_MAC_enc_tablemid(
            WBWFLEA_MAC_WK1* tab,
            WBWFLEA_ENCODINGS_FOR_MACMID* enc_ctx, 
            WFLEA_CTX* wflea_ctx);

void wbwflea_gen_MAC_enc_tableend(
            WBWFLEA_MAC_WK2* tab,
            WBWFLEA_ENCODINGS_FOR_MACend* enc_ctx, 
            WFLEA_CTX* wflea_ctx);



#endif /* _WBWFLEA_TABLES_H_ */