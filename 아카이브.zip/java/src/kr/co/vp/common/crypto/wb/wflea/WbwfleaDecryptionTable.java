/**
 * @file    WbwfleaDecryptionTable.java
 * @brief   WbwfleaDecryptionTable
 * @author  FDL @ KMU
 * @date    2022.08.07.
 */
package kr.co.vp.common.crypto.wb.wflea;

public class WbwfleaDecryptionTable {
    public WbwfleaDecryptionTable(WbwfleaConfig config){
        this.wbwfleaRounds = config.getROUNDS();
        this.DTR = new byte[wbwfleaRounds][3][8][256];
        this.DTS = new byte[wbwfleaRounds][3][8][512];
    }
    WbwfleaDecryptionTable(WbwfleaEncodingsForDecryption decCtx){
        this.wbwfleaRounds = decCtx.getWbwfleaRounds();
        this.DTR = new byte[wbwfleaRounds][3][8][256];
        this.DTS = new byte[wbwfleaRounds][3][8][512];
    }
    public int wbwfleaRounds;
    public byte[][][][] DTR;
    public byte[][][][] DTS;
}
