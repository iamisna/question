/**
 * @file    wbwfleaEncodingsForMacmid.java
 * @brief   wbwfleaEncodingsForMacmid
 * @author  FDL @ KMU
 * @version 2022.08.07.
 */
package kr.co.vp.common.crypto.wb.mac;

import kr.co.vp.common.crypto.wb.wflea.WbwfleaConfig;

public class wbwfleaEncodingsForMacmid {
    public wbwfleaEncodingsForMacmid(WbwfleaConfig config){
        this.rounds = config.getROUNDS();
        this.Table1 = config.getTable1();
        this.Table2 = config.getTable2();
        this.MIDTable = config.getMIDTable();

        this.f = new byte[rounds - Table1 - Table2][4][8][16];
        this.fInv = new byte[rounds - Table1 - Table2][4][8][16];
        this.g = new byte[rounds - Table1 - Table2][3][8][16];
        this.gInv = new byte[rounds - Table1 - Table2][3][8][16];
        this.h = new byte[rounds - Table1 - Table2][3][8][16];
        this.hInv = new byte[rounds - Table1 - Table2][3][8][16];
        this.t = new byte[rounds - Table1 - Table2][3];
    }
    public int rounds, Table1, Table2;
    int MIDTable;

    public byte[][][][] f, fInv, g, gInv, h, hInv;
    public byte[][] t;
}
