/**
 * @file    wbwfleaConfig.java
 * @brief   Whitebox WF-LEA java code: configuration for key size: 128 or 192 or 256
 * @author  FDL @ KMU
 * @version 2022.08.08.
 */
package kr.co.vp.common.crypto.wb.wflea;

public class WbwfleaConfig {
	public WbwfleaConfig() { }
	public WbwfleaConfig(String flag, int alg, int macBlock, int table1, int table2) {
		this.WFLEAFLAG = flag;
		this.ALG = alg;
		this.MACMSGLEN = macBlock;
		this.Table1 = table1;
		this.Table2 = table2;
	}
	public String getWFLEAFLAG() {
		return this.WFLEAFLAG;
	}

	public int getROUNDS() {
		return this.ROUNDS;
	}

	public int getTable1() {
		return this.Table1;
	}

	public int getTable2() {
		return this.Table2;
	}

	public int getKEYBYTES() {
		return KEYBYTES;
	}

	public int getMIDTable() {
		return MIDTable;
	}

	public int getMACMSGLEN() {
		return MACMSGLEN;
	}

	public final int ERROR		= 0x00000000;

	private String WFLEAFLAG;

	private int ALG;

	private int ROUNDS;
	private int KEYBYTES;
	private int MACMSGLEN;
	private int Table1, Table2, MIDTable;

	public void config() {
		switch(this.ALG) {
		case 128:
			this.ROUNDS = 24;
			this.KEYBYTES = 16;
			this.MIDTable = (ROUNDS - Table1 - Table2);
			break;
		case 192:
			this.ROUNDS = 28;
			this.KEYBYTES = 24;
			this.MIDTable = (ROUNDS - Table1 - Table2);
			break;
		case 256:
			this.ROUNDS = 32;
			this.KEYBYTES = 32;
			this.MIDTable = (ROUNDS - Table1 - Table2);
			break;
		default:
			Common.log.info("Config Error : %d " + ERROR);
		}
	}


}
