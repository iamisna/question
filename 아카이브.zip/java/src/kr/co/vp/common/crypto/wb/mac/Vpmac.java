/**
 * @file    vpmac.java
 * @brief   VPMAC Ver1.0
 * @author  FDL @ KMU
 * @version 2022.08.07.
 */
package kr.co.vp.common.crypto.wb.mac;

import kr.co.vp.common.crypto.wb.Cbclea;
import kr.co.vp.common.crypto.wb.exception.WhiteBoxException;
import kr.co.vp.common.crypto.wb.wflea.*;
import kr.co.vp.common.crypto.wb.random.*;

import java.util.Arrays;
import java.util.Base64;
import java.util.Objects;

public class Vpmac {

	/**
	 * @param byteLen 입력 사이즈
	 * @return WbwfleaConfig.MACMSGLEN 블록에 맞게 패딩
	 */
	public int padLen(int byteLen, WbwfleaConfig config) {
		 int tmp = byteLen % (16 * config.getMACMSGLEN());
		 return byteLen + (16 * config.getMACMSGLEN() - tmp);
	}

	/**
	 * @param src 입력 데이터
	 * @param len 길이
	 * @return one-zero 패딩된 데이터
	 */
	public byte[] padMsg(byte[] src, int len) {
		byte[] dst = new byte[len];
		System.arraycopy(src, 0, dst, 0, src.length);
		dst[src.length] = (byte) 0x80;             // one-zero padding
		return dst;
	}
	
	public byte[] vpMacGen(wbwfleaMacWK1 wk1Tab, wbwfleaMacWK2 wk2Tab, byte[] src, WbwfleaConfig config) throws WhiteBoxException {
		byte[] paddedMsg;
		WbwfleaEncrypt wbwfleaEncrypt = new WbwfleaEncrypt();
		byte[] dst = new byte[16];
		int blkLen;
		byte[] enc = new byte[16];
		byte[] iv = new byte[16];
		try {
			Vpmac vpmac = new Vpmac();
			int padLen = vpmac.padLen(src.length, config);
			paddedMsg = vpmac.padMsg(src, padLen);   //one-zero pad to msg
			blkLen = padLen / 16;           // block length
			System.arraycopy(wk2Tab.IV, 0, iv, 0, 16);
		}
		catch (Exception e) {
			WhiteBoxException wbe = new WhiteBoxException("2987");
			Common.log.info(wbe.getErrorCode());
			Common.log.info(wbe.getMessage());
			throw wbe;
		}
		if (paddedMsg.length % 16 != 0){
			WhiteBoxException e = new WhiteBoxException("2019");
			Common.log.info(e.getErrorCode());
			Common.log.info(e.getMessage());
			throw e;
		}

		// i < blkLen
		for(int i = 0; i < blkLen; i++)     // N-1 blk
		{
			for(int j = 0; j < 16; j++)
			{
				byte tmp = wk2Tab.XOR[j/4][(2 * j + 1) % 8][((((paddedMsg[16 * i + j] >> 4) & 0xf) << 4 ) ^ ((iv[j] >> 4) & 0xf))];

				enc[j] = (byte) ((tmp & 0xf) << 4);

				enc[j] ^= wk2Tab.XOR[j / 4][(2 * j) % 8][(((paddedMsg[16 * i + j] & 0xf) << 4) ^ (iv[j] & 0xf))];
			}

			enc = wbwfleaEncrypt.wbwfleaSepEncryptwb(wk1Tab, wk2Tab, enc, config);

			System.arraycopy(enc, 0, iv, 0, 16);
		}
		System.arraycopy(iv, 0, dst, 0, 16);
		return dst;
	}

	/**
	 * VP MAC Generate
	 * @param wk1 : WhiteBox KEY 1
	 * @param wk2 : WhiteBox KEY 2
	 * @param src : input data
	 * @return tag
	 */
	public byte[] vpMacGenTagFromBase64(String wk1, String wk2, byte[] src, WbwfleaConfig config) throws WhiteBoxException {
		if((wk1.isEmpty()) || (wk2.isEmpty())){
			WhiteBoxException e = new WhiteBoxException("2020");
			Common.log.info(e.getErrorCode());
			Common.log.info(e.getMessage());
			throw e;
		} else if (src == null) {
			WhiteBoxException e = new WhiteBoxException("2018");
			Common.log.info(e.getErrorCode());
			Common.log.info(e.getMessage());
			throw e;
		}
		try{
			Vpmac vpmac = new Vpmac();
			/* String을 Base64로 디코딩하여 화이트박스 키 1,2 생성 */
			wbwfleaMacWK1 wk1Tab = vpmac.wbwfleaMacWK1DecodeBase64(wk1, config);
			wbwfleaMacWK2 wk2Tab = vpmac.wbwfleaMacWK2DecodeBase64(wk2, config);

			byte[] dst = vpmac.vpMacGen(wk1Tab, wk2Tab, src, config);
			return dst;
		} catch (Exception e) {
			WhiteBoxException wbe = new WhiteBoxException("2988");
			Common.log.info(wbe.getErrorCode());
			Common.log.info(wbe.getMessage());
			throw wbe;
		}
	}

	/**
	 * @param key 키
	 * @param src 입력 데이터
	 * @param iv iv
	 * @param BeSeed 외부 인코딩 생성 seed
	 * @param tag 서명 값
	 * @return valid(1) / invalid(0)
	 */
	public String vpMacVerify(byte[] key, byte[] src, byte[] iv, byte[] BeSeed, byte[] tag, WbwfleaConfig config) throws WhiteBoxException {
		if(src == null){
			WhiteBoxException e = new WhiteBoxException("2021");
			Common.log.info(e.getErrorCode());
			Common.log.info(e.getMessage());
			throw e;
		}
		/* setup: WFLEA context (roundkey generation) */
		Wflea wflea = new Wflea();
		WfleaCtx ctx = wflea.wfleaGenCtx(key, config);

		if(!Objects.equals(ctx.getErrorCode(), "0000")) {
			WhiteBoxException e = new WhiteBoxException(ctx.getErrorCode());
			Common.log.info(e.getErrorCode());
			Common.log.info(e.getMessage());
			throw e;
		}
		WbwfleaExtEncoding Be;
		byte[] paddedMsg;
		int padLen;
		try {
			Randperm randperm = new Randperm();
			Be = randperm.genRandperm128Bits(BeSeed);
			Vpmac vpmac = new Vpmac();
			padLen = vpmac.padLen(src.length, config);
			paddedMsg = vpmac.padMsg(src, padLen);                //padded
		} catch (Exception e) {
			WhiteBoxException wbe = new WhiteBoxException("2089");
			Common.log.info(wbe.getErrorCode());
			Common.log.info(wbe.getMessage());
			throw wbe;
		}
		if(paddedMsg.length % 16 != 0) {
			WhiteBoxException wbe = new WhiteBoxException("2022");
			Common.log.info(wbe.getErrorCode());
			Common.log.info(wbe.getMessage());
			throw wbe;
		}
		try{
			int blkLen = padLen / 16;			// block length

			byte[] ivTmp = new byte[16];
			byte[] enc = new byte[16];
			byte[] dec = new byte[16];

			System.arraycopy(iv, 0, ivTmp, 0, 16);

			for(int i = 0; i < blkLen; i++)     // N-1 blk
			{
				for(int j = 0; j < 16; j++)
				{
					enc[j] = (byte) (paddedMsg[16 * i + j] ^ ivTmp[j]) ;
				}

				dec = wflea.wfleaEncryptblk4Bits(enc, ctx);             // in sign, usign wfLEA. not Wbwflea.

				System.arraycopy(dec, 0, ivTmp, 0, 16);
			}
			WbwfleaExtTransform wbwfleaExtTransform = new WbwfleaExtTransform();
			dec = wbwfleaExtTransform.wbwfleaExtTransforms(Be, dec, 1);

			if(!Arrays.equals(dec, tag)){
				return "INVALID";
			}
			return "VALID";
		} catch (Exception e) {
			WhiteBoxException wbE = new WhiteBoxException("2990");
			Common.log.info(wbE.getErrorCode());
			Common.log.info(wbE.getMessage());
			throw wbE;
		}
	}
	public String vpMacTagVerifyBase64(byte[] key, byte[] src, String ivStr, String BeSeedStr, byte[] tag, WbwfleaConfig config) throws WhiteBoxException {
		if (ivStr.length() != 24) {
			WhiteBoxException e = new WhiteBoxException("2023");
			Common.log.info(e.getErrorCode());
			Common.log.info(e.getMessage());
			throw e;
		} else if (tag.length != 16) {
			WhiteBoxException e = new WhiteBoxException("2024");
			Common.log.info(e.getErrorCode());
			Common.log.info(e.getMessage());
			throw e;
		} else if (BeSeedStr.length() != 44) {
			WhiteBoxException e = new WhiteBoxException("2025");
			Common.log.info(e.getErrorCode());
			Common.log.info(e.getMessage());
			throw e;
		} else if (key.length != config.getKEYBYTES()) {
			WhiteBoxException e = new WhiteBoxException("2026");
			Common.log.info(e.getErrorCode());
			Common.log.info(e.getMessage());
			throw e;
		}
		Common common = new Common();
		byte[] iv = common.seedDecodeBase64(ivStr);
		byte[] BeSeed = common.seedDecodeBase64(BeSeedStr);

		return vpMacVerify(key, src, iv, BeSeed, tag, config);
	}

	/**
	 * @param src 입력 데이터
	 * @param IV iv
	 * @param key 키
	 * @return CBC MAC 서명 값
	 */
	public byte[] cbcmacLea(final byte[] src, byte[] IV, byte[] key, WbwfleaConfig config) {
		Wflea wflea = new Wflea();
		WfleaCtx ctx = wflea.wfleaGenCtx(key, config);

		int blkLen = src.length / 16;
		byte[] enc = new byte[16];
		byte[] dec;
		byte[] dst = new byte[16];
		byte[] inIv = new byte[16];

		System.arraycopy(IV, 0, inIv, 0, 16);

		for(int i = 0; i < blkLen; i++)     // N-1 blk
		{
			for(int j = 0; j < 16; j++)
			{
				enc[j] = (byte) (src[16 * i + j] ^ inIv[j]);
			}
			dec = wflea.wfleaEncryptblk(enc, ctx);

			System.arraycopy(dec, 0, inIv, 0, 16);
		}
		System.arraycopy(inIv, 0, dst, 0, 16);
		return dst;
	}


	/**
	 * @param AinSeed 외부인코딩1 생성 시드
	 * @param BinSeed 외부인코딩2 생성 시드
	 * @param key 키
	 * @return WK1
	 * @throws WhiteBoxException
	 */
	public wbwfleaMacWK1 vpmacWk1KeyGen(byte[] AinSeed, byte[] BinSeed, byte[] key, WbwfleaConfig config) throws WhiteBoxException {
		/* setup: WFLEA context (roundkey generation) */
		Wflea wflea = new Wflea();
		WfleaCtx wfleaCtx = wflea.wfleaGenCtx(key, config);

		if(!Objects.equals(wfleaCtx.getErrorCode(), "0000")) {
			WhiteBoxException e = new WhiteBoxException(wfleaCtx.getErrorCode());
			Common.log.info(e.getErrorCode());
			Common.log.info(e.getMessage());
			throw e;
		}
		Randperm randperm = new Randperm();

		WbwfleaExtEncoding Ain = randperm.genRandperm128Bits(AinSeed);
		WbwfleaExtEncoding Bin = randperm.genRandperm128Bits(BinSeed);

		WbwfleamacEncodings wbwfleamacEncodings = new WbwfleamacEncodings();
		wbwfleaEncodingsForMacmid encCtx2 = wbwfleamacEncodings.wbwfleaGenEncodingsForMacmid(Ain, Bin, config);         // table2 first.   wk1 permutation

		WbwfleaTables wbwfleaTables = new WbwfleaTables();
		wbwfleaMacWK1 wk1Tab = wbwfleaTables.wbwfleaGenMacEncTablemid(encCtx2, wfleaCtx, config);		// table2 first wk1

		return wk1Tab;
	}

	/**
	 * @param AinSeed 외부인코딩1 생성 시드
	 * @param BinSeed 외부인코딩2 생성 시드
	 * @param IV iv
	 * @param BeSeed 외부인코딩3 생성 시드
	 * @param key 키
	 * @return WK2
	 * @throws WhiteBoxException
	 */
	public wbwfleaMacWK2 vpmacWk2KeyGen(byte[] AinSeed, byte[] BinSeed, byte[] IV, byte[] BeSeed, byte[] key, WbwfleaConfig config) throws WhiteBoxException {
		/* setup: WFLEA context (roundkey generation) */
		Wflea wflea = new Wflea();
		WfleaCtx wfleaCtx = wflea.wfleaGenCtx(key, config);

		if(!Objects.equals(wfleaCtx.getErrorCode(), "0000")) {
			WhiteBoxException e = new WhiteBoxException(wfleaCtx.getErrorCode());
			Common.log.info(e.getErrorCode());
			Common.log.info(e.getMessage());
			throw e;
		}
		/* external encoding generation (for encryption) */
		Randperm randperm = new Randperm();
		WbwfleaExtTransform wbwfleaExtTransform = new WbwfleaExtTransform();
		WbwfleaExtEncoding Ae = wbwfleaExtTransform.wbwfleaGenExtEncoding();
		WbwfleaExtEncoding Be = randperm.genRandperm128Bits(BeSeed);

		/* wk2 start*/
		WbwfleaExtEncoding Ain = randperm.genRandperm128Bits(AinSeed);
		WbwfleaExtEncoding Bin = randperm.genRandperm128Bits(BinSeed);

		WbwfleamacEncodings wbwfleamacEncodings = new WbwfleamacEncodings();
		wbwfleaEncodingsForMacfirst encCtx1 = wbwfleamacEncodings.wbwfleaGenEncodingsForMacfirst(Ae, Ain, config);    //  table1  wk2 permutation
		wbwfleaEncodingsForMacend encCtx3 = wbwfleamacEncodings.wbwfleaGenEncodingsForMacend(Bin, Be, config);        //  table3  wk2 permutation

		WbwfleaTables wbwfleaTables = new WbwfleaTables();
		wbwfleaMacWK2 wk2TabTmp = wbwfleaTables.wbwfleaGenMacEncTablefirst(encCtx1, wfleaCtx, config);    //  table1  wk2
		wbwfleaMacWK2 wk2Tab = wbwfleaTables.wbwfleaGenMacEncTableend(wk2TabTmp, encCtx3, wfleaCtx, config);        //  table3  wk2

		/* CBC-table-permutation */
		WbwfleaExtEncoding CBCAe = wbwfleaExtTransform.wbwfleaGenExtIdentityEncoding();    // wk2  xor permutation

		Cbclea cbclea = new Cbclea();
		byte[][][] xor = cbclea.cbcGenEncodingTable(CBCAe, Be, Ae);        // wk2  table4
		wk2Tab.XOR = xor;

		System.arraycopy(IV, 0, wk2Tab.IV, 0, 16);
		return wk2Tab;
	}

	/**
	 * @param ctx WK1
	 * @return WK1을 base64 인코딩 적용한 String
	 */
	private String WK1EncodeBase64(wbwfleaMacWK1 ctx) {
		Base64.Encoder base64Encoder = Base64.getEncoder();
		byte[] tmp = new byte[ctx.getMIDTable() * 3 * 8 * (512 + 256)];

		int i, j, k, l;

		for(i = 0; i < ctx.getMIDTable(); i++) {
			for(j = 0; j < 3; j++) {
				for(k = 0 ; k < 8; k++) {
					for(l = 0; l < 512; l++) {
						tmp[(i * 3 * 8 * 512) + (j * 8 * 512) + (k * 512) + l] = ctx.ETA[i][j][k][l];
					}
				}
			}
		}
		for(i = 0; i < ctx.getMIDTable(); i++) {
			for(j = 0; j < 3; j++) {
				for(k = 0 ; k < 8; k++) {
					for(l = 0; l < 256; l++) {
						tmp[(ctx.getMIDTable() * 3 * 8 * 512) + (i * 3 * 8 * 256) + (j * 8 * 256) + (k * 256) + l] = ctx.ETR[i][j][k][l];
					}
				}
			}
		}
		String encodingDat = base64Encoder.encodeToString(tmp);
		return encodingDat;
	}

	/**
	 * @param ctx WK2
	 * @return WK2을 base64 인코딩 적용한 String
	 */
	private String WK2EncodeBase64(wbwfleaMacWK2 ctx) {
		Base64.Encoder base64Encoder = Base64.getEncoder();

		int i, j, k, l;
		int tables = (ctx.Table1 + ctx.Table2);
		byte[] tmp = new byte[(tables * 3 * 8 * (512 + 256)) + (4 * 8 * 256) + 16];

		for(i = 0; i < tables; i++) {
			for(j = 0; j < 3; j++) {
				for(k = 0 ; k < 8; k++) {
					for(l = 0; l < 512; l++) {
						tmp[(i * 3 * 8 * 512) + (j * 8 * 512) + (k * 512) + l] = ctx.ETA[i][j][k][l];
					}
				}
			}
		}
		for(i = 0; i < tables; i++) {
			for(j = 0; j < 3; j++) {
				for(k = 0 ; k < 8; k++) {
					for(l = 0; l < 256; l++) {
						tmp[(tables * 3 * 8 * 512) + (i * 3 * 8 * 256) + (j * 8 * 256) + (k * 256) + l] = ctx.ETR[i][j][k][l];
					}
				}
			}
		}
		for(i = 0; i<4; i++){
			for(j=0; j<8; j++){
				for(k=0;k<256;k++){
					tmp[(tables * 3 * 8 * (512 + 256)) + (i * 8 * 256) + (j * 256) + k] = ctx.XOR[i][j][k];
				}
			}
		}
		for(i = 0; i< 16; i++){
			tmp[(tables * 3 * 8 * (512+256)) + (4 * 8 * 256) + i] = ctx.IV[i];
		}
		String encodingDat = base64Encoder.encodeToString(tmp);
		return encodingDat;
	}

	/**
	 * @param strWk1 base64 인코딩된 String
	 * @return WK1
	 */
	private wbwfleaMacWK1 wbwfleaMacWK1DecodeBase64(String strWk1, WbwfleaConfig config) {
		wbwfleaMacWK1 ctx = new wbwfleaMacWK1(config);
		Base64.Decoder base64Decoder = Base64.getDecoder();
		byte[] tmp;
		int i, j, k, l;

		tmp = base64Decoder.decode(strWk1);

		for(i = 0; i < ctx.getMIDTable(); i++) {
			for(j = 0; j < 3; j++) {
				for(k = 0 ; k < 8; k++) {
					for(l = 0; l < 512; l++) {
						ctx.ETA[i][j][k][l] = tmp[(i * 3 * 8 * 512) + (j * 8 * 512) + (k * 512) + l];
					}
				}
			}
		}
		for(i = 0; i < ctx.getMIDTable(); i++) {
			for(j = 0; j < 3; j++) {
				for(k = 0 ; k < 8; k++) {
					for(l = 0; l < 256; l++) {
						ctx.ETR[i][j][k][l] = tmp[(ctx.getMIDTable() * 3 * 8 * 512) + (i * 3 * 8 * 256) + (j * 8 * 256) + (k * 256) + l];
					}
				}
			}
		}
		return ctx;
	}

	/**
	 * @param strWk2 base64 인코딩된 String
	 * @return WK2
	 */
	private wbwfleaMacWK2 wbwfleaMacWK2DecodeBase64(String strWk2, WbwfleaConfig config) {
		wbwfleaMacWK2 ctx = new wbwfleaMacWK2(config);
		Base64.Decoder base64Decoder = Base64.getDecoder();

		int i, j, k, l;
		int tables = (ctx.Table1 + ctx.Table2);
		byte[] tmp;

		tmp = base64Decoder.decode(strWk2);

		for(i = 0; i < tables; i++) {
			for(j = 0; j < 3; j++) {
				for(k = 0 ; k < 8; k++) {
					for(l = 0; l < 512; l++) {
						ctx.ETA[i][j][k][l] = tmp[(i * 3 * 8 * 512) + (j * 8 * 512) + (k * 512) + l];
					}
				}
			}
		}
		for(i = 0; i < tables; i++) {
			for(j = 0; j < 3; j++) {
				for(k = 0 ; k < 8; k++) {
					for(l = 0; l < 256; l++) {
						ctx.ETR[i][j][k][l] = tmp[(tables * 3 * 8 * 512) + (i * 3 * 8 * 256) + (j * 8 * 256) + (k * 256) + l];
					}
				}
			}
		}
		for(i = 0; i<4; i++){
			for(j=0; j<8; j++){
				for(k=0;k<256;k++){
					ctx.XOR[i][j][k] = tmp[(tables * 3 * 8 * (512 + 256)) + (i * 8 * 256) + (j * 256) + k];
				}
			}
		}
		for(i = 0; i< 16; i++){
			ctx.IV[i] = tmp[(tables * 3 * 8 * (512+256)) + (4 * 8 * 256) + i];
		}

		return ctx;
	}

	public String vpmacWk1KeyGenBase64(byte[] AinSeed, byte[] BinSeed, byte[] key, WbwfleaConfig config) throws WhiteBoxException {
		if((AinSeed.length != 32) || (BinSeed.length != 32)) {
			WhiteBoxException e = new WhiteBoxException("2015");
			Common.log.info(e.getErrorCode());
			Common.log.info(e.getMessage());
			throw e;
		} else if (key.length != config.getKEYBYTES()) {
			WhiteBoxException e = new WhiteBoxException("2016");
			Common.log.info(e.getErrorCode());
			Common.log.info(e.getMessage());
			throw e;
		}
		try {
			Vpmac vpmac = new Vpmac();
			wbwfleaMacWK1 wk1Tab = vpmac.vpmacWk1KeyGen(AinSeed, BinSeed, key, config);		// 고정된 wk1 생성
			String wk1 = vpmac.WK1EncodeBase64(wk1Tab);					// wk1 테이블에 base64 적용
			return wk1;
		} catch (Exception e) {
			WhiteBoxException wbe = new WhiteBoxException("2986");
			Common.log.info(wbe.getErrorCode());
			Common.log.info(wbe.getMessage());
			throw wbe;
		}
	}

	public String vpmacWk2KeyGenBase64(byte[] AinSeed, byte[] BinSeed, byte[] iv, byte[] BeSeed, byte[] key, WbwfleaConfig config) throws WhiteBoxException {
		if((AinSeed.length != 32) || (BinSeed.length != 32) || (BeSeed.length != 32)) {
			WhiteBoxException e = new WhiteBoxException("2015");
			Common.log.info(e.getErrorCode());
			Common.log.info(e.getMessage());
			throw e;
		} else if (key.length != config.getKEYBYTES()) {
			WhiteBoxException e = new WhiteBoxException("2016");
			Common.log.info(e.getErrorCode());
			Common.log.info(e.getMessage());
			throw e;
		} else if (iv.length != 16) {
			WhiteBoxException e = new WhiteBoxException("2017");
			Common.log.info(e.getErrorCode());
			Common.log.info(e.getMessage());
			throw e;
		}
		try{
			Vpmac vpmac = new Vpmac();
			wbwfleaMacWK2 wk2Tab = vpmac.vpmacWk2KeyGen(AinSeed, BinSeed, iv, BeSeed, key, config);	// 일회용 wk2 생성
			String wk2 = vpmac.WK2EncodeBase64(wk2Tab);					// wk2 테이블에 base64 적용
			return wk2;
		} catch (Exception e) {
			WhiteBoxException wbe = new WhiteBoxException("2986");
			Common.log.info(wbe.getErrorCode());
			Common.log.info(wbe.getMessage());
			throw wbe;
		}
	}
}
