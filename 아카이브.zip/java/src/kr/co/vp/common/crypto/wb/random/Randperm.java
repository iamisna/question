/**
 * @file    randperm.java
 * @brief   4-bit/1-bit random permutation generation
 * @author  FDL @ KMU
 * @version 2022.08.07.
 */

package kr.co.vp.common.crypto.wb.random;

import kr.co.vp.common.crypto.wb.wflea.*;
import kr.co.vp.common.crypto.wb.Lea128;

public class Randperm {

	private byte[] shuffle4Bits() {
		int j;
		byte[] x = new byte[16];
		
		for(j = 0; j < 16; j++) {
			x[j] = (byte) j;
		}
		for(int i = 15; i > 0 ; i--) {
			j = (int) ((Math.random() * 1000) % (i + 1));
			byte tmp = x[i];
			x[i] = x[j];
			x[j] = tmp;
		}
		return x;
	}
	
	private byte[] getInvMap4Bits(final byte[] src) {
		byte[] dst = new byte[16];
		for(int j = 0; j < 16; j++) {
			dst[src[j]] = (byte) j;
		}
		return dst;
	}
	
	public byte[][] genRandperm4bits() {
		Randperm randperm = new Randperm();
		byte[][] retMap = new byte[2][16];
		
		byte[] map;
		byte[] mapInv;
		
		map = randperm.shuffle4Bits();
		mapInv = randperm.getInvMap4Bits(map);
		
		retMap[0] = map;
		retMap[1] = mapInv;
		
		return retMap;
	}
	
	public byte[] idenGenRandperm4bits(byte[] map) {
		Randperm randperm = new Randperm();

		for(int j = 0; j < 16; j++) {
			map[j] = (byte) j;
		}
		byte[] mapInv = randperm.getInvMap4Bits(map);
		
		return mapInv;
	}
	
	public byte genRandperm1bits() {
		byte map = (byte) ((byte) (Math.random() * 1000) & 0xff);
		return map;
	}
	
	private byte[][] setIdentity4bits() {
		Randperm randperm = new Randperm();
		byte[][] retMap = new byte[2][16];
		
		byte[] map = new byte[16];
		byte[] mapInv;
		
		for(int j = 0; j < 16; j++) {
			map[j] = (byte) j;
		}
		
		mapInv = randperm.getInvMap4Bits(map);
		
		retMap[0] = map;
		retMap[1] = mapInv;
		
		return retMap;
	}
	
	private int transformBy32bitPerm4bits(int x, byte[][] map) {
		Wflea wflea = new Wflea();
		int ret = 0;
		for (int j = 0; j < 8; j++)
	    {
		 	ret ^= ((map[j][wflea.getJthNibble(x, j)]) << (4 * j));
	    }
		return ret;
	}

	private byte[] initPerm4Bits()
	{
		byte[] dst = new byte[16];
		for (int j = 0; j < 16; j++)
			dst[j] = (byte) j;
		return dst;
	}
	private byte[][] genRandperm4BitsW16B(byte[] rdat)
	{
		Randperm randperm = new Randperm();
		byte[][] dst = new byte[2][16];
		byte[] x, xInv;
		x = randperm.initPerm4Bits();

		int j = 0;
		int l, t;
		byte tmp;

		for(t = 4; t > 0; t--)
		{
			int u = 1 << t;
			for(l = 0; l < (u >> 1); l++)
			{
				int i = u - 1 - l;
				int cnt = 0;
				while(cnt <= 8 - t)
				{
					int mask = u - 1;
					j = (rdat[i] >> cnt) & mask;
					if (j <= i)
						break;
					cnt++;
				}
				j = j % (i + 1);
				tmp = x[i];
				x[i] = x[j];
				x[j] = tmp;
			}
		}
		xInv = randperm.getInvMap4Bits(x);
		dst[0] = x;
		dst[1] = xInv;
		return dst;
	}

	private byte[] addOne(byte[] x)
	{
		byte[] dst = x;
		for (int j = 15; j >= 0; j--)
		{
			dst[j] = (byte) (x[j] + 1);
			if (dst[j] != 0) {
				return dst;
			}
		}
		return dst;
	}

	private byte[] xor128(byte[] dst, byte[] src)
	{
		Common common = new Common();
		Lea128 lea128 = new Lea128();
		int[] srcInt = common.wordToInt(src);
		int[] dstInt = common.wordToInt(dst);
		for (int i = 0; i < lea128.LEA128_WORDLEN_BLK; i++) {
			dstInt[i] = dstInt[i] ^ srcInt[i];
		}
		dst = common.intToWord(dstInt);
		return dst;
	}

	private byte[] genRand512B(byte[] seed)
	{
		Randperm randperm = new Randperm();
		Lea128 lea128 = new Lea128();
		byte[] dst = new byte[512];
		byte[] K = new byte[lea128.LEA128_BYTELEN_KEY];
		byte[] V = new byte[lea128.LEA128_BYTELEN_BLK];
		byte[] seedTmp = new byte[16];

		int[][] RK = lea128.lea128Keyschedule(K);

		V = randperm.addOne(V);
		K = lea128.lea128Encryptblk(V, RK);
		System.arraycopy(seed, 0, seedTmp, 0, 16);
		K = randperm.xor128(K, seedTmp);
		V = randperm.addOne(V);
		V = lea128.lea128Encryptblk(V, RK);
		System.arraycopy(seed, lea128.LEA128_BYTELEN_BLK, seedTmp, 0, 16);
		V = randperm.xor128(V, seedTmp);

		RK = lea128.lea128Keyschedule(K);

		for (int i = 0; i < 32; i++)
		{
			V = randperm.addOne(V);
			byte[] dstTmp = lea128.lea128Encryptblk(V, RK);
			System.arraycopy(dstTmp, 0, dst, lea128.LEA128_BYTELEN_BLK * i, 16);
		}
		return dst;
	}

	/**
	 * @param seed 초기 시드 값
	 * @return LEA 128 기반 CTR DRBG로 랜덤 생성된 외부 인코딩
	 */
	public WbwfleaExtEncoding genRandperm128Bits(byte[] seed) {
		Randperm randperm = new Randperm();
		byte[] rdatTmp = new byte[16];
		byte[] rdat = randperm.genRand512B(seed);

		WbwfleaExtEncoding ctx = new WbwfleaExtEncoding();
		for(int i = 0; i < 4; i++) {
			for (int j = 0; j < 8; j++) {
				byte[][] tmp;
				System.arraycopy(rdat, 16 * (8 * i + j), rdatTmp, 0, 16);
				tmp = randperm.genRandperm4BitsW16B(rdatTmp);

				ctx.f[i][j] = tmp[0];
				ctx.fInv[i][j] = tmp[1];
			}
		}
		return ctx;
    }
}
