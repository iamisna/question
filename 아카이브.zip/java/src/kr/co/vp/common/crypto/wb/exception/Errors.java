/**
 * @file    Errors.java
 * @brief   error messages
 * @author  FDL @ KMU
 * @version 2022.08.07.
 */
package kr.co.vp.common.crypto.wb.exception;

public class Errors {

}
