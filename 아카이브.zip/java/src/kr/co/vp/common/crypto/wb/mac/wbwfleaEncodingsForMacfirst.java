/**
 * @file    wbwfleaEncodingsForMacfirst.java
 * @brief   wbwfleaEncodingsForMacfirst
 * @author  FDL @ KMU
 * @version 2022.08.07.
 */
package kr.co.vp.common.crypto.wb.mac;

import kr.co.vp.common.crypto.wb.wflea.WbwfleaConfig;

public class wbwfleaEncodingsForMacfirst {
    public wbwfleaEncodingsForMacfirst(WbwfleaConfig config){
        this.Table1 = config.getTable1();
        this.f = new byte[Table1][4][8][16];
        this.fInv = new byte[Table1][4][8][16];
        this.g = new byte[Table1][3][8][16];
        this.gInv = new byte[Table1][3][8][16];
        this.h = new byte[Table1][3][8][16];
        this.hInv = new byte[Table1][3][8][16];
        this.t = new byte[Table1][3];
    }

    public int Table1;
    public byte[][][][] f, fInv, g, gInv, h, hInv;;
    public byte[][] t;

    public byte[][][][] getF() {
        return f;
    }

    public byte[][][][] getfInv() {
        return fInv;
    }

    public byte[][][][] getG() {
        return g;
    }

    public byte[][][][] getH() {
        return h;
    }

    public byte[][] getT() {
        return t;
    }
}
