/**
 * @file    Lea128.java
 * @brief   Lea128 java code
 * @author  FDL @ KMU
 * @version 2022.08.07.
 */
package kr.co.vp.common.crypto.wb;

import kr.co.vp.common.crypto.wb.wflea.Common;

public class Lea128 {
    public int LEA128_BYTELEN_KEY = 16;
    public int LEA128_BYTELEN_BLK = 16;

    public int LEA128_WORDLEN_RNDKEY = 6;
    public int LEA128_WORDLEN_BLK = 4;

    public int LEA128_NUM_RNDS = 24;

    private static final int[] delta =  {
            0xc3efe9db, 0x44626b02, 0x79e27c8a, 0x78df30ec,
            0x715ea49e, 0xc785da0a, 0xe04ef22a, 0xe5c40957 };

    public int roL(int x, int l) {
        return (x << l) | (x >>> (32 - l));
    }

    public int roR(int x, int l) {
        return (x >>> l) | (x << (32 - l));
    }

    public int xoR(int x, int y) {
        return x ^ y;
    }

    public int adD(int x, int y) {
        return x + y;
    }

    public int suB(int x, int y) {
        return x - y;
    }

    public int[][] lea128Keyschedule(final byte[] k) {
        Lea128 lea128 = new Lea128();
        Common common = new Common();

        int[][] rndKey = new int[lea128.LEA128_NUM_RNDS][lea128.LEA128_WORDLEN_RNDKEY];
        int[] kTmp = common.wordToInt(k);

        for (int i = 0; i < 24; i++) {
            kTmp[0] = lea128.roL(lea128.adD(kTmp[0], lea128.roL(delta[i % 4], i)), 1);
            kTmp[1] = lea128.roL(lea128.adD(kTmp[1], lea128.roL(delta[i % 4], i + 1)), 3);
            kTmp[2] = lea128.roL(lea128.adD(kTmp[2], lea128.roL(delta[i % 4], i + 2)), 6);
            kTmp[3] = lea128.roL(lea128.adD(kTmp[3], lea128.roL(delta[i % 4], i + 3)), 11);

            rndKey[i][0] = kTmp[0];
            rndKey[i][1] = kTmp[1];
            rndKey[i][2] = kTmp[2];
            rndKey[i][3] = kTmp[1];
            rndKey[i][4] = kTmp[3];
            rndKey[i][5] = kTmp[1];
        }
        return rndKey;
    }

    private int[] wfleaRound(int[] plain, final int[] rndkey) {
        Lea128 lea128 = new Lea128();
        int[] cipher = new int[lea128.LEA128_WORDLEN_BLK];

        int T = plain[0];
        cipher[0] = lea128.roL(lea128.adD(lea128.xoR(plain[0], rndkey[0]), lea128.xoR(plain[1], rndkey[1])), 9);
        cipher[1] = lea128.roR(lea128.adD(lea128.xoR(plain[1], rndkey[2]), lea128.xoR(plain[2], rndkey[3])), 5);
        cipher[2] = lea128.roR(lea128.adD(lea128.xoR(plain[2], rndkey[4]), lea128.xoR(plain[3], rndkey[5])), 3);
        cipher[3] = T;

        return cipher;
    }

    private int[] wfleaRoundInv(int[] cipher, final int[] rndkey) {
        Lea128 lea128 = new Lea128();
        int[] plain = new int[lea128.LEA128_WORDLEN_BLK];

        int T = cipher[3];
        plain[0] = lea128.xoR(lea128.suB(lea128.roR(cipher[0], 9), lea128.xoR(cipher[3], rndkey[0])), rndkey[1]);
        plain[1] = lea128.xoR(lea128.suB(lea128.roL(cipher[1], 5), lea128.xoR(plain[0], rndkey[2])), rndkey[3]);
        plain[2] = lea128.xoR(lea128.suB(lea128.roL(cipher[2], 3), lea128.xoR(plain[1], rndkey[4])), rndkey[5]);
        plain[3] = plain[2];
        plain[2] = plain[1];
        plain[1] = plain[0];
        plain[0] = T;

        return plain;
    }

    public byte[] lea128Encryptblk(final byte[] src, final int[][] rndKey) {
        Common common = new Common();
        Lea128 lea128 = new Lea128();

        int[] t = common.wordToInt(src);
        for(int j = 0; j < lea128.LEA128_NUM_RNDS; j++) {
            t = lea128.wfleaRound(t, rndKey[j]);
        }
        byte[] dst = common.intToWord(t);

        return dst;
    }

    public byte[] lea128Decryptblk(final byte[] src, final int[][] rndKey) {
        Common Common = new Common();
        Lea128 lea128 = new Lea128();

        int[] t = Common.wordToInt(src);
        for(int j = 0; j < lea128.LEA128_BYTELEN_BLK; j++) {
            t = lea128.wfleaRoundInv(t, rndKey[lea128.LEA128_NUM_RNDS - 1 - j]);
        }
        byte[] dst = Common.intToWord(t);

        return dst;
    }
}
