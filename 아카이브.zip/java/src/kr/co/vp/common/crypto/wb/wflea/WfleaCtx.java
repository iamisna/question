/**
 * @file    WfleaCtx.java
 * @brief   WfleaCtx
 * @author  FDL @ KMU
 * @version 2022.08.07.
 */
package kr.co.vp.common.crypto.wb.wflea;

public class WfleaCtx {
    public WfleaCtx(WbwfleaConfig config) {
        this.key = new byte[config.getKEYBYTES()];
        this.rndKey = new int[config.getROUNDS()][6];
        this.ErrorCode = "0000";
    }

    public int blkBytes = 16;        /*!< number of bytes of a block = 16 */
    public int blkWords = 4;        /*!< number of words of a block = 4 */
    public int rndKeyBytes = 24;    /*!< number of bytes of a roundkey = 24 */
    public int rndKeyWords = 6;    /*!< number of words of a roundkey = 6 */

    public int keyBytes;                                /*!< number of bytes of a key = 16 or 24 or 32*/
    public byte[] key;    /*!< key */

    public int numRounds;                    /*!< number of rounds = 24 or 28 or 32*/

    public int[][] rndKey;    /*!< Nr roundkeys */

    public String ErrorCode;
    public String ErrorMessage;
    public void setErrorMessage(String errorMessage) {
        ErrorMessage = errorMessage;
    }

    public void setErrorCode(String errorCode) {
        ErrorCode = errorCode;
    }

    public String getErrorCode() {
        return ErrorCode;
    }

    public String getErrorMessage() {
        return ErrorMessage;
    }
}
