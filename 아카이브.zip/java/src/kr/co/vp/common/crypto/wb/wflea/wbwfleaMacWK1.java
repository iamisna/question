/**
 * @file    wbwfleaMacWK1.java
 * @brief   wbwfleaMacWK1
 * @author  FDL @ KMU
 * @version 2022.08.06.
 */
package kr.co.vp.common.crypto.wb.wflea;

public class wbwfleaMacWK1 {
    public wbwfleaMacWK1(WbwfleaConfig config) {
        this.MIDTable = config.getMIDTable();
        this.ETA = new byte[MIDTable][3][8][512];
        this.ETR = new byte[MIDTable][3][8][256];
    }

    public int getMIDTable() {
        return MIDTable;
    }
    private int MIDTable;
    public byte[][][][] ETA;
    public byte[][][][] ETR;
}
