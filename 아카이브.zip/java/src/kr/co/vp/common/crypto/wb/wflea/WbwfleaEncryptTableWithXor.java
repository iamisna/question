/**
 * @file    WbwfleaEncryptTableWithXor.java
 * @brief   WbwfleaEncryptTableWithXor
 * @author  FDL @ KMU
 * @version 2022.08.06.
 */
package kr.co.vp.common.crypto.wb.wflea;

import kr.co.vp.common.crypto.wb.XorTable;

public class WbwfleaEncryptTableWithXor {
    public WbwfleaEncryptTableWithXor(WbwfleaConfig config) {
        this.encTab = new WbwfleaEncryptionTable(config);
        this.ExTable = new XorTable();
    }
    public WbwfleaEncryptionTable encTab;
    public XorTable ExTable;

    public void setEncTab(WbwfleaEncryptionTable encTab) {
        this.encTab = encTab;
    }

    public void setExTable(XorTable exTable) {
        this.ExTable = exTable;
    }
}
