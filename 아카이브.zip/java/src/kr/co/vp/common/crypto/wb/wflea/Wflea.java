/**
 * @file    wflea.java
 * @brief   WF-LEA java code
 * @author  FDL @ KMU
 * @version 2022.08.07.
 */
package kr.co.vp.common.crypto.wb.wflea;

import kr.co.vp.common.crypto.wb.exception.ErrorCodeVO;
import kr.co.vp.common.crypto.wb.random.Sha256;
import java.security.NoSuchAlgorithmException;
import java.util.Objects;

public class Wflea {
	/* LEA의 키스케줄 시 사용되는 상수 */
	private final int[] delta =  {
			0xc3efe9db, 0x44626b02, 0x79e27c8a, 0x78df30ec, 
			0x715ea49e, 0xc785da0a, 0xe04ef22a, 0xe5c40957 };

	private int xor4bits(int x, int y) {
		int val = 0;
		
		byte z;
		for(int j = 0; j < 8; j++) {
			z = (byte) xor(getJthNibble(x, j), getJthNibble(y, j));
			val ^= (z << (4 * j));
		}
		return val;
	}
	private int rol4Bits(int x, int l) {
		int val = 0;
		
		int q = l >>> 2;
		int r = l & 0x3;
		
		byte z;
		for(int j = 0; j < 8; j++) {
			z = (byte) rol(getJthNibble(x, (8 + j - q) % 8), getJthNibble(x, (8 + j - q - 1) % 8), r);
			val ^= (z << (4 * j));
		}
		return val;
	}
	private int ror4Bits(int x, int l) {
		int val = 0;
		
		int q = l >> 2;
		int r = l & 0x3;
		
		byte z;
		for(int j = 0; j < 8; j++) {
			z = (byte) ror(getJthNibble(x, (j + q + 1) % 8), getJthNibble(x, (j + q) % 8), r);
			val ^= (z << (4 * j));
		}
		return val;
	}
	private int add4Bits(int src1, int src2) {
		int val = 0;
		
		byte z = 0;
		for(int j = 0; j < 8; j++) {
			z = (byte) add((z >> 4), getJthNibble(src1, j), getJthNibble(src2, j));
			val ^= ((z & 0xf) << (4 * j));
		}
		return val;
	}
	private int sub4Bits(int src1, int src2) {
		int val = 0;
		
		byte z = 0;
		for(int j = 0; j < 8; j++) {
			z = (byte) sub((z >> 4), getJthNibble(src1, j), getJthNibble(src2, j));
			val ^= ((z & 0xf) << (4 * j));
		}
		return val;
	}

	/**
	 * WFLEA context generation (roundkey generation)
	 * @param key : 키
	 * @return WfleaCtx
	 */
	public WfleaCtx wfleaGenCtx(byte[] key, WbwfleaConfig config) {
		WfleaCtx ctx = new WfleaCtx(config);

		ctx.keyBytes = config.getKEYBYTES();
		ctx.numRounds = config.getROUNDS();
		int[] keyInt;
		/* key set-up */
		ctx.key = key;

		Sha256 sha256 = new Sha256();
		Common common = new Common();
		if(Objects.equals(config.getWFLEAFLAG(), "wflea")) {
			byte[] data = new byte[ctx.keyBytes + 1];
			byte[] digest;
			int[] digestInt;

			if (ctx.keyBytes >= 0) System.arraycopy(ctx.key, 0, data, 0, ctx.keyBytes);
			
			for(int j = 0; j < ctx.numRounds; j++) {
				data[ctx.keyBytes] = (byte) ((j + 1) & 0xff);

				try {
					digest = sha256.sha256Hash(data);
				} catch (NoSuchAlgorithmException e) {
					String errorCode = ErrorCodeVO.ERR_SHA_LGIC_FUNC_2027.code;
					String errorMessage = ErrorCodeVO.ERR_SHA_LGIC_FUNC_2027.message;
					ctx.setErrorCode(errorCode);
					ctx.setErrorMessage(errorMessage);
					return ctx;
				}

				digestInt = common.wordToInt(digest);

				if(j < ctx.numRounds) {
					System.arraycopy(digestInt, 0, ctx.rndKey[j], 0, 6);
				}
			}
		}
		else {
			keyInt = common.wordToInt(ctx.key);
			WfleaCtx tmp;
			switch(ctx.keyBytes) {
				case 16:
					tmp = keySchedule128(keyInt, config);
					ctx.rndKey = tmp.rndKey;
					break;
				case 24:
					tmp = keySchedule192(keyInt, config);
					ctx.rndKey = tmp.rndKey;
					break;
				case 32:
					tmp = keySchedule256(keyInt, config);
					ctx.rndKey = tmp.rndKey;
					break;
				default:
			}
		}
		return ctx;
	}

	private int roL(int x, int l) {
		return (x << l) | (x >>> (32 - l));
	}

	private int roR(int x, int l) {
		return (x >>> l) | (x << (32 - l));
	}

	private int xoR(int x, int y) {
		return x ^ y;
	}

	private int adD(int x, int y) {
		return x + y;
	}

	private int suB(int x, int y) {
		return x - y;
	}

	/**
	 * @param k 키
	 * @return 키스케줄을 거친 라운드 키 (WfleaCtx 구조체)
	 */
	private WfleaCtx keySchedule128(int[] k, WbwfleaConfig config) {
		WfleaCtx ctx = new WfleaCtx(config);
		Wflea wflea = new Wflea();

		for (int i = 0; i < 24; i++) {
			k[0] = wflea.roL(wflea.adD(k[0], wflea.roL(wflea.delta[i % 4], i)), 1);
			k[1] = wflea.roL(wflea.adD(k[1], wflea.roL(wflea.delta[i % 4], i + 1)), 3);
			k[2] = wflea.roL(wflea.adD(k[2], wflea.roL(wflea.delta[i % 4], i + 2)), 6);
			k[3] = wflea.roL(wflea.adD(k[3], wflea.roL(wflea.delta[i % 4], i + 3)), 11);

			ctx.rndKey[i][0] = k[0];
			ctx.rndKey[i][1] = k[1];
			ctx.rndKey[i][2] = k[2];
			ctx.rndKey[i][3] = k[1];
			ctx.rndKey[i][4] = k[3];
			ctx.rndKey[i][5] = k[1];
		}
		return ctx;
	}

	/**
	 * @param k 키
	 * @return 키스케줄을 거친 라운드 키 (WfleaCtx 구조체)
	 */
	private WfleaCtx keySchedule192(int[] k, WbwfleaConfig config) {
		WfleaCtx ctx = new WfleaCtx(config);
		Wflea wflea = new Wflea();

		for (int i = 0; i < 28; i++) {
			k[0] = wflea.roL(wflea.adD(k[0], wflea.roL(wflea.delta[i % 4], i)), 1);
			k[1] = wflea.roL(wflea.adD(k[1], wflea.roL(wflea.delta[i % 4], i + 1)), 3);
			k[2] = wflea.roL(wflea.adD(k[2], wflea.roL(wflea.delta[i % 4], i + 2)), 6);
			k[3] = wflea.roL(wflea.adD(k[3], wflea.roL(wflea.delta[i % 4], i + 3)), 11);
			k[4] = wflea.roL(wflea.adD(k[4], wflea.roL(wflea.delta[i % 6], i + 4)), 13);
			k[5] = wflea.roL(wflea.adD(k[5], wflea.roL(wflea.delta[i % 6], i + 5)), 17);

			ctx.rndKey[i][0] = k[0];
			ctx.rndKey[i][1] = k[1];
			ctx.rndKey[i][2] = k[2];
			ctx.rndKey[i][3] = k[3];
			ctx.rndKey[i][4] = k[4];
			ctx.rndKey[i][5] = k[5];
		}
		return ctx;
	}

	/**
	 * @param k 키
	 * @return 키스케줄을 거친 라운드 키 (WfleaCtx 구조체)
	 */
	private WfleaCtx keySchedule256(int[] k, WbwfleaConfig config) {
		WfleaCtx ctx = new WfleaCtx(config);
		Wflea wflea = new Wflea();

		for (int i = 0; i < 32; i++) {
			k[(6 * i + 0) % 8] = wflea.roL(wflea.adD(k[(6 * i + 0) % 8], wflea.roL(wflea.delta[i % 8], i)), 1);
			k[(6 * i + 1) % 8] = wflea.roL(wflea.adD(k[(6 * i + 1) % 8], wflea.roL(wflea.delta[i % 8], i + 1)), 3);
			k[(6 * i + 2) % 8] = wflea.roL(wflea.adD(k[(6 * i + 2) % 8], wflea.roL(wflea.delta[i % 8], i + 2)), 6);
			k[(6 * i + 3) % 8] = wflea.roL(wflea.adD(k[(6 * i + 3) % 8], wflea.roL(wflea.delta[i % 8], i + 3)), 11);
			k[(6 * i + 4) % 8] = wflea.roL(wflea.adD(k[(6 * i + 4) % 8], wflea.roL(wflea.delta[i % 8], i + 4)), 13);
			k[(6 * i + 5) % 8] = wflea.roL(wflea.adD(k[(6 * i + 5) % 8], wflea.roL(wflea.delta[i % 8], i + 5)), 17);

			ctx.rndKey[i][0] = k[(6 * i + 0) % 8];
			ctx.rndKey[i][1] = k[(6 * i + 1) % 8];
			ctx.rndKey[i][2] = k[(6 * i + 2) % 8];
			ctx.rndKey[i][3] = k[(6 * i + 3) % 8];
			ctx.rndKey[i][4] = k[(6 * i + 4) % 8];
			ctx.rndKey[i][5] = k[(6 * i + 5) % 8];
		}
		return ctx;
	}
	
	private int[] wfleaRound4Bits(int[] plain, final int[] rndkey) {
		Wflea wflea = new Wflea();
		int[] cipher = new int[4];

		int T = plain[0];
		cipher[0] = wflea.rol4Bits(wflea.add4Bits(wflea.xor4bits(plain[0], rndkey[0]), wflea.xor4bits(plain[1], rndkey[1])), 9);
		cipher[1] = wflea.ror4Bits(wflea.add4Bits(wflea.xor4bits(plain[1], rndkey[2]), wflea.xor4bits(plain[2], rndkey[3])), 5);
		cipher[2] = wflea.ror4Bits(wflea.add4Bits(wflea.xor4bits(plain[2], rndkey[4]), wflea.xor4bits(plain[3], rndkey[5])), 3);
		cipher[3] = T;
		
		return cipher;
	}

	private int[] wfleaRoundInv4Bits(int[] cipher, final int[] rndkey) {
		Wflea wflea = new Wflea();
		int[] plain = new int[4];

		int T = cipher[3];
		plain[0] = wflea.xor4bits(wflea.sub4Bits(wflea.ror4Bits(cipher[0], 9), wflea.xor4bits(cipher[3], rndkey[0])), rndkey[1]);
		plain[1] = wflea.xor4bits(wflea.sub4Bits(wflea.rol4Bits(cipher[1], 5), wflea.xor4bits(plain[0], rndkey[2])), rndkey[3]);
		plain[2] = wflea.xor4bits(wflea.sub4Bits(wflea.rol4Bits(cipher[2], 3), wflea.xor4bits(plain[1], rndkey[4])), rndkey[5]);
		plain[3] = plain[2]; 
		plain[2] = plain[1]; 
		plain[1] = plain[0]; 
		plain[0] = T;

		return plain;
	}

	/**
	 * @brief WFLEA round function
	 * @param plain : state
	 * @param rndkey : 192-bit roundkey
	 * @return 암호화된 state
	 */
	private int[] wfleaRound(int[] plain, final int[] rndkey) {
		Wflea wflea = new Wflea();
		int[] cipher = new int[4];

		int T = plain[0];
		cipher[0] = wflea.roL(wflea.adD(wflea.xoR(plain[0], rndkey[0]), wflea.xoR(plain[1], rndkey[1])), 9);
		cipher[1] = wflea.roR(wflea.adD(wflea.xoR(plain[1], rndkey[2]), wflea.xoR(plain[2], rndkey[3])), 5);
		cipher[2] = wflea.roR(wflea.adD(wflea.xoR(plain[2], rndkey[4]), wflea.xoR(plain[3], rndkey[5])), 3);
		cipher[3] = T;

		return cipher;
	}

	/**
	 * @brief WFLEA inverse round function
	 * @param cipher : state
	 * @param rndkey : 192-bit roundkey
	 * @return 복호화된 state
	 */
	private int[] wfleaRoundInv(int[] cipher, final int[] rndkey) {
		Wflea wflea = new Wflea();
		int[] plain = new int[4];

		int T = cipher[3];
		plain[0] = wflea.xoR(wflea.suB(wflea.roR(cipher[0], 9), wflea.xoR(cipher[3], rndkey[0])), rndkey[1]);
		plain[1] = wflea.xoR(wflea.suB(wflea.roL(cipher[1], 5), wflea.xoR(plain[0], rndkey[2])), rndkey[3]);
		plain[2] = wflea.xoR(wflea.suB(wflea.roL(cipher[2], 3), wflea.xoR(plain[1], rndkey[4])), rndkey[5]);
		plain[3] = plain[2];
		plain[2] = plain[1];
		plain[1] = plain[0];
		plain[0] = T;

		return plain;
	}

	/**
	 * @brief WFLEA 1-block encryption function
	 * @param src : input data
	 * @param ctx : WFLEA context
	 * @return
	 */
	public byte[] wfleaEncryptblk(final byte[] src, WfleaCtx ctx) {
		Common common = new Common();
		Wflea wflea = new Wflea();

		int[] t = common.wordToInt(src);
		for(int j = 0; j < ctx.numRounds; j++) {
			t = wflea.wfleaRound(t, ctx.rndKey[j]);
		}
		byte[] dst = common.intToWord(t);

		return dst;
	}

	/**
	 * @brief WFLEA 1-block encryption function (4-bit version)
	 * @param src : input data
	 * @param ctx : WFLEA context
	 * @return output data
	 */
	public byte[] wfleaEncryptblk4Bits(final byte[] src, WfleaCtx ctx) {
		Common common = new Common();
		Wflea wflea = new Wflea();

		int[] t = common.wordToInt(src);
		for(int j = 0; j < ctx.numRounds; j++) {
			t = wflea.wfleaRound4Bits(t, ctx.rndKey[j]);
		}
		byte[] dst = common.intToWord(t);

		return dst;
	}

	/**
	 * @brief WFLEA 1-block decryption function
	 * @param src : input data
	 * @param ctx : WFLEA context
	 * @return output data
	 */
	public byte[] wfleaDecryptblk(final byte[] src, final WfleaCtx ctx) {
		Common common = new Common();
		Wflea wflea = new Wflea();

		int[] t = common.wordToInt(src);
		for(int j = 0; j < ctx.numRounds; j++) {
			t = wflea.wfleaRoundInv(t, ctx.rndKey[ctx.numRounds - 1 - j]);
		}
		byte[] dst = common.intToWord(t);

		return dst;
	}

	/**
	 * @brief WFLEA 1-block decryption function (4-bit version)
	 * @param src : input data
	 * @param ctx : WFLEA context
	 * @return output data
	 */
	public byte[] wfleaDecryptblk4Bits(final byte[] src, final WfleaCtx ctx) {
		Common common = new Common();
		Wflea wflea = new Wflea();

		int[] t = common.wordToInt(src);
		for(int j = 0; j < ctx.numRounds; j++) {
			t = wflea.wfleaRoundInv4Bits(t, ctx.rndKey[ctx.numRounds - 1 - j]);
		}
		byte[] dst = common.intToWord(t);

		return dst;
	}

	public int getJthNibble(int x, int j) {
		return (x >>> (4 * j)) & 0xf;
	}
	/*
	x, y: 4-bit
	c, b: 1-bit
	l: 1,2,3
	z: output
	 */
	/* -- 4-bit small functions -- */
	private int xor(int x, int y) {
		return ((x ^ y) & 0xf);
	}

	public int rol(int x, int y, int l) {
		return (((x << l) | (y >>> (4 - l))) & 0xf);
	}

	public int ror(int x, int y, int l) {
		return (((x << (4 - l)) | (y >>> l)) & 0xf);
	}
	
	public int add(int c, int x, int y) {
		return (c + x + y) & 0x1f;
	}
	
	public int sub(int b, int x, int y) {
		byte t, zz;
		int z;
		if(x < y) {
			zz =  (byte) ((0x10 + x) - y); 
			t = 1;
		}
		else {
			zz = (byte) (x - y); t = 0;
		}
		if(zz < b) {
			zz = (byte) ((0x10 + zz) - b); 
			t = (byte) (t + 1);
		}
		else {
			zz = (byte) (zz - b);
		}
		z = (zz ^ (t << 4)) & 0x1f;
		return z;
	}
}

