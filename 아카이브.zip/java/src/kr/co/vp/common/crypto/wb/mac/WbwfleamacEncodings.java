/**
 * @file    WbwfleamacEncodings.java
 * @brief   Whitebox WF-LEA C code: Random encoding generation
 * @author  FDL @ KMU
 * @version 2022.08.07.
 */
package kr.co.vp.common.crypto.wb.mac;

import kr.co.vp.common.crypto.wb.wflea.*;
import kr.co.vp.common.crypto.wb.random.*;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;

public class WbwfleamacEncodings {
	public wbwfleaEncodingsForMacmid wbwfleaGenEncodingsForMacmid(WbwfleaExtEncoding A, WbwfleaExtEncoding B, WbwfleaConfig config) {
		wbwfleaEncodingsForMacmid ctx = new wbwfleaEncodingsForMacmid(config);
		Randperm randperm = new Randperm();
		byte[][] tmp;

		/* f */
		/* case: r = 0 */
		ctx.f[0] = A.f;
		ctx.fInv[0] = A.fInv;

		/* case: r = 1, ..., MIDTable */
		for (int r = 1; r < ctx.MIDTable - 1; r++)
		{
			for (int j = 0; j < 8; j++)
			{
				tmp = randperm.genRandperm4bits();
				ctx.f[r][0][j] = tmp[0];
				ctx.fInv[r][0][j] = tmp[1];

				tmp = randperm.genRandperm4bits();
				ctx.f[r][1][j] = tmp[0];
				ctx.fInv[r][1][j] = tmp[1];

				tmp = randperm.genRandperm4bits();
				ctx.f[r][2][j] = tmp[0];
				ctx.fInv[r][2][j] = tmp[1];
			}
			ctx.f[r][3] = ctx.f[r-1][0];
			ctx.fInv[r][3] = ctx.fInv[r-1][0];
		}

		/* case: //ex encoding */
		ctx.f[ctx.MIDTable - 1][0] = B.fInv[3];
		ctx.fInv[ctx.MIDTable - 1][0] = B.f[3];

		for (int j = 0; j < 8; j++)
		{
			tmp = randperm.genRandperm4bits();
			ctx.f[ctx.MIDTable - 1][1][j] = tmp[0];
			ctx.fInv[ctx.MIDTable - 1][1][j] = tmp[1];

			tmp = randperm.genRandperm4bits();
			ctx.f[ctx.MIDTable - 1][2][j] = tmp[0];
			ctx.fInv[ctx.MIDTable - 1][2][j] = tmp[1];
		}
		ctx.f[ctx.MIDTable - 1][3] = ctx.f[ctx.MIDTable - 2][0];
		ctx.fInv[ctx.MIDTable - 1][3] = ctx.fInv[ctx.MIDTable - 2][0];

		/* g */
		for (int r = 0; r < ctx.MIDTable; r++)
		{
			for (int j = 0; j < 8; j++)
			{
				tmp = randperm.genRandperm4bits();
				ctx.g[r][0][j] = tmp[0];
				ctx.gInv[r][0][j] = tmp[1];

				tmp = randperm.genRandperm4bits();
				ctx.g[r][1][j] = tmp[0];
				ctx.gInv[r][1][j] = tmp[1];

				tmp = randperm.genRandperm4bits();
				ctx.g[r][2][j] = tmp[0];
				ctx.gInv[r][2][j] = tmp[1];
			}
		}

		/* h */
		/* case: r = 0, ..., Nr - 2 */
		for (int r = 0; r < ctx.MIDTable - 1; r++)
		{
			ctx.h[r][0] = ctx.fInv[r+1][0];
			ctx.hInv[r][0] = ctx.f[r+1][0];
			ctx.h[r][1] = ctx.fInv[r+1][1];
			ctx.hInv[r][1] = ctx.f[r+1][1];
			ctx.h[r][2] = ctx.fInv[r+1][2];
			ctx.hInv[r][2] = ctx.f[r+1][2];
		}
		/* case: exencoding */
		ctx.h[ctx.MIDTable - 1] = B.f;
		ctx.hInv[ctx.MIDTable - 1] = B.fInv;

		/* t */
		for (int r = 0; r < ctx.MIDTable; r++)
		{
			ctx.t[r][0] = randperm.genRandperm1bits();
			ctx.t[r][1] = randperm.genRandperm1bits();
			ctx.t[r][2] = randperm.genRandperm1bits();
		}
		return ctx;
	}

	public wbwfleaEncodingsForMacfirst wbwfleaGenEncodingsForMacfirst(WbwfleaExtEncoding A, WbwfleaExtEncoding B, WbwfleaConfig config) {
		wbwfleaEncodingsForMacfirst ctx = new wbwfleaEncodingsForMacfirst(config);
		Randperm randperm = new Randperm();
		byte[][] tmp;

		/* f */
		/* case: r = 0 */
		ctx.f[0] = A.fInv;
		ctx.fInv[0] = A.f;

		/* case: r = 1, ..., MIDTable */
		for (int r = 1; r < ctx.Table1 - 1; r++)
		{
			for (int j = 0; j < 8; j++)
			{
				tmp = randperm.genRandperm4bits();
				ctx.f[r][0][j] = tmp[0];
				ctx.fInv[r][0][j] = tmp[1];

				tmp = randperm.genRandperm4bits();
				ctx.f[r][1][j] = tmp[0];
				ctx.fInv[r][1][j] = tmp[1];

				tmp = randperm.genRandperm4bits();
				ctx.f[r][2][j] = tmp[0];
				ctx.fInv[r][2][j] = tmp[1];
			}
			ctx.f[r][3] = ctx.f[r-1][0];
			ctx.fInv[r][3] = ctx.fInv[r-1][0];
		}

		/* case: r = Nr - 1 */
		ctx.f[ctx.Table1 - 1][0] = B.f[3];
		ctx.fInv[ctx.Table1 - 1][0] = B.fInv[3];

		for (int j = 0; j < 8; j++)
		{
			tmp = randperm.genRandperm4bits();
			ctx.f[ctx.Table1 - 1][1][j] = tmp[0];
			ctx.fInv[ctx.Table1 - 1][1][j] = tmp[1];

			tmp = randperm.genRandperm4bits();
			ctx.f[ctx.Table1 - 1][2][j] = tmp[0];
			ctx.fInv[ctx.Table1 - 1][2][j] = tmp[1];
		}
		ctx.f[ctx.Table1 - 1][3] = ctx.f[ctx.Table1 - 2][0];
		ctx.fInv[ctx.Table1 - 1][3] = ctx.fInv[ctx.Table1 - 2][0];

		/* g */
		for (int r = 0; r < ctx.Table1; r++)
		{
			for (int j = 0; j < 8; j++)
			{
				tmp = randperm.genRandperm4bits();
				ctx.g[r][0][j] = tmp[0];
				ctx.gInv[r][0][j] = tmp[1];

				tmp = randperm.genRandperm4bits();
				ctx.g[r][1][j] = tmp[0];
				ctx.gInv[r][1][j] = tmp[1];

				tmp = randperm.genRandperm4bits();
				ctx.g[r][2][j] = tmp[0];
				ctx.gInv[r][2][j] = tmp[1];
			}
		}

		/* h */
		/* case: r = 0, ..., Nr - 2 */
		for (int r = 0; r < ctx.Table1 - 1; r++)
		{
			ctx.h[r][0] = ctx.fInv[r+1][0];
			ctx.hInv[r][0] = ctx.f[r+1][0];
			ctx.h[r][1] = ctx.fInv[r+1][1];
			ctx.hInv[r][1] = ctx.f[r+1][1];
			ctx.h[r][2] = ctx.fInv[r+1][2];
			ctx.hInv[r][2] = ctx.f[r+1][2];
		}
		/* case: exencoding */
		ctx.h[ctx.Table1 - 1] = B.fInv;
		ctx.hInv[ctx.Table1 - 1] = B.f;

		/* t */
		for (int r = 0; r < ctx.Table1; r++)
		{
			ctx.t[r][0] = randperm.genRandperm1bits();
			ctx.t[r][1] = randperm.genRandperm1bits();
			ctx.t[r][2] = randperm.genRandperm1bits();
		}
		return ctx;
	}

	public wbwfleaEncodingsForMacend wbwfleaGenEncodingsForMacend(WbwfleaExtEncoding A, WbwfleaExtEncoding B, WbwfleaConfig config) {
		wbwfleaEncodingsForMacend ctx = new wbwfleaEncodingsForMacend(config);
		Randperm randperm = new Randperm();
		byte[][] tmp;

		/* f */
		/* case: r = 0 */
		ctx.f[0] = A.fInv;
		ctx.fInv[0] = A.f;

		/* case: r = 1, ..., MIDTable */
		for (int r = 1; r < ctx.Table2 - 1; r++)
		{
			for (int j = 0; j < 8; j++)
			{
				tmp = randperm.genRandperm4bits();
				ctx.f[r][0][j] = tmp[0];
				ctx.fInv[r][0][j] = tmp[1];

				tmp = randperm.genRandperm4bits();
				ctx.f[r][1][j] = tmp[0];
				ctx.fInv[r][1][j] = tmp[1];

				tmp = randperm.genRandperm4bits();
				ctx.f[r][2][j] = tmp[0];
				ctx.fInv[r][2][j] = tmp[1];
			}
			ctx.f[r][3] = ctx.f[r-1][0];
			ctx.fInv[r][3] = ctx.fInv[r-1][0];
		}

		/* case: r = Nr - 1 */
		ctx.f[ctx.Table2 - 1][0] = B.f[3];
		ctx.fInv[ctx.Table2 - 1][0] = B.fInv[3];

		for (int j = 0; j < 8; j++)
		{
			tmp = randperm.genRandperm4bits();
			ctx.f[ctx.Table2 - 1][1][j] = tmp[0];
			ctx.fInv[ctx.Table2 - 1][1][j] = tmp[1];

			tmp = randperm.genRandperm4bits();
			ctx.f[ctx.Table2 - 1][2][j] = tmp[0];
			ctx.fInv[ctx.Table2 - 1][2][j] = tmp[1];
		}
		ctx.f[ctx.Table2 - 1][3] = ctx.f[ctx.Table2 - 2][0];
		ctx.fInv[ctx.Table2 - 1][3] = ctx.fInv[ctx.Table2 - 2][0];

		/* g */
		for (int r = 0; r < ctx.Table2; r++)
		{
			for (int j = 0; j < 8; j++)
			{
				tmp = randperm.genRandperm4bits();
				ctx.g[r][0][j] = tmp[0];
				ctx.gInv[r][0][j] = tmp[1];

				tmp = randperm.genRandperm4bits();
				ctx.g[r][1][j] = tmp[0];
				ctx.gInv[r][1][j] = tmp[1];

				tmp = randperm.genRandperm4bits();
				ctx.g[r][2][j] = tmp[0];
				ctx.gInv[r][2][j] = tmp[1];
			}
		}

		/* h */
		/* case: r = 0, ..., Nr - 2 */
		for (int r = 0; r < ctx.Table2 - 1; r++)
		{
			ctx.h[r][0] = ctx.fInv[r + 1][0];
			ctx.hInv[r][0] = ctx.f[r + 1][0];
			ctx.h[r][1] = ctx.fInv[r + 1][1];
			ctx.hInv[r][1] = ctx.f[r + 1][1];
			ctx.h[r][2] = ctx.fInv[r + 1][2];
			ctx.hInv[r][2] = ctx.f[r + 1][2];
		}
		/* case: r = Nr - 1 */
		ctx.h[ctx.Table2 - 1] = B.fInv;
		ctx.hInv[ctx.Table2 - 1] = B.f;

		/* t */
		for (int r = 0; r < ctx.Table2; r++)
		{
			ctx.t[r][0] = randperm.genRandperm1bits();
			ctx.t[r][1] = randperm.genRandperm1bits();
			ctx.t[r][2] = randperm.genRandperm1bits();
		}
		return ctx;
	}
}


