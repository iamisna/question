/**
 * @file    Ctrlea.java
 * @brief   Ctrlea java code
 * @author  FDL @ KMU
 * @version 2022.08.07.
 */
package kr.co.vp.common.crypto.wb;

import kr.co.vp.common.crypto.wb.exception.WhiteBoxException;
import kr.co.vp.common.crypto.wb.wflea.*;
import kr.co.vp.common.crypto.wb.random.Randperm;

import java.util.Objects;

public class Ctrlea {
	public WbwfleaEncryptTableWithXor ctrKeyGenEnc(byte[] AeSeed, byte[] CTRHSeed, byte[] CTRGSeed, byte[] key, WbwfleaConfig config) {
		WbwfleaEncryptTableWithXor ctrEncTab = new WbwfleaEncryptTableWithXor(config);

		/* setup: WFLEA context (roundkey generation) */
		Wflea Wflea = new Wflea();
		WfleaCtx wfleaCtx = Wflea.wfleaGenCtx(key, config);

		/* external encoding generation (for encryption) */
		Randperm randperm = new Randperm();
		WbwfleaExtTransform wbwfleaExtTransform = new WbwfleaExtTransform();
		WbwfleaExtEncoding Ae = randperm.genRandperm128Bits(AeSeed);
		WbwfleaExtEncoding Be = wbwfleaExtTransform.wbwfleaGenExtEncoding();

		/* random networked encodings generation (for encryption) */
		WbwfleaEncodings wbwfleaEncodings = new WbwfleaEncodings();
		WbwfleaEncodingsForEncryption encCtx = wbwfleaEncodings.wbwfleaGenEncodingsForEncryption(Ae, Be, config);

		/* encryption table generation with external encoding, random networked encodings, roundkey */
		WbwfleaTables wbwfleaTables = new WbwfleaTables();
		WbwfleaEncryptionTable encTab = wbwfleaTables.wbwfleaGenEncryptionTable(encCtx, wfleaCtx, config);
		ctrEncTab.setEncTab(encTab);

		/*Xor encoding (for encryption) */
		WbwfleaExtEncoding CTRG = randperm.genRandperm128Bits(CTRGSeed);
		WbwfleaExtEncoding CTRH = randperm.genRandperm128Bits(CTRHSeed);

		/*Xor table (for encryption) */
		XorTable ctrExTab = ctrXorDecodingTable(Be,  CTRG,  CTRH);
		ctrEncTab.setExTable(ctrExTab);

		return ctrEncTab;
	}
	public String ctrKeyGenEncBase64(byte[] AeSeed, byte[] CTRHSeed, byte[] CTRGSeed, byte[] key, WbwfleaConfig config) throws WhiteBoxException {
		if((AeSeed.length != 32) || (CTRHSeed.length != 32) || (CTRGSeed.length != 32)) {
			WhiteBoxException e = new WhiteBoxException("2001");
			Common.log.info(e.getErrorCode());
			Common.log.info(e.getMessage());
			throw e;
		} else if (key.length != config.getKEYBYTES()) {
			WhiteBoxException e = new WhiteBoxException("2002");
			Common.log.info(e.getErrorCode());
			Common.log.info(e.getMessage());
			throw e;
		}
		try{
			Cbclea cbclea = new Cbclea();
			Ctrlea ctrlea = new Ctrlea();
			WbwfleaEncryptTableWithXor ctrEncTab = ctrlea.ctrKeyGenEnc(AeSeed, CTRHSeed, CTRGSeed, key, config);
			String encryptTab = cbclea.wbwfleaEncKeyEncodeBase64(ctrEncTab);
			return encryptTab;
		} catch (Exception e) {
			WhiteBoxException wbe = new WhiteBoxException("2980");
			Common.log.info(wbe.getErrorCode());
			Common.log.info(wbe.getMessage());
			throw wbe;
		}
	}

	private WbwfleaEncryptTableWithXor ctrKeyGenDec(byte[] AeSeed, byte[] CTRHSeed, byte[] CTRHdSeed, byte[] key, WbwfleaConfig config)  {
		WbwfleaEncryptTableWithXor ctrDecTab = new WbwfleaEncryptTableWithXor(config);

		/* setup: WFLEA context (roundkey generation) */
		Wflea Wflea = new Wflea();
		WfleaCtx wfleaCtx = Wflea.wfleaGenCtx(key, config);

		/* external encoding generation (for encryption) */
		Randperm randperm = new Randperm();
		WbwfleaExtEncoding Ae = randperm.genRandperm128Bits(AeSeed);

		WbwfleaExtEncoding CTRH = randperm.genRandperm128Bits(CTRHSeed);

		/* external encoding generation (for decryption) */
		WbwfleaExtTransform wbwfleaExtTransform = new WbwfleaExtTransform();
		WbwfleaExtEncoding Bd = wbwfleaExtTransform.wbwfleaGenExtEncoding();

		/* random networked encodings generation (for decryption) */
		WbwfleaEncodings wbwfleaEncodings = new WbwfleaEncodings();
		WbwfleaEncodingsForEncryption decCtx = wbwfleaEncodings.wbwfleaGenEncodingsForEncryption(Ae, Bd, config);

		/* decryption table generation with external encoding, random networked encodings, roundkey */
		WbwfleaTables wbwfleaTables = new WbwfleaTables();
		WbwfleaEncryptionTable decTab = wbwfleaTables.wbwfleaGenEncryptionTable(decCtx, wfleaCtx, config);
		ctrDecTab.setEncTab(decTab);

		/* CTR-table-permutation */
		WbwfleaExtEncoding CTRGd = new WbwfleaExtEncoding();	//CTRGd is inverse of CTRH

		CTRGd.f = CTRH.fInv;
		CTRGd.fInv = CTRH.f;

		WbwfleaExtEncoding CTRHd = randperm.genRandperm128Bits(CTRHdSeed);

		/*Xor table (for decryption) */
		Cbclea cbclea = new Cbclea();
		XorTable ctrExTable = cbclea.xorDecodingTable(Bd, CTRGd, CTRHd);
		ctrDecTab.setExTable(ctrExTable);

		return ctrDecTab;
	}
	public String ctrKeyGenDecBase64(byte[] AeSeed, byte[] CTRHSeed, byte[] CTRHdSeed, byte[] key, WbwfleaConfig config) throws WhiteBoxException {
		if((AeSeed.length != 32) || (CTRHSeed.length != 32) || (CTRHdSeed.length != 32)) {
			WhiteBoxException e = new WhiteBoxException("2008");
			Common.log.info(e.getErrorCode());
			Common.log.info(e.getMessage());
			throw e;
		} else if (key.length != config.getKEYBYTES()) {
			WhiteBoxException e = new WhiteBoxException("2009");
			Common.log.info(e.getErrorCode());
			Common.log.info(e.getMessage());
			throw e;
		}
		try{
			Cbclea cbclea = new Cbclea();
			Ctrlea ctrlea = new Ctrlea();
			WbwfleaEncryptTableWithXor ctrDecTab = ctrlea.ctrKeyGenDec(AeSeed, CTRHSeed, CTRHdSeed, key, config);
			String decryptTab = cbclea.wbwfleaEncKeyEncodeBase64(ctrDecTab);
			return decryptTab;
		} catch (Exception e) {
			WhiteBoxException wbe = new WhiteBoxException("2983");
			Common.log.info(wbe.getErrorCode());
			Common.log.info(wbe.getMessage());
			throw wbe;
		}
	}

	public byte[] ctrLeaWEncoder(final byte[] src, byte[] IV, WbwfleaExtEncoding Ae, byte[] key, WbwfleaConfig config) throws WhiteBoxException {
		if(src.length % 16 != 0) {
			WhiteBoxException e = new WhiteBoxException("2006");
			Common.log.info(e.getErrorCode());
			Common.log.info(e.getMessage());
			throw e;
		} else if (IV.length != 16) {
			WhiteBoxException e = new WhiteBoxException("2007");
			Common.log.info(e.getErrorCode());
			Common.log.info(e.getMessage());
			throw e;
		} else if (key.length != config.getKEYBYTES()) {
			WhiteBoxException e = new WhiteBoxException("2002");
			Common.log.info(e.getErrorCode());
			Common.log.info(e.getMessage());
			throw e;
		}
		try{
			Wflea wflea = new Wflea();
			WfleaCtx ctx = wflea.wfleaGenCtx(key, config);
			if(!Objects.equals(ctx.getErrorCode(), "0000")) {
				WhiteBoxException e = new WhiteBoxException(ctx.getErrorCode());
				Common.log.info(e.getErrorCode());
				Common.log.info(e.getMessage());
				throw e;
			}
			int blklen = src.length / 16;
			byte[] dst = new byte[src.length];
			byte[] enc;
			byte[] dec;
			byte[] inIV = new byte[16];

			System.arraycopy(IV, 0, inIV, 0, 16);

			WbwfleaExtTransform wbwfleaExtTransform = new WbwfleaExtTransform();
			for(int i = 0; i < blklen; i++)     // N-1 blk
			{
				enc = ctrUpdate(inIV);

				enc = wbwfleaExtTransform.wbwfleaExtTransforms(Ae, enc, 1);

				dec = wflea.wfleaEncryptblk4Bits(enc, ctx);

				for(int j=0;j<16;j++)
				{
					dst[16 * i + j] = (byte) (dec[j] ^ src[16*i+j]);
				}
			}
			return dst;
		} catch (Exception e) {
			WhiteBoxException wbe = new WhiteBoxException("2982");
			Common.log.info(wbe.getErrorCode());
			Common.log.info(wbe.getMessage());
			throw wbe;
		}

	}

	public byte[] ctrUpdate(byte[] iv){
		byte[] dst = new byte[16];
		int i = 15;
		while(i >= 0)
		{
			iv[i] = (byte) ((iv[i] + 1) & 0xff);
			if(iv[i] == 0)
			{
				i -= 1;
			}
			else{
				System.arraycopy(iv, 0, dst, 0, 16);
				return dst;
			}
		}
		return dst;
	}

	public XorTable ctrGenEncodingTable(WbwfleaExtEncoding f, WbwfleaExtEncoding g, WbwfleaExtEncoding h)
	{
		XorTable tab = new XorTable();
	    int i, j, l;
	    
	    for(i = 0; i < 4; i++)
	    {
	        for(j = 0; j < 8; j++)
	        {
	            for (l = 0; l < 256; l++)
	            {
	                byte X = (byte) ((l >> 4) & 0xf);
	                byte Y = (byte) ((l) & 0xf);
	                byte Z = (byte) ((f.f[i][j][X])^(g.fInv[i][j][Y]));
	
	                tab.XOR[i][j][l] = h.fInv[i][j][Z];
	            }
	        }
	    }
		return tab;
	}

	public byte[] wbctrLea(WbwfleaEncryptTableWithXor dstTab, byte[] src, byte[] CTR)
	{
		WbwfleaEncrypt wbwfleaEncrypt = new WbwfleaEncrypt();
		Ctrlea ctrlea = new Ctrlea();

	    int blkLen = src.length / 16;           // block length
	    byte[] dst = new byte[src.length];
	    byte[] enc = new byte[16];
		byte[] inCTR = new byte[16];
		byte[] iv;
	    int i, j;

		System.arraycopy(CTR, 0, inCTR, 0, 16);

	    for(i = 0; i < blkLen; i++)     // N-1 blk
	    {
	        for(j = 0; j < 16; j++)
	        {
	            enc[j] = src[16 * i + j];
	        }
			iv = ctrlea.ctrUpdate(inCTR);

			iv = wbwfleaEncrypt.wbwfleaEncryptwb(dstTab.encTab, iv);
	
	        for(j = 0; j < 16; j++)
	        {
				byte tmp = dstTab.ExTable.XOR[j / 4][(2 * j + 1) % 8][(((src[16 * i + j] >> 4) & 0xf) ^ (((iv[j] >> 4) & 0xf) << 4))];
				byte tmp1 = (byte) ((tmp & 0xf) << 4);
				enc[j] = (byte) (tmp1 ^ dstTab.ExTable.XOR[j / 4][(2 * j) % 8][((src[16 * i + j] & 0xf) ^ ((iv[j] & 0xf) << 4))]);
	        }
	
	        for(j = 0; j < 16; j++)
	        {
	        	dst[16 * i + j] = enc[j];
	        }
	    }
	    return dst;
	}
	public byte[] wbctrLeaEncBase64(String tabStr, byte[] src, String ivStr, WbwfleaConfig config) throws WhiteBoxException {
		if((tabStr == null)) {
			WhiteBoxException e = new WhiteBoxException("2005");
			Common.log.info(e.getErrorCode());
			Common.log.info(e.getMessage());
			throw e;
		} else if (src.length % 16 != 0) {
			WhiteBoxException e = new WhiteBoxException("2003");
			Common.log.info(e.getErrorCode());
			Common.log.info(e.getMessage());
			throw e;
		} else if (ivStr.length() != 24) {
			WhiteBoxException e = new WhiteBoxException("2007");
			Common.log.info(e.getErrorCode());
			Common.log.info(e.getMessage());
			throw e;
		}
		try{
			Cbclea cbclea = new Cbclea();
			Ctrlea ctrlea = new Ctrlea();
			Common common = new Common();
			WbwfleaEncryptTableWithXor dstTab = cbclea.wbwfleaEncKeyDecodeBase64(tabStr, config);	// base64로 인코딩된 WB CTR 복호화 테이블을 디코딩하여 사용
			byte[] ctr = common.seedDecodeBase64(ivStr);
			byte[] dst = ctrlea.wbctrLea(dstTab, src, ctr);		// WB CTR 복호화
			return dst;
		} catch (Exception e){
			WhiteBoxException wbe = new WhiteBoxException("2982");
			Common.log.info(wbe.getErrorCode());
			Common.log.info(wbe.getMessage());
			throw wbe;
		}
	}
	public byte[] wbctrLeaDecBase64(String tabStr, byte[] src, String ivStr, WbwfleaConfig config) throws WhiteBoxException {
		if((tabStr == null)) {
			WhiteBoxException e = new WhiteBoxException("2012");
			Common.log.info(e.getErrorCode());
			Common.log.info(e.getMessage());
			throw e;
		} else if (src.length % 16 != 0) {
			WhiteBoxException e = new WhiteBoxException("2013");
			Common.log.info(e.getErrorCode());
			Common.log.info(e.getMessage());
			throw e;
		} else if (ivStr.length() != 24) {
			WhiteBoxException e = new WhiteBoxException("2014");
			Common.log.info(e.getErrorCode());
			Common.log.info(e.getMessage());
			throw e;
		}
		try{
			Cbclea cbclea = new Cbclea();
			Ctrlea ctrlea = new Ctrlea();
			Common common = new Common();
			WbwfleaEncryptTableWithXor dstTab = cbclea.wbwfleaEncKeyDecodeBase64(tabStr, config);	// base64로 인코딩된 WB CTR 복호화 테이블을 디코딩하여 사용
			byte[] ctr = common.seedDecodeBase64(ivStr);
			byte[] dst = ctrlea.wbctrLea(dstTab, src, ctr);		// WB CTR 복호화
			return dst;
		} catch (Exception e){
			WhiteBoxException wbe = new WhiteBoxException("2985");
			Common.log.info(wbe.getErrorCode());
			Common.log.info(wbe.getMessage());
			throw wbe;
		}
	}
	public XorTable ctrXorDecodingTable(WbwfleaExtEncoding f, WbwfleaExtEncoding g, WbwfleaExtEncoding h) {
		XorTable tab = new XorTable();

		int i, j, l;
		for(i = 0; i < 4; i++)
		{
			for(j = 0; j < 8; j++)
			{
				for (l = 0; l < 256; l++)
				{
					byte X = (byte) ((l >> 4) & 0xf);
					byte Y = (byte) ((l) & 0xf);
					byte Z = (byte) ((f.f[i][j][X]) ^ (g.fInv[i][j][Y]));

					tab.XOR[i][j][l] = h.f[i][j][Z];
				}
			}
		}
		return tab;
	}

	public byte[] wbCtrLeaEncryptFromBase64(String encStr, byte[] data, String ivBase64, String CTRGSeedBase64, WbwfleaConfig config) throws WhiteBoxException {
		Cbclea cbclea = new Cbclea();
		Ctrlea ctrlea = new Ctrlea();
		Padding padding = cbclea.encodeBase64(data, CTRGSeedBase64);			// WB CBC 패딩. 얼마나 패딩했는지 배열 마지막에 붙여서 리턴.

		int wbDataLen = data.length + padding.getPadNum(); // 패딩된 메시지 길이 = 메시지 길이 + 얼마나 패딩했는지 (배열 마지막 값)
		byte[] encodedMsg = new byte[wbDataLen];
		System.arraycopy(padding.getPaddedMsg(), 0, encodedMsg, 0, wbDataLen);	// 패딩된 메시지만 복사하여 사용

		/*WB CTR lea encryption*/
		byte[] dst  = ctrlea.wbctrLeaEncBase64(encStr, encodedMsg, ivBase64, config);			// WB CTR 암호화 base64
		return dst;
	}

	public byte[] wbCtrLeaDecryptFromBase64(String decStr, byte[] data, String ivBase64, String CTRHdSeedBase64, WbwfleaConfig config) throws WhiteBoxException {
		Ctrlea ctrlea = new Ctrlea();
		Cbclea cbclea = new Cbclea();
		byte[] encodedMsg = ctrlea.wbctrLeaDecBase64(decStr, data, ivBase64, config);	// WB CTR 복호화 base64

		Padding padding = cbclea.decodeBase64(encodedMsg, CTRHdSeedBase64);		//PADDING 제거. 얼마나 패딩을 제거했는지 배열 마지막에 함께 리턴.

		/* 패딩 제거된 메시지 길이 = 메시지 길이 - 얼마나 패딩을 제거했는지 (배열 마지막 값) */
		int wbDataLen = encodedMsg.length - padding.getPadNum();
		byte[] dst = new byte[wbDataLen];
		System.arraycopy(padding.getPaddedMsg(), 0, dst, 0, wbDataLen); // 패딩 제거된 메시지만 복사하여 사용

		return dst;
	}
}
