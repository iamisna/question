package kr.co.vp.common.crypto.wb.exception;

import java.util.Collections;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public enum ErrorCodeVO {

    END_LGIC_NORM_0000("0000", "정상종료"),
    ERR_ENC_TBL_PARM_2001("2001", "시드 length 오류"),
    ERR_ENC_TBL_PARM_2002("2002", "키 length 오류"),
    ERR_ENC_PDNG_PARM_2003("2003", "평문 length 오류"),
    ERR_ENC_PDNG_PARM_2004("2004", "IV length 오류"),
    ERR_ENC_PRCS_PARM_2005("2005", "키 테이블 오류"),
    ERR_ENC_PRCS_PARM_2006("2006", "평문 length 오류"),
    ERR_ENC_PRCS_PARM_2007("2007", "IV length 오류"),
    ERR_ENC_TBL_FAIL_2980("2980", "암호화 키테이블 생성 오류"),
    ERR_ENC_PDNG_FAIL_2981("2981", "암호화 패딩 오류"),
    ERR_ENC_PRCS_FAIL_2982("2982", "암호화 실패"),
    ERR_DEC_TBL_PARM_2008("2008", "시드 length 오류"),
    ERR_DEC_TBL_PARM_2009("2009", "키 length 오류"),
    ERR_DEC_PDNG_PARM_2010("2010", "평문 length 오류"),
    ERR_DEC_PDNG_PARM_2011("2011", "시드 length 오류"),
    ERR_DEC_PRCS_PARM_2012("2012", "키 테이블 오류"),
    ERR_DEC_PRCS_PARM_2013("2013", "평문 length 오류"),
    ERR_DEC_PRCS_PARM_2014("2014", "IV length 오류"),
    ERR_DEC_TBL_FAIL_2983("2983", "복호화 키테이블 생성 오류"),
    ERR_DEC_PDNG_FAIL_2984("2984", "복호화 패딩 오류"),
    ERR_DEC_PRCS_FAIL_2985("2985", "복호화 실패"),
    ERR_SIGN_CRET_TBL_PARM_2015("2015", "시드 length 오류"),
    ERR_SIGN_CRET_TBL_PARM_2016("2016", "키 length 오류"),
    ERR_SIGN_CRET_TBL_PARM_2017("2017", "IV length 오류"),
    ERR_SIGN_CRET_PDNG_PARM_2018("2018", "평문 length 오류"),
    ERR_SIGN_CRET_PRCS_PARM_2019("2019", "평문 length 오류"),
    ERR_SIGN_CRET_PRCS_PARM_2020("2020", "키 테이블 오류"),
    ERR_SIGN_CRET_TBL_FAIL_2986("2986", "암호화 키테이블 생성 오류"),
    ERR_SIGN_CRET_PDNG_FAIL_2987("2987", "서명 생성 패딩 오류"),
    ERR_SIGN_CRET_PRCS_FAIL_2988("2988", "서명값 생성 실패"),
    ERR_SIGN_VFC_PDNG_PARM_2021("2021", "평문 length 오류"),
    ERR_SIGN_VFC_PRCS_PARM_2022("2022", "평문 length 오류"),
    ERR_SIGN_VFC_PRCS_PARM_2023("2023", "IV length 오류"),
    ERR_SIGN_VFC_PRCS_PARM_2024("2024", "Tag length 오류"),
    ERR_SIGN_VFC_PRCS_PARM_2025("2025", "시드 length 오류"),
    ERR_SIGN_VFC_PRCS_PARM_2026("2026", "키 length 오류"),
    ERR_SIGN_VFC_PDNG_FAIL_2989("2089", "서명 검증 패딩 오류"),
    ERR_SIGN_VFC_PRCS_FAIL_2990("2990", "서명값 검증 실패"),
    ERR_SHA_LGIC_FUNC_2027("2027", "함수설정 오류"),
    ERROR("9999", "System Error");

    public String code;
    public String message;

    ErrorCodeVO(String code, String message) {
        this.code = code;
        this.message = message;
    }

    public String getCode() {
        return code;
    }
    public String getMessage() {
        return message;
    }

    private static final Map<String, ErrorCodeVO> descriptions =
            Collections.unmodifiableMap(Stream.of(values()).collect(Collectors.toMap(
                    ErrorCodeVO::getCode, Function.identity())));

    public static ErrorCodeVO find(String code) {
        return Optional.ofNullable( descriptions.get(code)).orElse(descriptions.get("9999"));
    }
}
