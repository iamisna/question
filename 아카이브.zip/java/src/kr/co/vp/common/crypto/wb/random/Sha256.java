/**
 * @file    Sha256.java
 * @brief   sha256
 * @author  FDL @ KMU
 * @version 2022.08.07.
 */
package kr.co.vp.common.crypto.wb.random;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class Sha256 {
	public byte[] sha256Hash(byte[] data) throws NoSuchAlgorithmException {
        String algorithm = "SHA-256";
        MessageDigest messageDigest = MessageDigest.getInstance(algorithm);
        return messageDigest.digest(data);
    }
}
