/**
 * @file    WbwfleaExtTransform.java
 * @brief   Whitebox WF-LEA java code: External encoding
 * @author  FDL @ KMU
 * @version 2022.08.06.
 */
package kr.co.vp.common.crypto.wb.wflea;

import kr.co.vp.common.crypto.wb.random.Randperm;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Base64.Encoder;

public class WbwfleaExtTransform {

	/**
	 * @return generate external encoding
	 */
	public WbwfleaExtEncoding wbwfleaGenExtEncoding() {
		WbwfleaExtEncoding ctx = new WbwfleaExtEncoding();
		Randperm randperm = new Randperm();
		byte[][] tmp;
		for(int i = 0; i < 4; i++) {
			for (int j = 0; j < 8; j++) {
				tmp = randperm.genRandperm4bits();
				ctx.f[i][j] = tmp[0];
				ctx.fInv[i][j] = tmp[1];
			}
		}
		return ctx;
	}

	/**
	 * @return generate identity external encoding
	 */
	public WbwfleaExtEncoding wbwfleaGenExtIdentityEncoding() {
		WbwfleaExtEncoding ctx = new WbwfleaExtEncoding();
		Randperm randperm = new Randperm();
		for(int i = 0; i < 4; i++) {
			for (int j = 0; j < 8; j++) {
				ctx.fInv[i][j] = randperm.idenGenRandperm4bits(ctx.f[i][j]);
			}
		}
		return ctx;
	}

	/**
	 * @param ctx external encoding
	 * @param src state
	 * @param flag do f if flag = 0, do f_inv if flag != 0
	 * @return Whitebox WFLEA external encoding
	 */
	public byte[] wbwfleaExtTransforms(WbwfleaExtEncoding ctx, byte[] src, int flag) {
		Common common = new Common();

		int[] srcInt = common.wordToInt(src);
		for(int i = 0; i < 4; i++)
	    {
	        int T = 0;
	        for(int j = 0; j < 8; j++)
	        {
	            int tmp;
	            if (flag == 0) {
	                tmp = ctx.f[i][j][(srcInt[i] >>> (4 * j)) & 0xf];
	            }
	            else {
	                tmp = ctx.fInv[i][j][(srcInt[i] >>> (4 * j)) & 0xf];
	            }
	            T ^= tmp << (4 * j);
	        }
			srcInt[i] = T;
	    }
		byte[] dst = common.intToWord(srcInt);
		return dst;
	}
}

