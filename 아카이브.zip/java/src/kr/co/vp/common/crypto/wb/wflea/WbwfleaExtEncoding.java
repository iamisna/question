/**
 * @file    WbwfleaExtEncoding.java
 * @brief   WbwfleaExtEncoding
 * @author  FDL @ KMU
 * @version 2022.08.06.
 */
package kr.co.vp.common.crypto.wb.wflea;

public class WbwfleaExtEncoding {
    /*
    f: input(or output) encoding
        f = (f[0], f[1], f[2], f[3])
        f[i] = diag(f[i][7],...,f[i][0])    i = 0,1,2,3
        f[i][j]: 4-bit permutation          j = 0,1,2,3,4,5,6,7
	 */
    public byte[][][] f = new byte[4][8][16];
    public byte[][][] fInv = new byte[4][8][16];
}
