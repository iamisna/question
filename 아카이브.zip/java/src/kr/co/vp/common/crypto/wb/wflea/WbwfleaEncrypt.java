/**
 * @file    WbwfleaEncrypt.java
 * @brief   Whitebox WF-LEA java code: Encryption/Decryption
 * @author  FDL @ KMU
 * @version 2022.08.06.
 */
package kr.co.vp.common.crypto.wb.wflea;

import java.util.Base64;

public class WbwfleaEncrypt {
	private int wbwfleaAddWb(WbwfleaEncryptionTable encTab, int r, int i, int x, int y) {
		Wflea wflea = new Wflea();
	    byte c = 0;
	    int z = 0;
	    for (int j = 0; j < 8; j++)
	    {
	        int cxy = (c << 8) ^ (wflea.getJthNibble(x, j) << 4) ^ (wflea.getJthNibble(y, j));
	        byte tmp = encTab.ETA[r][i][j][cxy];
	        c = (byte) ((tmp >> 4) & 0x1);
	        z ^= ((tmp & 0xf) << (4 * j));
	    }
	    return z;
	}
	
	private int wbwfleaRol9Wb(WbwfleaEncryptionTable encTab, int r, int x)
	{
		Wflea wflea = new Wflea();
		int y = 0;
	    for (int j = 0; j < 8; j++)
	    {
	        int xy = (wflea.getJthNibble(x, (j + 6) % 8) << 4) ^ (wflea.getJthNibble(x, (j + 5) % 8));

	        byte tmp = encTab.ETR[r][0][j][xy];
	        y ^= ((tmp & 0xf) << (4 * j));
	    }
	    return y;
	}
	
	private int wbwfleaRor9Wb(WbwfleaDecryptionTable decTab, int r, int x)
	{
		Wflea wflea = new Wflea();
		int y = 0;
	    for (int j = 0; j < 8; j++)
	    {
	        int xy = (wflea.getJthNibble(x, (j + 3) % 8) << 4) ^ (wflea.getJthNibble(x, (j + 2) % 8));
	        byte tmp = decTab.DTR[r][0][j][xy];
	        y ^= ((tmp & 0xf) << (4 * j));
	    }
	    return y;
	}
	
	private int wbwfleaRor5Wb(WbwfleaEncryptionTable encTab, int r, int x)
	{
		Wflea wflea = new Wflea();
		int y = 0;
	    for (int j = 0; j < 8; j++)
	    {
	        int xy = (wflea.getJthNibble(x, (j + 2) % 8) << 4) ^ (wflea.getJthNibble(x, (j + 1) % 8));
	        byte tmp = encTab.ETR[r][1][j][xy];
	        y ^= ((tmp & 0xf) << (4 * j));
	    }
	    return y;
	}
	
	private int wbwfleaRol5Wb(WbwfleaDecryptionTable decTab, int r, int x)
	{
		Wflea wflea = new Wflea();
		int y = 0;
	    for (int j = 0; j < 8; j++)
	    {
	        int xy = (wflea.getJthNibble(x, (j + 7) % 8) << 4) ^ (wflea.getJthNibble(x, (j + 6) % 8));
	        byte tmp = decTab.DTR[r][1][j][xy];
	        y ^= ((tmp & 0xf) << (4 * j));
	    }
	    return y;
	}
	
	private int wbwfleaRor3Wb(WbwfleaEncryptionTable encTab, int r, int x)
	{
		Wflea wflea = new Wflea();
		int y = 0;
	    for (int j = 0; j < 8; j++)
	    {
	        int xy = (wflea.getJthNibble(x, (j + 1) % 8) << 4) ^ (wflea.getJthNibble(x, j));
	        byte tmp = encTab.ETR[r][2][j][xy];
	        y ^= ((tmp & 0xf) << (4 * j));
	    }
	    return y;
	}
	
	private int wbwfleaRol3Wb(WbwfleaDecryptionTable decTab, int r, int x)
	{
		Wflea wflea = new Wflea();
		int j;
	    int y = 0;
	    for (j = 0; j < 8; j++)
	    {
	        int xy = (wflea.getJthNibble(x, j) << 4) ^ (wflea.getJthNibble(x, (j + 7) % 8));
	        byte tmp = decTab.DTR[r][2][j][xy];
	        y ^= ((tmp & 0xf) << (4 * j));
	    }
	    return y;
	}
	
	private int wbwfleaSubWb(WbwfleaDecryptionTable decTab, int r, int i, int x, int y)
	{
		Wflea wflea = new Wflea();
		byte b = 0;
	    int z = 0;
	    for (int j = 0; j < 8; j++)
	    {
	        int bxy = (b << 8) ^ (wflea.getJthNibble(x, j) << 4) ^ (wflea.getJthNibble(y, j));
	        byte tmp = decTab.DTS[r][i][j][bxy];
	        b = (byte) ((tmp >> 4) & 0x1);
	        z ^= ((tmp & 0xf) << (4 * j));
	    }
	    return z;
	}
	
	private int[] wbwfleaRoundWb(WbwfleaEncryptionTable encTab, int r, int[] x)
	{
		WbwfleaEncrypt wbwfleaEncrypt = new WbwfleaEncrypt();
	    int tmp = x[0];
	    int t;
	    int[] dst = new int[4];

	    t = wbwfleaEncrypt.wbwfleaAddWb(encTab, r, 0, x[0], x[1]);
	    dst[0] = wbwfleaEncrypt.wbwfleaRol9Wb(encTab, r, t);
	    t = wbwfleaEncrypt.wbwfleaAddWb(encTab, r, 1, x[1], x[2]);
	    dst[1] = wbwfleaEncrypt.wbwfleaRor5Wb(encTab, r, t);
	    t = wbwfleaEncrypt.wbwfleaAddWb(encTab, r, 2, x[2], x[3]);
	    dst[2] = wbwfleaEncrypt.wbwfleaRor3Wb(encTab, r, t);
	    dst[3] = tmp;
	    
	    return dst;
	}

	private int[] wbwfleaInvRoundWb(WbwfleaDecryptionTable decTab, int r, int[] x)
	{
		WbwfleaEncrypt wbwfleaEncrypt = new WbwfleaEncrypt();
	    int tmp = x[3];
	    int t;
	    int[] dst = new int[4];
	
	    t = wbwfleaEncrypt.wbwfleaRor9Wb(decTab, r, x[0]);
	    dst[0] = wbwfleaEncrypt.wbwfleaSubWb(decTab, r, 0, t, x[3]);
	    t = wbwfleaEncrypt.wbwfleaRol5Wb(decTab, r, x[1]);
	    dst[1] = wbwfleaEncrypt.wbwfleaSubWb(decTab, r, 1, t, dst[0]);
	    t = wbwfleaEncrypt.wbwfleaRol3Wb(decTab, r, x[2]);
	    dst[2] = wbwfleaEncrypt.wbwfleaSubWb(decTab, r, 2, t, dst[1]);

	    dst[3] = dst[2];
	    dst[2] = dst[1];
	    dst[1] = dst[0];
	    dst[0] = tmp;
	    
	    return dst;
	}

	/**
	 * Whitebox WFLEA encryption
	 * @param encTab encryption table
	 * @param x 16-byte data
	 * @return 16-byte data
	 */
	public byte[] wbwfleaEncryptwb(WbwfleaEncryptionTable encTab, byte[] x)
	{
		Common common = new Common();
		WbwfleaEncrypt wbwfleaEncrypt = new WbwfleaEncrypt();

		int[] xInt = common.wordToInt(x);
	    for (int r = 0; r < encTab.getRounds(); r++)
	    {
	    	xInt = wbwfleaEncrypt.wbwfleaRoundWb(encTab, r, xInt);
	    }
		byte[] dst = common.intToWord(xInt);
	    
	    return dst;
	}

	public WbwfleaEncryptionTable encryptTabDecodeBase64(String str, WbwfleaConfig config){
		Base64.Decoder base64Decoder = Base64.getDecoder();
		WbwfleaEncryptionTable encTab = new WbwfleaEncryptionTable(config);

		int i, j, k, l;

		byte[] tmp = base64Decoder.decode(str);
		for(i = 0; i < encTab.getRounds(); i++) {
			for(j = 0; j < 3; j++) {
				for(k = 0 ; k < 8; k++) {
					for(l = 0; l < 512; l++) {
						encTab.ETA[i][j][k][l] = tmp[(i * 3 * 8 * 512) + (j * 8 * 512) + (k * 512) + l];
					}
				}
			}
		}
		for(i = 0; i < encTab.getRounds(); i++) {
			for(j = 0; j < 3; j++) {
				for(k = 0 ; k < 8; k++) {
					for(l = 0; l < 256; l++) {
						encTab.ETR[i][j][k][l] = tmp[(encTab.getRounds() * 3 * 8 * 512) + (i * 3 * 8 * 256) + (j * 8 * 256) + (k * 256) + l];
					}
				}
			}
		}
		return encTab;
	}
	public byte[] wbwfleaEncryptwbBase64(String encStr, byte[] src, WbwfleaConfig config)
	{
		WbwfleaEncrypt wbwfleaEncrypt = new WbwfleaEncrypt();
		WbwfleaEncryptionTable encTab = wbwfleaEncrypt.encryptTabDecodeBase64(encStr, config);
		byte[] dst = wbwfleaEncrypt.wbwfleaEncryptwb(encTab, src);
		return dst;
	}

	/**
	 * Whitebox WFLEA decryption
	 * @param decTab decryption table
	 * @param x 16-byte data
	 * @return 16-byte data
	 */
	public byte[] wbwfleaDecryptwb(WbwfleaDecryptionTable decTab, byte[] x) {
		Common common = new Common();
		WbwfleaEncrypt wbwfleaEncrypt = new WbwfleaEncrypt();

		int[] xInt = common.wordToInt(x);
	    for (int r = 0; r < decTab.wbwfleaRounds; r++)
	    {
	    	xInt = wbwfleaEncrypt.wbwfleaInvRoundWb(decTab, r, xInt);
	    }
		byte[] dst = common.intToWord(xInt);
	    
	    return dst;
	}
	public byte[] wbwfleaDecryptwbBase64(String decStr, byte[] src, WbwfleaConfig config) {
		WbwfleaEncrypt wbwfleaEncrypt = new WbwfleaEncrypt();
		WbwfleaDecryptionTable decTab = decryptTabDecodeBase64(decStr, config);
		byte[] dst = wbwfleaEncrypt.wbwfleaDecryptwb(decTab, src);
		return dst;
	}

	public WbwfleaDecryptionTable decryptTabDecodeBase64(String str, WbwfleaConfig config) {
		Base64.Decoder base64Decoder = Base64.getDecoder();
		WbwfleaDecryptionTable decTab = new WbwfleaDecryptionTable(config);

		int i, j, k, l;

		byte[] tmp = base64Decoder.decode(str);
		for(i = 0; i < decTab.wbwfleaRounds; i++) {
			for(j = 0; j < 3; j++) {
				for(k = 0 ; k < 8; k++) {
					for(l = 0; l < 256; l++) {
						decTab.DTR[i][j][k][l] = tmp[(i * 3 * 8 * 256) + (j * 8 * 256) + (k * 256) + l];
					}
				}
			}
		}
		for(i = 0; i < decTab.wbwfleaRounds; i++) {
			for(j = 0; j < 3; j++) {
				for(k = 0 ; k < 8; k++) {
					for(l = 0; l < 512; l++) {
						decTab.DTS[i][j][k][l] = tmp[(decTab.wbwfleaRounds * 3 * 8 * 256) + (i * 3 * 8 * 512) + (j * 8 * 512) + (k * 512) + l];
					}
				}
			}
		}
		return decTab;
	}

	/**
	 * Whitebox WFLEA encryption (WK1 + WK2)
	 * @param wk1Tab WK1 encryption table
	 * @param wk2Tab WK2 encryption table
	 * @param src 16-byte data
	 * @return 16-byte data
	 */
	public byte[] wbwfleaSepEncryptwb(wbwfleaMacWK1 wk1Tab, wbwfleaMacWK2 wk2Tab, byte[] src, WbwfleaConfig config)
	{
	    int r;
		byte[] dst = new byte[16];

		for (r = 0; r < config.getTable1(); r++)
	    {
			src = wbwfleaByteRoundwb(wk2Tab.ETA[r], wk2Tab.ETR[r], src);
	    }
		for (r = config.getTable1(); r < config.getROUNDS() - config.getTable2(); r++)
	    {
			src = wbwfleaByteRoundwb(wk1Tab.ETA[r - config.getTable1()], wk1Tab.ETR[r - config.getTable1()], src);
	    }
	    for (r = config.getROUNDS() - config.getTable2(); r < config.getROUNDS(); r++)
	    {
			src = wbwfleaByteRoundwb(wk2Tab.ETA[r - config.getMIDTable()], wk2Tab.ETR[r - config.getMIDTable()], src);
		}
		System.arraycopy(src, 0, dst, 0, 16);

		return dst;
	}

	private byte[] wbwfleaByteRoundwb(byte[][][] ETA, byte[][][] ETR, byte[] src)
	{
		Common common = new Common();
		int[] srcInt = common.wordToInt(src);
		int tmp = srcInt[0];
	    int T;

	    T = wbwfleaByteAddwb(ETA, 0, srcInt[0], srcInt[1]);
		srcInt[0] = wbwfleaByteRol9Wb(ETR, T);
	    
	    T = wbwfleaByteAddwb(ETA, 1, srcInt[1], srcInt[2]);
		srcInt[1] = wbwfleaByteRor5Wb(ETR, T);

	    T = wbwfleaByteAddwb(ETA, 2, srcInt[2], srcInt[3]);
		srcInt[2] = wbwfleaByteRor3Wb(ETR, T);

		srcInt[3] = tmp;

		byte[] dst = common.intToWord(srcInt);
		return dst;
	}
	private int wbwfleaByteAddwb(byte[][][] ETA, int i, int X, int Y)
	{
		Wflea wflea = new Wflea();
	    byte c = 0;
	    int Z = 0;
	    for (int j = 0; j < 8; j++)
	    {
	        int cXY = (c << 8) ^ (wflea.getJthNibble(X, j) << 4) ^ (wflea.getJthNibble(Y, j));
	        byte tmp = ETA[i][j][cXY];
	        c = (byte) ((tmp >>> 4) & 0x1);
	        Z ^= ((tmp & 0xf) << (4*j));
	    }
	    return Z;
	}
	
	private int wbwfleaByteRol9Wb(byte[][][] ETR, int X)
	{
		Wflea wflea = new Wflea();
	    int Y = 0;
	    for (int j = 0; j < 8; j++)
	    {
	        int XY = (wflea.getJthNibble(X, (j + 6) % 8) << 4) ^ (wflea.getJthNibble(X, (j + 5) % 8));
	        byte tmp = ETR[0][j][XY];
	        Y ^= ((tmp & 0xf) << (4 * j));
	    }
	    return Y;
	}
	
	private int wbwfleaByteRor5Wb(byte[][][] ETR, int X)
	{
		Wflea wflea = new Wflea();
	    int Y = 0;
	    for (int j = 0; j < 8; j++)
	    {
	        int XY = (wflea.getJthNibble(X, (j + 2) % 8) << 4) ^ (wflea.getJthNibble(X, (j + 1) % 8));
	        byte tmp = ETR[1][j][XY];
	        Y ^= ((tmp & 0xf) << (4 * j));
	    }
	    return Y;
	}
	
	private int wbwfleaByteRor3Wb(byte[][][] ETR, int X)
	{
		Wflea wflea = new Wflea();
		int j;
	    int Y = 0;
	    for (j = 0; j < 8; j++)
	    {
	        int XY = (wflea.getJthNibble(X, (j + 1) % 8) << 4) ^ (wflea.getJthNibble(X, j));
	        byte tmp = ETR[2][j][XY];
	        Y ^= ((tmp & 0xf) << (4*j));
	    }
	    return Y;
	}
}
