/**
 * @file    WbwfleaTables.java
 * @brief   Whitebox WF-LEA java code: Table generation
 * @author  FDL @ KMU
 * @version 2022.08.06.
 */
package kr.co.vp.common.crypto.wb.wflea;

import kr.co.vp.common.crypto.wb.XorTable;
import kr.co.vp.common.crypto.wb.mac.wbwfleaEncodingsForMacend;
import kr.co.vp.common.crypto.wb.mac.wbwfleaEncodingsForMacfirst;
import kr.co.vp.common.crypto.wb.mac.wbwfleaEncodingsForMacmid;

import java.util.Base64;

public class WbwfleaTables {
	private byte wbwfleaAddwb(int i, int j, byte[] f0, byte[] f1, byte[] g, int k, int l, byte y, byte X0, byte X1) {
		Wflea wflea = new Wflea();
		byte cZ = (byte) wflea.add((y ^ i), (f0[X0] ^ k), (f1[X1] ^ l));
	    cZ = (byte) ((((cZ >> 4) ^ j) << 4) ^ g[(cZ) & 0xf]);
	    return cZ;
	}
	private byte wbwfleaSubwb(int i, int j, byte[] f0, byte[] f1, byte[] g, int k, int l, byte y, byte X0, byte X1) {
		Wflea wflea = new Wflea();
		byte bZ = (byte) wflea.sub((y ^ i), f0[X0], (f1[X1] ^ k));
	    bZ = (byte) ((((bZ >> 4) ^ j) << 4) ^ (g[((bZ) & 0xf) ^ l]));
	    return bZ;
	}
	private byte wbwfleaRolwb(byte l, byte[] f, byte[] g, byte[] h, byte X, byte Y)
	{
		Wflea wflea = new Wflea();
		byte Z = (byte) wflea.rol(f[X], g[Y], l);
	    Z = h[Z];
	    return Z;
	}
	private byte wbwfleaRorwb(byte l, byte[] f, byte[] g, byte[] h, byte X, byte Y)
	{
		Wflea wflea = new Wflea();
		byte Z = (byte) wflea.ror(f[X], g[Y], l);
	    Z = h[Z];
	    return Z;
	}

	/**
	 * @param encCtx random encodings
	 * @param wfleaCtx WFLEA context (roundkeys)
	 * @return Encryption table generation for Whitebox WFLEA
	 */
	public WbwfleaEncryptionTable wbwfleaGenEncryptionTable(WbwfleaEncodingsForEncryption encCtx, WfleaCtx wfleaCtx, WbwfleaConfig config) {
		WbwfleaEncryptionTable tab = new WbwfleaEncryptionTable(config);
		WbwfleaTables wbwfleaTables = new WbwfleaTables();

		for (int r = 0; r < config.getROUNDS(); r++)
	    {
	        for(int j = 0; j < 8; j++)
	        {
	            /* ETA */
	            for(int i = 0; i < 3; i++)
	            {
	                for (int l = 0; l < 512; l++)
	                {
	                    byte c = (byte) ((l >> 8) & 0x1);
	                    byte X = (byte) ((l >> 4) & 0xf);
	                    byte Y = (byte) ((l) & 0xf);
	                    tab.ETA[r][i][j][l] = wbwfleaTables.wbwfleaAddwb(
	                        (j == 0) ? 0 : (encCtx.t[r][i] >> (j - 1)) & 0x1,
	                        (encCtx.t[r][i] >> j) & 0x1,
	                        encCtx.f[r][i][j],
	                        encCtx.f[r][i+1][j],
	                        encCtx.gInv[r][i][j],
	                        (wfleaCtx.rndKey[r][2 * i]     >> (4 * j)) & 0xf,
	                        (wfleaCtx.rndKey[r][2 * i + 1] >> (4 * j)) & 0xf,
	                        c, X, Y);
	                }
	            }
	            /* ETR */
	            for (int l = 0; l < 256; l++)
	            {
	                byte X = (byte) ((l >> 4) & 0xf);
	                byte Y = (byte) ((l) & 0xf);

	                tab.ETR[r][0][j][l] = wbwfleaTables.wbwfleaRolwb(
	                    (byte) 1,
	                    encCtx.g[r][0][(j + 6) % 8],
	                    encCtx.g[r][0][(j + 5) % 8],
	                    encCtx.h[r][0][j],
	                    X, Y);

	                tab.ETR[r][1][j][l] = wbwfleaTables.wbwfleaRorwb(
	                    (byte) 1,
	                    encCtx.g[r][1][(j + 2) % 8],
	                    encCtx.g[r][1][(j + 1) % 8],
	                    encCtx.h[r][1][j],
	                    X, Y);

	                tab.ETR[r][2][j][l] = wbwfleaTables.wbwfleaRorwb(
	                    (byte) 3,
	                    encCtx.g[r][2][(j + 1) % 8],
	                    encCtx.g[r][2][j],
	                    encCtx.h[r][2][j],
	                    X, Y);
	            }
	        }
	    }
		return tab;
	}

	private String encryptTabEncodeBase64(WbwfleaEncryptionTable encTab, WbwfleaConfig config) {
		Base64.Encoder base64Encoder = Base64.getEncoder();

		byte[] tmp = new byte[config.getROUNDS() * 3 * 8 * (256 + 512)];

		int i, j, k, l;

		for(i = 0; i < config.getROUNDS(); i++) {
			for(j = 0; j < 3; j++) {
				for(k = 0 ; k < 8; k++) {
					for(l = 0; l < 512; l++) {
						tmp[(i * 3 * 8 * 512) + (j * 8 * 512) + (k * 512) + l] = encTab.ETA[i][j][k][l];
					}
				}
			}
		}
		for(i = 0; i < config.getROUNDS(); i++) {
			for(j = 0; j < 3; j++) {
				for(k = 0 ; k < 8; k++) {
					for(l = 0; l < 256; l++) {
						tmp[(config.getROUNDS() * 3 * 8 * 512) + (i * 3 * 8 * 256) + (j * 8 * 256) + (k * 256) + l] = encTab.ETR[i][j][k][l];
					}
				}
			}
		}
		String encodingDat = base64Encoder.encodeToString(tmp);
		return encodingDat;

	}
	public String wbwfleaGenEncryptionTableBase64(WbwfleaEncodingsForEncryption encCtx, WfleaCtx wfleaCtx, WbwfleaConfig config) {
		WbwfleaTables wbwfleaTables = new WbwfleaTables();
		WbwfleaEncryptionTable encTab = wbwfleaTables.wbwfleaGenEncryptionTable(encCtx, wfleaCtx, config);
		String encTabStr = wbwfleaTables.encryptTabEncodeBase64(encTab, config);
		return encTabStr;
	}

	/**
	 * @param decCtx random encodings
	 * @param wfleaCtx WFLEA context (roundkeys)
	 * @return	Decryption table generation for Whitebox WFLEA
	 */
	public WbwfleaDecryptionTable wbwfleaGenDecryptionTable(WbwfleaEncodingsForDecryption decCtx, WfleaCtx wfleaCtx) {
		WbwfleaDecryptionTable tab = new WbwfleaDecryptionTable(decCtx);
		WbwfleaTables wbwfleaTables = new WbwfleaTables();
		for (int r = 0; r < tab.wbwfleaRounds; r++)
	    {
	        for(int j = 0; j < 8; j++)
	        {
	            /* DTR */
	            for(int l = 0; l < 256; l++)
	            {
	            	byte X = (byte) ((l >> 4) & 0xf);
	                byte Y = (byte) ((l) & 0xf);

	                tab.DTR[r][0][j][l] = wbwfleaTables.wbwfleaRorwb(
	                    (byte) 1,
	                    decCtx.f[r][0][(j + 3) % 8],
	                    decCtx.f[r][0][(j + 2) % 8],
	                    decCtx.gInv[r][0][j],
	                    X, Y);
	                
	                tab.DTR[r][1][j][l] = wbwfleaTables.wbwfleaRolwb(
	                    (byte) 1,
	                    decCtx.f[r][1][(j + 7) % 8],
	                    decCtx.f[r][1][(j + 6) % 8],
	                    decCtx.gInv[r][1][j],
	                    X, Y);

	                tab.DTR[r][2][j][l] = wbwfleaTables.wbwfleaRolwb(
	                    (byte) 3,
	                    decCtx.f[r][2][j],
	                    decCtx.f[r][2][(j + 7) % 8],
	                    decCtx.gInv[r][2][j],
	                    X, Y);
	            }

	            /* DTS */
	            for (int l = 0; l < 512; l++)
	            {
	                byte b = (byte) ((l >> 8) & 0x1);
	                byte X = (byte) ((l >> 4) & 0xf);
	                byte Y = (byte) ((l) & 0xf);

	                tab.DTS[r][0][j][l] = wbwfleaTables.wbwfleaSubwb(
	                    (j == 0) ? 0 : (decCtx.t[r][0] >> (j - 1)) & 0x1,
	                    (decCtx.t[r][0] >> j) & 0x1,
	                    decCtx.g[r][0][j],
	                    decCtx.h[r][0][j],
	                    decCtx.h[r][1][j],
	                    (wfleaCtx.rndKey[tab.wbwfleaRounds - 1 - r][0] >> (4 * j)) & 0xf,
	                    (wfleaCtx.rndKey[tab.wbwfleaRounds - 1 - r][1] >> (4 * j)) & 0xf,
	                    b, X, Y);
	                
	                tab.DTS[r][1][j][l]= wbwfleaTables.wbwfleaSubwb(
	                    (j == 0) ? 0 : (decCtx.t[r][1] >> (j - 1)) & 0x1,
	                    (decCtx.t[r][1] >> j) & 0x1,
	                    decCtx.g[r][1][j],
	                    decCtx.hInv[r][1][j],
	                    decCtx.h[r][2][j],
	                    (wfleaCtx.rndKey[tab.wbwfleaRounds - 1 - r][2] >> (4 * j)) & 0xf,
	                    (wfleaCtx.rndKey[tab.wbwfleaRounds - 1 - r][3] >> (4 * j)) & 0xf,
	                    b, X, Y);

	                tab.DTS[r][2][j][l] = wbwfleaTables.wbwfleaSubwb(
	                    (j == 0) ? 0 : (decCtx.t[r][2] >> (j - 1)) & 0x1,
	                    (decCtx.t[r][2] >> j) & 0x1,
	                    decCtx.g[r][2][j],
	                    decCtx.hInv[r][2][j],
	                    decCtx.h[r][3][j],
	                    (wfleaCtx.rndKey[tab.wbwfleaRounds - 1 - r][4] >> (4 * j)) & 0xf,
	                    (wfleaCtx.rndKey[tab.wbwfleaRounds - 1 - r][5] >> (4 * j)) & 0xf,
	                    b, X, Y);
	            }
	        }
	    }
		return tab;
	}

	public String wbwfleaGenDecryptionTableBase64(WbwfleaEncodingsForDecryption decCtx, WfleaCtx wfleaCtx) {
		WbwfleaTables wbwfleaTables = new WbwfleaTables();
		WbwfleaDecryptionTable tab = wbwfleaTables.wbwfleaGenDecryptionTable(decCtx, wfleaCtx);
		String decTabStr = wbwfleaTables.decryptionTabEncodeBase64(tab);
		return decTabStr;
	}

	private String decryptionTabEncodeBase64(WbwfleaDecryptionTable decTab) {
		Base64.Encoder base64Encoder = Base64.getEncoder();

		byte[] tmp = new byte[decTab.wbwfleaRounds * 3 * 8 * (256 + 512)];

		int i, j, k, l;

		for(i = 0; i < decTab.wbwfleaRounds; i++) {
			for(j = 0; j < 3; j++) {
				for(k = 0 ; k < 8; k++) {
					for(l = 0; l < 256; l++) {
						tmp[(i * 3 * 8 * 256) + (j * 8 * 256) + (k * 256) + l] = decTab.DTR[i][j][k][l];
					}
				}
			}
		}
		for(i = 0; i < decTab.wbwfleaRounds; i++) {
			for(j = 0; j < 3; j++) {
				for(k = 0 ; k < 8; k++) {
					for(l = 0; l < 512; l++) {
						tmp[(decTab.wbwfleaRounds * 3 * 8 * 256) + (i * 3 * 8 * 512) + (j * 8 * 512) + (k * 512) + l] = decTab.DTS[i][j][k][l];
					}
				}
			}
		}
		String encodingDat = base64Encoder.encodeToString(tmp);
		return encodingDat;
	}

	/**
	 * @param encCtx Table1 random encodings
	 * @param wfleaCtx WFLEA context (roundkeys)
	 * @return vpmac WK2 (Table1) Encryption table generation for Whitebox WFLEA
	 */
	public wbwfleaMacWK2 wbwfleaGenMacEncTablefirst(wbwfleaEncodingsForMacfirst encCtx, WfleaCtx wfleaCtx, WbwfleaConfig config) {
		WbwfleaTables wbwfleaTables = new WbwfleaTables();
		wbwfleaMacWK2 tab = new wbwfleaMacWK2(config);

		int r, i, j, l;
		for (r = 0; r < tab.Table1; r++)
	    {
	        for(j = 0; j < 8; j++)
	        {
	            /* ETA */
	            for(i = 0; i < 3; i++)
	            {
	                for (l = 0; l < 512; l++)
	                {
	                    byte c = (byte) ((l >> 8) & 0x1);
	                    byte X = (byte) ((l >> 4) & 0xf);
	                    byte Y = (byte) ((l) & 0xf);
	                    tab.ETA[r][i][j][l] = wbwfleaTables.wbwfleaAddwb(
	                        (j == 0) ? 0 : (encCtx.t[r][i] >> (j - 1)) & 0x1,
	                        (encCtx.t[r][i] >> j) & 0x1,
	                        encCtx.f[r][i][j],
	                        encCtx.f[r][i+1][j],
	                        encCtx.gInv[r][i][j],
	                        (wfleaCtx.rndKey[r][2 * i]     >> (4 * j)) & 0xf,
	                        (wfleaCtx.rndKey[r][2 * i + 1] >> (4 * j)) & 0xf,
	                        c, X, Y);
	                }
	            }
	            /* ETR */
	            for (l = 0; l < 256; l++)
	            {
	                byte X = (byte) ((l >> 4) & 0xf);
	                byte Y = (byte) ((l) & 0xf);
	
	                tab.ETR[r][0][j][l] = wbwfleaTables.wbwfleaRolwb(
	                    (byte) 1,
	                    encCtx.g[r][0][(j + 6) % 8],
	                    encCtx.g[r][0][(j + 5) % 8],
	                    encCtx.h[r][0][j],
	                    X, Y);
	
	                tab.ETR[r][1][j][l] = wbwfleaTables.wbwfleaRorwb(
	                    (byte) 1,
	                    encCtx.g[r][1][(j + 2) % 8],
	                    encCtx.g[r][1][(j + 1) % 8],
	                    encCtx.h[r][1][j],
	                    X, Y);
	
	                tab.ETR[r][2][j][l] = wbwfleaTables.wbwfleaRorwb(
	                    (byte) 3,
	                    encCtx.g[r][2][(j + 1) % 8],
	                    encCtx.g[r][2][j],
	                    encCtx.h[r][2][j],
	                    X, Y);
	
	            }
	        }
	    }
		return tab;
	}


	/**
	 * @param tab Table1이 저장된 wk2
	 * @param encCtx Table2 random encodings
	 * @param wfleaCtx WFLEA context (roundkeys)
	 * @return vpmac WK2 (Table1 + Table2) Encryption table generation for Whitebox WFLEA
	 */
	public wbwfleaMacWK2 wbwfleaGenMacEncTableend(wbwfleaMacWK2 tab, wbwfleaEncodingsForMacend encCtx, WfleaCtx wfleaCtx, WbwfleaConfig config) {
		WbwfleaTables wbwfleaTables = new WbwfleaTables();

		int r, i, j, l;
		for (r = 0; r < tab.Table2 ; r++)
	    {
	        for(j = 0; j < 8; j++)
	        {
	            /* ETA */
	            for(i = 0; i < 3; i++)
	            {
	                for (l = 0; l < 512; l++)
	                {
	                    byte c = (byte) ((l >> 8) & 0x1);
	                    byte X = (byte) ((l >> 4) & 0xf);
	                    byte Y = (byte) ((l) & 0xf);
	                    tab.ETA[r + config.getTable1()][i][j][l] = wbwfleaTables.wbwfleaAddwb(
	                        (j == 0) ? 0 : (encCtx.t[r][i] >> (j - 1)) & 0x1,
	                        (encCtx.t[r][i] >> j) & 0x1,
	                        encCtx.f[r][i][j],
	                        encCtx.f[r][i + 1][j],
	                        encCtx.gInv[r][i][j],
	                        (wfleaCtx.rndKey[r + config.getMIDTable() + config.getTable1()][2 * i]     >> (4 * j)) & 0xf,
	                        (wfleaCtx.rndKey[r + config.getMIDTable() + config.getTable1()][2 * i + 1] >> (4 * j)) & 0xf,
	                        c, X, Y);
	                }
				}

				/* ETR */
				for (l = 0; l < 256; l++)
	            {
	                byte X = (byte) ((l >> 4) & 0xf);
	                byte Y = (byte) ((l) & 0xf);
	
	                tab.ETR[r + config.getTable1()][0][j][l] = wbwfleaTables.wbwfleaRolwb(
	                    (byte) 1,
	                    encCtx.g[r][0][(j + 6) % 8],
	                    encCtx.g[r][0][(j + 5) % 8],
	                    encCtx.h[r][0][j],
	                    X, Y);
	
	                tab.ETR[r + config.getTable1()][1][j][l] = wbwfleaTables.wbwfleaRorwb(
	                    (byte) 1,
	                    encCtx.g[r][1][(j + 2) % 8],
	                    encCtx.g[r][1][(j + 1) % 8],
	                    encCtx.h[r][1][j],
	                    X, Y);
	
	                tab.ETR[r + config.getTable1()][2][j][l] = wbwfleaTables.wbwfleaRorwb(
	                    (byte) 3,
	                    encCtx.g[r][2][(j + 1) % 8],
	                    encCtx.g[r][2][j],
	                    encCtx.h[r][2][j],
	                    X, Y);
	            }
	        }
	    }
		return tab;
	}

	/**
	 * @param encCtx random encodings
	 * @param wfleaCtx WFLEA context (roundkeys)
	 * @return vpmac WK1 (MidTable) Encryption table generation for Whitebox WFLEA
	 */
public wbwfleaMacWK1 wbwfleaGenMacEncTablemid(wbwfleaEncodingsForMacmid encCtx, WfleaCtx wfleaCtx, WbwfleaConfig config) {
		wbwfleaMacWK1 tab = new wbwfleaMacWK1(config);
		WbwfleaTables wbwfleaTables = new WbwfleaTables();

		int r, i, j, l;
		for (r = 0; r < encCtx.rounds - encCtx.Table2 - encCtx.Table1; r++)
	    {
	        for(j = 0; j < 8; j++)
	        {
	            /* ETA */
	            for(i = 0; i < 3; i++)
	            {
	                for (l = 0; l < 512; l++)
	                {
	                    byte c = (byte) ((l >> 8) & 0x1);
	                    byte X = (byte) ((l >> 4) & 0xf);
	                    byte Y = (byte) ((l) & 0xf);
	                    tab.ETA[r][i][j][l] = wbwfleaTables.wbwfleaAddwb(
	                        (j == 0) ? 0 : (encCtx.t[r][i] >> (j - 1)) & 0x1,
	                        (encCtx.t[r][i] >> j) & 0x1,
	                        encCtx.f[r][i][j],
	                        encCtx.f[r][i+1][j],
	                        encCtx.gInv[r][i][j],
	                        (wfleaCtx.rndKey[r + encCtx.Table1][2 * i]     >> (4 * j)) & 0xf,
	                        (wfleaCtx.rndKey[r + encCtx.Table1][2 * i + 1] >> (4 * j)) & 0xf,
	                        c, X, Y);
	                }
	            }
	
	            /* ETR */
	            for (l = 0; l < 256; l++)
	            {
	                byte X = (byte) ((l >> 4) & 0xf);
	                byte Y = (byte) ((l) & 0xf);
	
	                tab.ETR[r][0][j][l] = wbwfleaTables.wbwfleaRolwb(
	                    (byte) 1,
	                    encCtx.g[r][0][(j + 6) % 8],
	                    encCtx.g[r][0][(j + 5) % 8],
	                    encCtx.h[r][0][j],
	                    X, Y);
	
	                tab.ETR[r][1][j][l] = wbwfleaTables.wbwfleaRorwb(
	                    (byte) 1,
	                    encCtx.g[r][1][(j + 2) % 8],
	                    encCtx.g[r][1][(j + 1) % 8],
	                    encCtx.h[r][1][j],
	                    X, Y);
	
	                tab.ETR[r][2][j][l] = wbwfleaTables.wbwfleaRorwb(
	                    (byte) 3,
	                    encCtx.g[r][2][(j + 1) % 8],
	                    encCtx.g[r][2][j],
	                    encCtx.h[r][2][j],
	                    X, Y);
	            }
	        }
	    }
		return tab;
	}
}

