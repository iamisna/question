/**
 * @file    mainTest.java
 * @brief   set of test functions
 * @author  FDL @ KMU
 * @date    2022.08.07.
 * UTF-8
 */
package kr.co.vp.common.crypto.wb.test;

import kr.co.vp.common.crypto.wb.Cbclea;
import kr.co.vp.common.crypto.wb.Ctrlea;
import kr.co.vp.common.crypto.wb.exception.WhiteBoxException;
import kr.co.vp.common.crypto.wb.random.Randperm;
import kr.co.vp.common.crypto.wb.wflea.*;
import kr.co.vp.common.crypto.wb.mac.*;

import java.util.Arrays;
import java.util.Objects;

public class MainTest {

	/**
	 * 기능	: wbwflea 암호화 / 복호화
	 * 주요함수
	 *  - wbwfleaGenEncryptionTableBase64(encCtx, wfleaCtx, config) : 암호화 키 테이블 생성
	 *  - wbwfleaGenDecryptionTableBase64(decCtx, wfleaCtx)   		: 복호화 키 테이블 생성
	 *  - wbwfleaEncryptwbBase64(encryptTab, wbeDat, config)        : 암호화
	 *  - wbwfleaDecryptwbBase64(decryptTab, wbdDat, config)        : 복호화
	 * @param config 알고리듬, round 수, key 길이, Table 크기를 설정한 config
	 * @return : 상황에 맞는 에러 코드 출력
	 **/
	public void testWbwfleaEncrypt(WbwfleaConfig config) {
		/* STEP 1 : 파라미터 생성 */
		Common common = new Common();

		/* 키 생성 (테스트를 위해 랜덤한 키 생성) */
		byte[] key = common.genRandBytes(config.getKEYBYTES());

		/* WFLEA Context 생성 (라운드 키 생성) */
		Wflea Wflea = new Wflea();
		WfleaCtx wfleaCtx = Wflea.wfleaGenCtx(key, config);

		/* plaintext 평문 생성 (테스트를 위해 랜덤한 평문 생성) */
  	    byte[] data = common.genRandBytes(16);

	    /* STEP 2: 암호화 키 테이블 생성을 위한 인코딩 정보 생성 */
	    /* external encoding generation (for encryption) */
		Randperm randperm = new Randperm();
		byte[] AeSeed = common.genRandBytes(32);
		byte[] BeSeed = common.genRandBytes(32);

		WbwfleaExtEncoding Ae = randperm.genRandperm128Bits(AeSeed);
		WbwfleaExtEncoding Be = randperm.genRandperm128Bits(BeSeed);

		/* STEP 3: 암호화 키 테이블 생성 */
	    /* random networked encodings generation (for encryption) */
		WbwfleaEncodings wbwfleaEncodings = new WbwfleaEncodings();
	    WbwfleaEncodingsForEncryption encCtx = wbwfleaEncodings.wbwfleaGenEncodingsForEncryption(Ae, Be, config);

	    /* encryption table generation with external encoding, random networked encodings, roundkey */
		WbwfleaTables wbwfleaTables = new WbwfleaTables();
		String encryptTab = wbwfleaTables.wbwfleaGenEncryptionTableBase64(encCtx, wfleaCtx, config); // 암호화 키 테이블 생성 base64

		/* STEP 4: 복호화 키 테이블 생성을 위한 인코딩 정보 생성 */
		/* external encoding generation (for decryption) */
		byte[] AdSeed = common.genRandBytes(32);
		byte[] BdSeed = common.genRandBytes(32);
		WbwfleaExtEncoding Ad = randperm.genRandperm128Bits(AdSeed);
		WbwfleaExtEncoding Bd = randperm.genRandperm128Bits(BdSeed);

		/* STEP 5: 복호화 키 테이블 생성 */
		/* random networked encodings generation (for decryption) */
		WbwfleaEncodingsForDecryption decCtx = wbwfleaEncodings.wbwfleaGenEncodingsForDecryption(Ad, Bd, config);

		/* decryption table generation with external encoding, random networked encodings, roundkey */
		String decryptTab = wbwfleaTables.wbwfleaGenDecryptionTableBase64(decCtx, wfleaCtx); // 복호화 키 생성 base64

		/* STEP 6: 암호화 */
		/* WhiteBox WFLEA Encryption */
		WbwfleaExtTransform wbwfleaExtTransform = new WbwfleaExtTransform();
		WbwfleaEncrypt wbwfleaEncrypt = new WbwfleaEncrypt();

		/* 이후 복호화한 값과 비교를 위해 외부 인코딩 Ae 적용 */
		byte[] wbeDat = wbwfleaExtTransform.wbwfleaExtTransforms(Ae, data, 0);		// WFLEA와의 비교를 위해 외부인코딩 적용.

		/* 암호화 */
		wbeDat = wbwfleaEncrypt.wbwfleaEncryptwbBase64(encryptTab, wbeDat, config);		// WBWFLEA 암호화 base64 암호화

		/* 이후 복호화한 값과 비교를 위해 외부 인코딩 Be 적용 */
		byte[] cipherData = wbwfleaExtTransform.wbwfleaExtTransforms(Be, wbeDat, 0);		// WFLEA와의 비교를 위해 외부인코딩 적용

		/* STEP 7: 복호화 */
		/* WhiteBox WFLEA Encryption */
		/* 복호화한 값과 비교를 위해 외부 인코딩 Ad 적용 */
		byte[] wbdDat = wbwfleaExtTransform.wbwfleaExtTransforms(Ad, cipherData, 0);		// WFLEA와 비교하기 위해 암호문에 외부인코딩 적용

		/* 복호화 */
		wbdDat = wbwfleaEncrypt.wbwfleaDecryptwbBase64(decryptTab, wbdDat, config);					// WBWFLEA 복호화 base64

		/* 복호화한 값과 비교를 위해 외부 인코딩 Bd 적용 */
		byte[] decryptedData = wbwfleaExtTransform.wbwfleaExtTransforms(Bd, wbdDat, 0);		// WFLEA와 비교하기 위해 복호화된 값에 외부인코딩 적용

		/* 확인용. 올바른 값으로 암/복호시 반드시 복호화한 값과 평문이 일치함. */
		if(!Arrays.equals(data, decryptedData)) {
			Common.log.info("평문과 복호화한 값이 일치하지 않음");
		}
		WhiteBoxException e = new WhiteBoxException("0000");
		Common.log.info(e.getErrorCode());
		Common.log.info(e.getMessage());
	}

	/* -- test functions -- */
	/**
	 * 기능 : wbcbc 암호화 / 복호화 테스트 함수
	 * 주요함수
	 *  - cbcKeyGenEncBase64(CBCAeSeed, BeSeed, key, config)			: 암호화 키 테이블 생성
	 *  - cbcKeyGenDecBase64(CBCBeSeed, BeSeed, key, config)			: 복호화 키 테이블 생성
	 *  - wbCbcLeaEncryptFromBase64(encryptTabStr, plainData, ivBase64, CBCAeSeedBase64, config)     : CBCLEA 암호화
	 *  - wbCbcLeaDecryptFromBase64(decryptTabStr, cipherData, ivBase64, CBCBeSeedBase64, config)    : CBCLEA 복호화
	 * @param msgbytelen 	: 랜덤 메시지 바이트 길이
	 * @param config 알고리듬, round 수, key 길이, Table 크기를 설정한 config
	 * @return 상황에 맞는 에러 코드 출력
	 * @throws WhiteBoxException
	 */
	public void testCbcwbwfleaEncrypt(int msgbytelen, WbwfleaConfig config) throws WhiteBoxException {
		/* STEP 1 : 파라미터 생성 */
		Common common = new Common();

		/* 키 생성 (테스트를 위해 랜덤한 키 생성) */
		byte[] key = common.genRandBytes(config.getKEYBYTES());
		/* 초기화 벡터 생성 */
		byte[] iv = common.genRandBytes(16);
		/* 평문 생성 (테스트를 위해 랜덤한 키 생성) */
		byte[] data = common.genRandBytes(msgbytelen);
		/* 생성한 초기화 벡터를 base64로 인코딩하여 String 형태로 저장 */
		String ivBase64 = common.seedEncodeBase64(iv);								// iv base64 Encoding

		/* STEP 2 : 암/복호화 키 테이블 생성을 위한 인코딩 정보 생성 */
		/* external encoding generation (for encryption) */
		byte[] BeSeed = common.genRandBytes(32);

		/*Xor encoding (for encryption) */
		byte[] CBCAeSeed = common.genRandBytes(32);
		String CBCAeSeedBase64 = common.seedEncodeBase64(CBCAeSeed);		// CBCAe 외부인코딩을 생성하는 시드값 base64 적용하여 저장

		/*Xor encoding (for decryption) */
		byte[] CBCBeSeed = common.genRandBytes(32);
		String CBCBeSeedBase64 = common.seedEncodeBase64(CBCBeSeed);		// CBCBe 외부인코딩을 생성하는 시드값 base64 적용하여 저장

		/* STEP 3: 암호화 키 테이블 생성 */
		/* encryption table generation with external encoding, random networked encodings, roundkey */
		/* Xor table (for encryption) */
		Cbclea cbclea = new Cbclea();
		String encStr = cbclea.cbcKeyGenEncBase64(CBCAeSeed, BeSeed, key, config);		// 암호화 테이블 base64 적용하여 저장

		/* STEP 4: 복호화 키 테이블 생성 */
		/* decryption table generation with external encoding, random networked encodings, roundkey */
		/* Xor table (for decryption) */
		String decStr = cbclea.cbcKeyGenDecBase64(CBCBeSeed, BeSeed, key, config);		// 복호화 테이블 base64 적용하여 저장

		/* STEP 5: WBLEA CBC 암호화 (화이트박스 연산) */
		/* WBLEA CBC encryption */
		byte[] cipherData = cbclea.wbCbcLeaEncryptFromBase64(encStr, data, ivBase64, CBCAeSeedBase64, config);

		/* STEP 6: WBLEA CBC 복호화 (화이트박스 연산) */
		/* WBLEA CBC decryption */
		byte[] decryptedData = cbclea.wbCbcLeaDecryptFromBase64(decStr, cipherData, ivBase64, CBCBeSeedBase64, config);

		/* 확인용. 올바른 값으로 암/복호시 반드시 복호화한 값과 평문이 일치함. */
		if(!Arrays.equals(data, decryptedData)){
			Common.log.info("복호화한 값이 평문과 일치하지 않음");
		}
		WhiteBoxException e = new WhiteBoxException("0000");
		Common.log.info(e.getErrorCode());
		Common.log.info(e.getMessage());
	}

	/**
	 * 기능 : wbctr 암호화 / 복호화 테스트 함수
	 * 주요함수
	 * - ctrKeyGenEncBase64(AeSeed, CTRHSeed, CTRGSeed, key, config)	: 암호화 키 테이블 생성
	 * - ctrKeyGenDecBase64(AeSeed, CTRHSeed, CTRHdSeed, key, config)   : 복호화 키 테이블 생성
	 * - wbCtrLeaEncryptFromBase64(encryptTabStr, plainData, ivStr, CTRGSeedBase64, config)	 : CTRLEA 암호화
	 * - wbCtrLeaDecryptFromBase64(decryptTabStr, cipherData, ivStr, CTRHdSeedBase64,config) : CTRLEA 복호화
	 * @param msgbytelen 랜덤 메시지 바이트 길이
	 * @param config   알고리듬, round 수, key 길이, Table 크기를 설정한 config
	 * @return 상황에 맞는 에러 코드 출력
	 * @throws WhiteBoxException
	 */
	public void testCtrwbwfleaEncrypt(int msgbytelen, WbwfleaConfig config) throws WhiteBoxException {
		/* STEP 1 : 파라미터 생성 */
		Common common = new Common();

		/* 키 생성 (테스트를 위해 랜덤한 키 생성) */
		byte[] key = common.genRandBytes(config.getKEYBYTES());
		/* 초기화 벡터 생성 */
		byte[] iv = common.genRandBytes(16);
		/* 평문 생성 (테스트를 위해 랜덤한 키 생성) */
		byte[] data = common.genRandBytes(msgbytelen);
		/* 생성한 초기화 벡터를 base64로 인코딩하여 String 형태로 저장 */
		String ivStr = common.seedEncodeBase64(iv);

		/* STEP 2 : 암/복호화 키 테이블 생성을 위한 인코딩 정보 생성 */
		/* CTR-table-permutation */
		byte[] CTRGSeed = common.genRandBytes(32);			//XOR g
		String CTRGSeedBase64 = common.seedEncodeBase64(CTRGSeed);

		byte[] CTRHSeed = common.genRandBytes(32);

		/* CTR-table-permutation */
		byte[] CTRHdSeed = common.genRandBytes(32);
		String CTRHdSeedBase64 = common.seedEncodeBase64(CTRHdSeed);

		/* CTR-table-gen */
		byte[] AeSeed = common.genRandBytes(32);

		/* STEP 3: 암호화 키 테이블 생성 */
		/* encryption table generation with external encoding, random networked encodings, roundkey */
		/* Xor table (for encryption) */
		Ctrlea ctrlea = new Ctrlea();
		String encStr = ctrlea.ctrKeyGenEncBase64(AeSeed, CTRHSeed, CTRGSeed, key, config);   //key gen base64

		/* STEP 4: 복호화 키 테이블 생성 */
		/* decryption table generation with external encoding, random networked encodings, roundkey */
		/* Xor table (for decryption) */
		String decStr = ctrlea.ctrKeyGenDecBase64(AeSeed, CTRHSeed, CTRHdSeed, key, config);   //key gen base64

		/* STEP 5: WBLEA CTR 암호화 (화이트박스 연산) */
		/* WB CTR LEA Encryption */
		byte[] cipherData = ctrlea.wbCtrLeaEncryptFromBase64(encStr, data, ivStr, CTRGSeedBase64, config);

		/* STEP 6: WBLEA CTR 복호화 (화이트박스 연산) */
		/* WB CTR LEA decryption*/
		byte[] decryptedData = ctrlea.wbCtrLeaDecryptFromBase64(decStr, cipherData, ivStr, CTRHdSeedBase64,config);

		/* 확인용. 올바른 값으로 암/복호시 반드시 복호화한 값과 평문이 일치함. */
		if(!Arrays.equals(data, decryptedData)){
			Common.log.info("복호화한 값이 평문과 일치하지 않음");
		}
		WhiteBoxException e = new WhiteBoxException("0000");
		Common.log.info(e.getErrorCode());
		Common.log.info(e.getMessage());
	}

	/**
	 * 기능 : VPMAC Tag 생성과 VPMAC Tag 검증 결과 비교
	 * 주요함수
	 *  - vpMacGen(wk1, wk2, wbeDat)						: VPMAC sig Gen
	 *  - vpMacVerify(key, wbeDat, ivSig, BeSeed, tag)		: VPMAC sig verify
	 * @param msgbytelen : 랜덤 메시지 바이트 길이
	 * @param config    알고리듬, round 수, key 길이, Table 크기를 설정한 config
	 * @return 상황에 맞는 에러 코드 출력
	 * @throws WhiteBoxException
	 */
	public void testVPMac(int msgbytelen, WbwfleaConfig config) throws WhiteBoxException {
		/* STEP 1 : 파라미터 생성 */
		Common common = new Common();

		/* 키 생성 (테스트를 위해 랜덤한 값으로 생성) */
		byte[] key = common.genRandBytes(config.getKEYBYTES());
		/* 초기화 벡터 생성 */
		byte[] iv = common.genRandBytes(16);
		/* 메시지 생성 (테스트를 위해 랜덤한 값으로 생성) */
		byte[] msg = common.genRandBytes(msgbytelen);

		/* STEP 2 : 암호화 키 테이블(WK1, WK2) 생성을 위한 인코딩 정보 생성 */
	    /* test: whitebox encryption */
	    /* external encoding generation (for encryption) */
		Randperm randperm = new Randperm();
		byte[] BeSeed = common.genRandBytes(32);
		WbwfleaExtEncoding Be = randperm.genRandperm128Bits(BeSeed);
		String BeSeedBase64 = common.seedEncodeBase64(BeSeed);

		byte[] AinSeed = common.genRandBytes(32);
		byte[] BinSeed = common.genRandBytes(32);

		/* STEP 3: 암호화 키 테이블 WK1 생성 */
		Vpmac vpmac = new Vpmac();
		String strWK1 = vpmac.vpmacWk1KeyGenBase64(AinSeed, BinSeed, key, config);		// wk1 생성 base64

		/* STEP 4: 암호화 키 테이블 WK2 생성 */
		String strWK2 = vpmac.vpmacWk2KeyGenBase64(AinSeed, BinSeed, iv, BeSeed, key, config);		// wk2 생성 base64

		/* STEP 5: VP MAC Tag 생성 (화이트박스 연산) */
		WbwfleaExtTransform wbwfleaExtTransform = new WbwfleaExtTransform();

		byte[] tag = vpmac.vpMacGenTagFromBase64(strWK1, strWK2, msg, config);

		/* STEP 6: VP MAC Tag 검증 (비 화이트박스 연산) */
		iv = wbwfleaExtTransform.wbwfleaExtTransforms(Be, iv, 0);		//서명시 B(IV) 입력.
		String ivSigBase64 = common.seedEncodeBase64(iv);

		/* 확인용. 올바른 값으로 서명 생성시, 반드시 유효한 서명으로 검증됨. */
		if(Objects.equals(vpmac.vpMacTagVerifyBase64(key, msg, ivSigBase64, BeSeedBase64, tag, config), "INVALID"))
		{
			Common.log.info("검증 결과 : INVALID");
		}
		WhiteBoxException e = new WhiteBoxException("0000");
		Common.log.info(e.getErrorCode());
		Common.log.info(e.getMessage());
	}

	/**
	 * 기능 : VPMAC 동작시 WK1는 고정하고, WK2를 바꾸며 진행 시 올바르게 검증 성공하는가
	 * @param msgbytelen : 랜덤 메시지 바이트 길이
	 * @param config 알고리듬, round 수, key 길이, Table 크기를 설정한 config
	 * @return 상황에 맞는 에러 코드 출력
	 * @throws WhiteBoxException
	 */
	public void testVpmacWk1Wk2(int msgbytelen, WbwfleaConfig config) throws WhiteBoxException {
		/* STEP 1 : 파라미터 생성 */
		Common common = new Common();
		/* 키 생성 (테스트를 위해 랜덤한 키 생성) */
		byte[] key = common.genRandBytes(config.getKEYBYTES());

		/* STEP 2: 고정된 WK1 생성을 위해 인코딩 정보 생성 */
		/* external encoding generation (for encryption) */
		Randperm randperm = new Randperm();
		byte[] AinSeed = common.genRandBytes(32);
		byte[] BinSeed = common.genRandBytes(32);

		/* STEP 3: 고정된 WK1 생성 */
		Vpmac vpmac = new Vpmac();
		String wk1Str = vpmac.vpmacWk1KeyGenBase64(AinSeed, BinSeed, key, config);		// wk1 생성 base64

		/* second ephemeral */
		WbwfleaExtTransform wbwfleaExtTransform = new WbwfleaExtTransform();
		/* test: whitebox encryption */
		/* STEP 4: 매 세션마다 생성되는 WK2 생성을 위해 인코딩 정보 생성 */ // WK1은 고정되고 WK2가 변할때 검증이 잘 이루어지는가
		for(int i = 0; i < 10; i++){
			/* 파라미터 생성 */
			/* 초기화 벡터 iv 생성 */
			byte[] iv = common.genRandBytes(16);
			/* 메시지 생성 (테스트를 위해 랜덤한 메시지 생성) */
			byte[] data = common.genRandBytes(msgbytelen);

			/* WK2 생성을 위한 외부 인코딩 정보 - 32 바이트 시드 BeSeed 생성 및 외부 인코딩 Be, 시드 BeSeed를 base64로 인코딩한 BeSeedBase64 생성 */
			byte[] BeSeed = common.genRandBytes(32);
			WbwfleaExtEncoding Be = randperm.genRandperm128Bits(BeSeed);
			String BeSeedBase64 = common.seedEncodeBase64(BeSeed);

			/* STEP 5: 매 세션마다 생성되는 WK2 생성 */
			String wk2Str = vpmac.vpmacWk2KeyGenBase64(AinSeed, BinSeed, iv, BeSeed, key, config);		// wk1 생성 base64

			/* STEP 6: VP MAC Tag 생성 */
			byte[] tag = vpmac.vpMacGenTagFromBase64(wk1Str, wk2Str, data, config);						// 서명 생성

			/* STEP 7: VP MAC Tag 검증 */
			iv = wbwfleaExtTransform.wbwfleaExtTransforms(Be, iv, 0);		// B(IV)를 입력하여 서명 검증
			String ivSigBase64 = common.seedEncodeBase64(iv);

			/* 확인용. 올바른 값으로 서명 생성시, 반드시 유효한 서명으로 검증됨. */
			if(Objects.equals(vpmac.vpMacTagVerifyBase64(key, data, ivSigBase64, BeSeedBase64, tag, config), "INVALID"))
			{
				Common.log.info("검증 결과 : INVALID");
			}
		}
		WhiteBoxException e = new WhiteBoxException("0000");
		Common.log.info(e.getErrorCode());
		Common.log.info(e.getMessage());
	}

	/**
	 * 메인 함수
	 * @param args
	 * @exception WhiteBoxException
	 */
	public static void main(String[] args) throws WhiteBoxException {
		/**
	 	 * WbwfleaConfig(String flag, int alg, int macBlock, int table1, int table2)
		 * String flag : "wflea" or "lea"
		 * int alg : 128 or 192 or 256
		 * int macBlock : 4 이상 권고
		 * int table1, table2 : 2 이상 권고
	 	 */
		WbwfleaConfig config = new WbwfleaConfig("lea",128,5,2,2);
		config.config();

		/* 임의의 메시지 길이 설정 */
		int msgbytelen = 81;
		MainTest mainTest = new MainTest();

		/* WBWFLEA */
//		mainTest.testWbwfleaEncrypt(config);
		/* WBWFLEA CBC */
//		mainTest.testCbcwbwfleaEncrypt(msgbytelen, config);
		/* WBWFLEA CTR*/
//		mainTest.testCtrwbwfleaEncrypt(msgbytelen, config);

		/**
		 * WbwfleaConfig(String flag, int alg, int macBlock, int table1, int table2)
		 * String flag : "wflea" or "lea"
		 * int alg : 128 or 192 or 256
		 * int macBlock : 4 이상 권고
		 * int table1, table2 : 2 이상 권고
		 */
		WbwfleaConfig configVpmac = new WbwfleaConfig("wflea",128,5,2,2);
		configVpmac.config();

		/* VP MAC */
		mainTest.testVPMac(msgbytelen, configVpmac);
		/* wk1, wk2 test */
//		mainTest.testVpmacWk1Wk2(msgbytelen, configVpmac);


		/* speed benchmark */
//		Benchmark benchmark = new Benchmark();
//		benchmark.TimeWBWFLEA(config);
//		benchmark.TimeCBC(config);
//		benchmark.TimeCTR(config);
//		benchmark.TimeVPMAC(configVpmac);
	}
}

