/**
 * @file    wbwfleaEncodingsForMacend.java
 * @brief   wbwfleaEncodingsForMacend
 * @author  FDL @ KMU
 * @version 2022.08.07.
 */
package kr.co.vp.common.crypto.wb.mac;

import kr.co.vp.common.crypto.wb.wflea.WbwfleaConfig;

public class wbwfleaEncodingsForMacend {
    public wbwfleaEncodingsForMacend(WbwfleaConfig config) {
        this.Table2 = config.getTable2();

        this.f = new byte[Table2][4][8][16];
        this.fInv = new byte[Table2][4][8][16];
        this.g = new byte[Table2][3][8][16];
        this.gInv = new byte[Table2][3][8][16];
        this.h = new byte[Table2][3][8][16];
        this.hInv = new byte[Table2][3][8][16];
        this.t = new byte[Table2][3];
    }
    int Table2;

    public byte[][][][] f, fInv, g, gInv, h, hInv;;
    public byte[][] t;
}
