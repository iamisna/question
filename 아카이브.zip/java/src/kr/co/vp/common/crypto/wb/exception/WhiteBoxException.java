package kr.co.vp.common.crypto.wb.exception;

import java.util.Objects;
import java.util.logging.Logger;

/**
 * class Biz 익셉션 처리용
 * @author IM Dongju
 * @since 2019.11.15
 */
public class WhiteBoxException extends Exception {
	private static final Logger log = Logger.getLogger(WhiteBoxException.class.getName());

	private static final long serialVersionUID = -624827297922973011L;

	private String message;

	private String errorCode;

	private final static String DEFAULT_MESSAGE = "이 요청을 처리하는 동안 오류가 발생하였습니다.<br/>같은 문제가 계속해서 발생할 경우 1577-XXXX번으로 문의 바랍니다.";


	/**
	 * 입력된 에러코드로 공통코드의 메시지를 찾아서 셋팅
	 *
	 * @param msgCode 에러코드
	 */
	public WhiteBoxException(String msgCode) {
		super();
		String msg;
		ErrorCodeVO error = ErrorCodeVO.find(msgCode);
		msg = error.message;

		if (error.code.equals("9999")) {
//			log.error("메시지코드 [" + msgCode + "] 가 CM_MSG_CD에 정의되어 있지 않습니다.");
			log.info("메시지코드 [" + msgCode + "] 가 CM_MSG_CD에 정의되어 있지 않습니다.");
			msg = DEFAULT_MESSAGE;
		}
		this.message = msg;
		//this.errorCode = msgCode;
		this.errorCode = error.code;
	}

	/**
	 * 입력된 에러코드와 에러 메시지로 셋팅
	 *
	 * @param errorCode 에러코드
	 * @param message   에러 메시지
	 */
	public WhiteBoxException(String errorCode, String message, String type) {
		super(message);
		this.errorCode = errorCode;
		this.message = message;
	}

	public WhiteBoxException() {
	}

	@Override
	public String getMessage() {
		return message;
	}

	public String getErrorCode() {
		return errorCode;
	}

}
