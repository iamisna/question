/**
 * @file    XorTable.java
 * @brief   XorTable
 * @author  FDL @ KMU
 * @version 2022.08.07.
 */
package kr.co.vp.common.crypto.wb;

public class XorTable {
    public byte[][][] XOR = new byte[4][8][256];
}
