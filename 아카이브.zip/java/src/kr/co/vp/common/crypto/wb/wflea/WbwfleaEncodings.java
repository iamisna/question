/**
 * @file    WbwfleaEncodings.java
 * @brief   Whitebox WF-LEA java code: Random encoding generation
 * @author  FDL @ KMU
 * @version 2022.06.06.
 */

package kr.co.vp.common.crypto.wb.wflea;

import kr.co.vp.common.crypto.wb.random.Randperm;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;

public class WbwfleaEncodings {
	/**
	 * @param A 외부 인코딩 1
	 * @param B 외부 인코딩 2
	 * @return generate random encodings for encryption
	 */
	public WbwfleaEncodingsForEncryption wbwfleaGenEncodingsForEncryption(WbwfleaExtEncoding A, WbwfleaExtEncoding B, WbwfleaConfig config) {
		WbwfleaEncodingsForEncryption ctx = new WbwfleaEncodingsForEncryption(config);
		Randperm randperm = new Randperm();
		byte[][] tmp;

		/* f */
		/* case: r = 0 */
		ctx.f[0] = A.fInv;
		ctx.fInv[0] = A.f;

		/* case: r = 1, ..., Nr - 2 */
		for (int r = 1; r < config.getROUNDS() - 1; r++)
		{
			for (int j = 0; j < 8; j++)
			{
				tmp = randperm.genRandperm4bits();
				ctx.f[r][0][j] = tmp[0];
				ctx.fInv[r][0][j] = tmp[1];

				tmp = randperm.genRandperm4bits();
				ctx.f[r][1][j] = tmp[0];
				ctx.fInv[r][1][j] = tmp[1];

				tmp = randperm.genRandperm4bits();
				ctx.f[r][2][j] = tmp[0];
				ctx.fInv[r][2][j] = tmp[1];
			}
			ctx.f[r][3] = ctx.f[r-1][0];
			ctx.fInv[r][3] = ctx.fInv[r-1][0];
		}

		/* case: r = Nr - 1 */
		ctx.f[config.getROUNDS() - 1][0] = B.f[3];
		ctx.fInv[config.getROUNDS() - 1][0] = B.fInv[3];

		for (int j = 0; j < 8; j++)
		{
			tmp = randperm.genRandperm4bits();
			ctx.f[config.getROUNDS() - 1][1][j] = tmp[0];
			ctx.fInv[config.getROUNDS() - 1][1][j] = tmp[1];

			tmp = randperm.genRandperm4bits();
			ctx.f[config.getROUNDS() - 1][2][j] = tmp[0];
			ctx.fInv[config.getROUNDS() - 1][2][j] = tmp[1];
		}
		ctx.f[config.getROUNDS() - 1][3] = ctx.f[config.getROUNDS() - 2][0];
		ctx.fInv[config.getROUNDS() - 1][3] = ctx.fInv[config.getROUNDS() - 2][0];

		/* g */
		for (int r = 0; r < config.getROUNDS(); r++)
		{
			for (int j = 0; j < 8; j++)
			{
				tmp = randperm.genRandperm4bits();
				ctx.g[r][0][j] = tmp[0];
				ctx.gInv[r][0][j] = tmp[1];

				tmp = randperm.genRandperm4bits();
				ctx.g[r][1][j] = tmp[0];
				ctx.gInv[r][1][j] = tmp[1];

				tmp = randperm.genRandperm4bits();
				ctx.g[r][2][j] = tmp[0];
				ctx.gInv[r][2][j] = tmp[1];
			}
		}

		/* h */
		/* case: r = 0, ..., Nr - 2 */
		for (int r = 0; r < config.getROUNDS() - 1; r++)
		{
			ctx.h[r][0] = ctx.fInv[r+1][0];
			ctx.hInv[r][0] = ctx.f[r+1][0];
			ctx.h[r][1] = ctx.fInv[r+1][1];
			ctx.hInv[r][1] = ctx.f[r+1][1];
			ctx.h[r][2] = ctx.fInv[r+1][2];
			ctx.hInv[r][2] = ctx.f[r+1][2];
		}
		/* case: r = Nr - 1 */
		ctx.h[config.getROUNDS() - 1] = B.fInv;
		ctx.hInv[config.getROUNDS() - 1] = B.f;

		/* t */
		for (int r = 0; r < config.getROUNDS(); r++)
		{
			ctx.t[r][0] = randperm.genRandperm1bits();
			ctx.t[r][1] = randperm.genRandperm1bits();
			ctx.t[r][2] = randperm.genRandperm1bits();
		}
		return ctx;
	}

	/**
	 * @param A 외부 인코딩 1
	 * @param B 외부 인코딩 2
	 * @return generate random encodings for decryption
	 */
	public WbwfleaEncodingsForDecryption wbwfleaGenEncodingsForDecryption(WbwfleaExtEncoding A, WbwfleaExtEncoding B, WbwfleaConfig config) {
		WbwfleaEncodingsForDecryption ctx = new WbwfleaEncodingsForDecryption(config);
		Randperm randperm = new Randperm();
		byte[][] tmp;

		/* h */
		/* case: r = 0 */
		ctx.h[0][0] = A.fInv[3];
		ctx.hInv[0][0] = A.f[3];

		for (int j = 0; j < 8; j++)
		{
			tmp = randperm.genRandperm4bits();
			ctx.h[0][1][j] = tmp[0];
			ctx.hInv[0][1][j] = tmp[1];

			tmp = randperm.genRandperm4bits();
			ctx.h[0][2][j] = tmp[0];
			ctx.hInv[0][2][j] = tmp[1];

			tmp = randperm.genRandperm4bits();
			ctx.h[0][3][j] = tmp[0];
			ctx.hInv[0][3][j] = tmp[1];
		}

		/* case: r = 1, ..., Nr - 2 */
		for (int r = 1; r < config.getROUNDS() - 1; r++)
		{
			ctx.h[r][0] = ctx.hInv[r - 1][3];
			ctx.hInv[r][0] = ctx.h[r - 1][3];

			for (int j = 0; j < 8; j++)
			{
				tmp = randperm.genRandperm4bits();
				ctx.h[r][1][j] = tmp[0];
				ctx.hInv[r][1][j] = tmp[1];

				tmp = randperm.genRandperm4bits();
				ctx.h[r][2][j] = tmp[0];
				ctx.hInv[r][2][j] = tmp[1];

				if(r != config.getROUNDS() - 2)
				{
					tmp = randperm.genRandperm4bits();
					ctx.h[r][3][j] = tmp[0];
					ctx.hInv[r][3][j] = tmp[1];
				}
				else
				{
					ctx.h[r][3] = B.fInv[0];
					ctx.hInv[r][3] = B.f[0];
				}
			}
		}

		/* case: r = Nr - 1 */
		ctx.h[config.getROUNDS() - 1][0] = B.f[0];
		ctx.hInv[config.getROUNDS() - 1][0] = B.fInv[0];
		ctx.h[config.getROUNDS() - 1][1] = B.fInv[1];
		ctx.hInv[config.getROUNDS() - 1][1] = B.f[1];
		ctx.h[config.getROUNDS() - 1][2] = B.fInv[2];
		ctx.hInv[config.getROUNDS() - 1][2] = B.f[2];
		ctx.h[config.getROUNDS() - 1][3] = B.fInv[3];
		ctx.hInv[config.getROUNDS() - 1][3] = B.f[3];

		/* f */
		/* case: r = 0 */
		ctx.f[0] = A.fInv;
		ctx.fInv[0] = A.f;

		/* case: r = 1, ..., Nr - 1 */
		for (int r = 1; r < config.getROUNDS(); r++)
		{
			ctx.f[r][0] = ctx.h[r - 1][0];
			ctx.fInv[r][0] = ctx.hInv[r - 1][0];

			ctx.f[r][1] = ctx.hInv[r - 1][1];
			ctx.fInv[r][1] = ctx.h[r - 1][1];

			ctx.f[r][2] = ctx.hInv[r - 1][2];
		}

		/* g */
		for (int r = 0; r < config.getROUNDS(); r++)
		{
			for (int j = 0; j < 8; j++)
			{
				tmp = randperm.genRandperm4bits();
				ctx.g[r][0][j] = tmp[0];
				ctx.gInv[r][0][j] = tmp[1];

				tmp = randperm.genRandperm4bits();
				ctx.g[r][1][j] = tmp[0];
				ctx.gInv[r][1][j] = tmp[1];

				tmp = randperm.genRandperm4bits();
				ctx.g[r][2][j] = tmp[0];
				ctx.gInv[r][2][j] = tmp[1];
			}
		}

		/* t */
		for (int r = 0; r < config.getROUNDS(); r++)
		{
			ctx.t[r][0] = randperm.genRandperm1bits();
			ctx.t[r][1] = randperm.genRandperm1bits();
			ctx.t[r][2] = randperm.genRandperm1bits();
		}
		return ctx;
	}
}

