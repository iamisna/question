/**
 * @file    WbwfleaEncodingsForDecryption.java
 * @brief   WbwfleaEncodingsForDecryption
 * @author  FDL @ KMU
 * @version 2022.06.06.
 */
package kr.co.vp.common.crypto.wb.wflea;

public class WbwfleaEncodingsForDecryption {
    WbwfleaEncodingsForDecryption(WbwfleaConfig config) {
        this.WbwfleaRounds = config.getROUNDS();
        this.f = new byte[WbwfleaRounds][3][8][16];
        this.fInv = new byte[WbwfleaRounds][3][8][16];
        this.g = new byte[WbwfleaRounds][3][8][16];
        this.gInv = new byte[WbwfleaRounds][3][8][16];
        this.h = new byte[WbwfleaRounds][4][8][16];
        this.hInv = new byte[WbwfleaRounds][4][8][16];
        this.t = new byte[WbwfleaRounds][3];
    }
    public int getWbwfleaRounds() {
        return WbwfleaRounds;
    }

    int WbwfleaRounds;
    byte[][][][] f, fInv, g, gInv, h, hInv;
    byte[][] t;
}
