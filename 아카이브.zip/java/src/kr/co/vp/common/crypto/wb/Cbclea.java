/**
 * @file    Cbclea.java
 * @brief   Cbclea java code
 * @author  FDL @ KMU
 * @version 2022.08.07.
 */
package kr.co.vp.common.crypto.wb;

import kr.co.vp.common.crypto.wb.exception.WhiteBoxException;
import kr.co.vp.common.crypto.wb.random.Randperm;
import kr.co.vp.common.crypto.wb.wflea.*;
import java.util.Base64;
import java.util.Objects;

public class Cbclea {
	private Padding encode(byte[] wbeDat, WbwfleaExtEncoding exTab) throws WhiteBoxException {
		WbwfleaExtTransform wbwfleaExtTransform = new WbwfleaExtTransform();

		Padding padding = cbcPad(wbeDat);

		int dataLen = wbeDat.length + padding.getPadNum();
		byte[] dst = new byte[dataLen];
		System.arraycopy(padding.getPaddedMsg(), 0, dst, 0, dataLen);

		int blkLen = dataLen / 16;
		byte[] tmp = new byte[16];

		// i < blkLen
		for (int i = 0; i < blkLen; i++ ){
			System.arraycopy(dst, i * 16, tmp, 0, 16);

			tmp = wbwfleaExtTransform.wbwfleaExtTransforms(exTab, tmp, 0);

			System.arraycopy(tmp, 0, dst, i * 16, 16);
		}
		padding.setPaddedMsg(dst);

		return padding;
	}
	public Padding encodeBase64(byte[] wbeDat, String seedBase64) throws WhiteBoxException {
		if((wbeDat == null)) {
			WhiteBoxException e = new WhiteBoxException("2003");
			Common.log.info(e.getErrorCode());
			Common.log.info(e.getMessage());
			throw e;
		} else if (seedBase64.length() != 44) {
			WhiteBoxException e = new WhiteBoxException("2004");
			Common.log.info(e.getErrorCode());
			Common.log.info(e.getMessage());
			throw e;
		}
		try {
			Cbclea cbclea = new Cbclea();
			WbwfleaExtEncoding exTab = cbclea.seedDecodeBase64ExtEncoding(seedBase64);
			Padding padding = cbclea.encode(wbeDat, exTab);
			return padding;
		}
		catch (Exception e){
			WhiteBoxException wbE = new WhiteBoxException("2981");
			Common.log.info(wbE.getErrorCode());
			Common.log.info(wbE.getMessage());
			throw wbE;
		}
	}

	/**
	 * @param CBCAeSeed byte array
	 * @param BeSeed byte array
	 * @param key 키
	 * @return WB Encryption + XOR Table을 base64 인코딩 적용한 String
	 */
	public String cbcKeyGenEncBase64(byte[] CBCAeSeed, byte[] BeSeed, byte[] key, WbwfleaConfig config) throws WhiteBoxException {
		if((CBCAeSeed.length != 32) || (BeSeed.length != 32)) {
			WhiteBoxException e = new WhiteBoxException("2001");
			Common.log.info(e.getErrorCode());
			Common.log.info(e.getMessage());
			throw e;
		} else if (key.length != config.getKEYBYTES()) {
			WhiteBoxException e = new WhiteBoxException("2002");
			Common.log.info(e.getErrorCode());
			Common.log.info(e.getMessage());
			throw e;
		}
		try {
			WbwfleaEncryptTableWithXor cbcEncTab = cbcKeyGenEnc(CBCAeSeed, BeSeed, key, config);
			String encryptTab = wbwfleaEncKeyEncodeBase64(cbcEncTab);
			return encryptTab;
		} catch (Exception e) {
			WhiteBoxException wbE = new WhiteBoxException("2980");
			Common.log.info(wbE.getErrorCode());
			Common.log.info(wbE.getMessage());
			throw wbE;
		}
	}

	private WbwfleaEncryptTableWithXor cbcKeyGenEnc(byte[] CBCAeSeed, byte[] BeSeed, byte[] key, WbwfleaConfig config) {
		WbwfleaEncryptTableWithXor cbcEncTab = new WbwfleaEncryptTableWithXor(config);

		/* setup: WFLEA context (roundkey generation) */
		Wflea wflea = new Wflea();
		WfleaCtx wfleaCtx = wflea.wfleaGenCtx(key, config);
		try {
			if(!Objects.equals(wfleaCtx.getErrorCode(), "0000")) {
				throw new WhiteBoxException(wfleaCtx.getErrorCode());
			}
		}
		catch (WhiteBoxException e){
			Common.log.info(wfleaCtx.getErrorCode());
			Common.log.info(wfleaCtx.getErrorMessage());
			e.printStackTrace();
		}

		/* external encoding generation (for encryption) */
		Randperm randperm = new Randperm();
		WbwfleaExtTransform wbwfleaExtTransform = new WbwfleaExtTransform();
		WbwfleaExtEncoding Ae = wbwfleaExtTransform.wbwfleaGenExtEncoding();
		WbwfleaExtEncoding Be = randperm.genRandperm128Bits(BeSeed);

		/* random networked encodings generation (for encryption) */
		WbwfleaEncodings wbwfleaEncodings = new WbwfleaEncodings();
		WbwfleaEncodingsForEncryption encCtx = wbwfleaEncodings.wbwfleaGenEncodingsForEncryption(Ae, Be, config);

		/* encryption table generation with external encoding, random networked encodings, roundkey */
		WbwfleaTables wbwfleaTables = new WbwfleaTables();
		WbwfleaEncryptionTable encTab = wbwfleaTables.wbwfleaGenEncryptionTable(encCtx, wfleaCtx, config);
		cbcEncTab.setEncTab(encTab);

		/*Xor encoding (for encryption) */
		WbwfleaExtEncoding cbcAe = randperm.genRandperm128Bits(CBCAeSeed);

		/*Xor table (for encryption) */
		XorTable cbcExTab = xorEncodingTable(cbcAe, Be, Ae);
		cbcEncTab.setExTable(cbcExTab);

		return cbcEncTab;
	}

	private WbwfleaDecryptTableWithXor cbcKeyGenDec(byte[] CBCBeSeed, byte[] BeSeed, byte[] key, WbwfleaConfig config)  {
		WbwfleaDecryptTableWithXor cbcDecTab = new WbwfleaDecryptTableWithXor(config);

		/* setup: WFLEA context (roundkey generation) */
		Wflea wflea = new Wflea();
		WfleaCtx wfleaCtx = wflea.wfleaGenCtx(key, config);

		/* external encoding generation (for encryption) */
		Randperm randperm = new Randperm();
		WbwfleaExtEncoding Be = randperm.genRandperm128Bits(BeSeed);

		/* external encoding generation (for decryption) */
		WbwfleaExtTransform wbwfleaExtTransform = new WbwfleaExtTransform();
		WbwfleaExtEncoding Bep = new WbwfleaExtEncoding();	//Bep is inverse of Be
		WbwfleaExtEncoding Bd = wbwfleaExtTransform.wbwfleaGenExtEncoding();

		Bep.f = Be.fInv;
		Bep.fInv = Be.f;

		/* random networked encodings generation (for decryption) */
		WbwfleaEncodings wbwfleaEncodings = new WbwfleaEncodings();
		WbwfleaEncodingsForDecryption decCtx = wbwfleaEncodings.wbwfleaGenEncodingsForDecryption(Bep, Bd, config);

		/* decryption table generation with external encoding, random networked encodings, roundkey */
		WbwfleaTables wbwfleaTables = new WbwfleaTables();
		WbwfleaDecryptionTable decTab = wbwfleaTables.wbwfleaGenDecryptionTable(decCtx, wfleaCtx);
		cbcDecTab.setDecTab(decTab);

		/*Xor encoding (for decryption) */
		WbwfleaExtEncoding cbcBe = randperm.genRandperm128Bits(CBCBeSeed);

		/*Xor table (for decryption) */
		XorTable cbcDeExTab = xorDecodingTable(Bd, Be, cbcBe);
		cbcDecTab.setCbcDeExTable(cbcDeExTab);

		return cbcDecTab;
	}

	/**
	 * @param CBCBeSeed byte array
	 * @param BeSeed byte array
	 * @param key
	 * @return WB Encryption + XOR Table을 base64 인코딩 적용한 String
	 */
	public String cbcKeyGenDecBase64(byte[] CBCBeSeed, byte[] BeSeed, byte[] key, WbwfleaConfig config) throws WhiteBoxException {
		Cbclea cbclea = new Cbclea();
		WbwfleaDecryptTableWithXor cbcDecTab;
		String decryptTab;

		if((CBCBeSeed.length != 32) || (BeSeed.length != 32)) {
			WhiteBoxException e = new WhiteBoxException("2008");
			Common.log.info(e.getErrorCode());
			Common.log.info(e.getMessage());
			throw e;
		} else if (key.length != config.getKEYBYTES()) {
			WhiteBoxException e = new WhiteBoxException("2009");
			Common.log.info(e.getErrorCode());
			Common.log.info(e.getMessage());
			throw e;
		}
		try {
			cbcDecTab = cbclea.cbcKeyGenDec(CBCBeSeed, BeSeed, key, config);
			decryptTab = wbwfleaDecKeyEncodeBase64(cbcDecTab);
			return decryptTab;
		} catch (Exception e) {
			WhiteBoxException wbE = new WhiteBoxException("2983");
			Common.log.info(wbE.getErrorCode());
			Common.log.info(wbE.getMessage());
			throw wbE;
		}
	}

	/**
	 * @param src 입력 데이터
	 * @return 패딩된 데이터 + 패딩된 길이
	 */
	public Padding cbcPad(byte[] src) throws WhiteBoxException {
		if(src == null) {
			WhiteBoxException e = new WhiteBoxException("2003");
			Common.log.info(e.getErrorCode());
			Common.log.info(e.getMessage());
			throw e;
		}
		try {
			int padLen = src.length;
			int padnum = 16 - (padLen % 16);

			padLen = padLen + padnum;

			byte[] dst = new byte[padLen];

			System.arraycopy(src, 0, dst, 0, src.length);

			for(int i = 0; i < padnum;i++){
				dst[src.length + i] = (byte) (padnum & 0xff);
			}

			Padding padding = new Padding(dst, padnum);
			return padding;
		}
		catch (Exception e) {
			WhiteBoxException wbe = new WhiteBoxException("2981");
			Common.log.info(wbe.getErrorCode());
			Common.log.info(wbe.getMessage());
			throw wbe;
		}
	}

	/**
	 * @param src 입력 데이터
	 * @return 패딩을 제거한 데이터 + 제거한 패딩 값
	 */
	public Padding removePad(byte[] src) throws WhiteBoxException {
		if(src.length % 16 != 0) {
			WhiteBoxException e = new WhiteBoxException("2010");
			Common.log.info(e.getErrorCode());
			Common.log.info(e.getMessage());
			throw e;
		}
		try{
			int msgLen = src[src.length - 1];
			int len = src.length - msgLen;
			byte[] dst = new byte[len + 1];

			System.arraycopy(src, 0, dst, 0, len);
			Padding padding = new Padding(dst, msgLen);

			return padding;
		} catch (Exception e) {
			WhiteBoxException wbe = new WhiteBoxException("2984");
			Common.log.info(wbe.getErrorCode());
			Common.log.info(wbe.getMessage());
			throw wbe;
		}
	}

	/**
	 * CBC LEA 암호화 함수
	 * @param src 입력 데이터
	 * @param IV iv
	 * @param key 키
	 * @return 암호화한 데이터
	 */
	public byte[] cbcLea(final byte[] src, byte[] IV, byte[] key, WbwfleaConfig config) throws WhiteBoxException {
		if(src.length % 16 != 0) {
			WhiteBoxException e = new WhiteBoxException("2006");
			Common.log.info(e.getErrorCode());
			Common.log.info(e.getMessage());
			throw e;
		} else if (IV.length != 16) {
			WhiteBoxException e = new WhiteBoxException("2007");
			Common.log.info(e.getErrorCode());
			Common.log.info(e.getMessage());
			throw e;
		} else if (key.length != config.getKEYBYTES()) {
			WhiteBoxException e = new WhiteBoxException("2002");
			Common.log.info(e.getErrorCode());
			Common.log.info(e.getMessage());
			throw e;
		}
		Wflea wflea = new Wflea();
		WfleaCtx ctx = wflea.wfleaGenCtx(key, config);
		if(!Objects.equals(ctx.getErrorCode(), "0000")) {
			WhiteBoxException e = new WhiteBoxException(ctx.getErrorCode());
			Common.log.info(e.getErrorCode());
			Common.log.info(e.getMessage());
			throw e;
		}
		try {
			int blklen = src.length / 16;
			byte[] enc = new byte[16];
			byte[] dec;
			byte[] dst = new byte[src.length];
			byte[] inIv = new byte[16];
			System.arraycopy(IV, 0, inIv, 0, 16);

			for(int i = 0; i < blklen; i++)     // N-1 blk
			{
				for(int j = 0; j < 16; j++)
				{
					enc[j] = (byte) (src[16 * i + j] ^ inIv[j]);
				}
				dec = wflea.wfleaEncryptblk4Bits(enc, ctx);
				for(int j = 0; j < 16; j++)
				{
					dst[16 * i + j] = dec[j];
					inIv[j]= dec[j];
				}
			}
			return dst;
		}
		catch (Exception e) {
			WhiteBoxException wbe = new WhiteBoxException("2982");
			Common.log.info(wbe.getErrorCode());
			Common.log.info(wbe.getMessage());
			throw wbe;
		}
	}

	/**
	 * @param src 입력 데이터
	 * @param iv
	 * @param key
	 * @return 복호화된 데이터
	 */
	public byte[] inCbcLea(final byte[] src, byte[] iv, byte[] key, WbwfleaConfig config) throws WhiteBoxException {
		if(src.length % 16 != 0) {
			WhiteBoxException e = new WhiteBoxException("2013");
			Common.log.info(e.getErrorCode());
			Common.log.info(e.getMessage());
			throw e;
		} else if (iv.length != 16) {
			WhiteBoxException e = new WhiteBoxException("2014");
			Common.log.info(e.getErrorCode());
			Common.log.info(e.getMessage());
			throw e;
		} else if (key.length != config.getKEYBYTES()) {
			WhiteBoxException e = new WhiteBoxException("2009");
			Common.log.info(e.getErrorCode());
			Common.log.info(e.getMessage());
			throw e;
		}
		try{
			byte[] dst = new byte[src.length];
			Wflea Wflea = new Wflea();
			WfleaCtx ctx = Wflea.wfleaGenCtx(key, config);
			if(!Objects.equals(ctx.getErrorCode(), "0000")) {
				WhiteBoxException e = new WhiteBoxException(ctx.getErrorCode());
				Common.log.info(e.getErrorCode());
				Common.log.info(e.getMessage());
				throw e;
			}
			int blkLen = src.length / 16;

			byte[] dec = new byte[16];
			byte[] rec;
			byte[] ivIn = new byte[16];

			System.arraycopy(iv, 0, ivIn, 0, 16);

			for(int i = 0; i < blkLen; i++)    /* i = 0,...,blklen-1 */
			{
				System.arraycopy(src, 16 * i, dec, 0, 16);

				rec = Wflea.wfleaDecryptblk4Bits(dec, ctx);

				for(int j = 0; j < 16; j++)
				{
					dst[16 * i + j] = (byte) (rec[j] ^ ivIn[j]);
					ivIn[j]= src[16 * i + j];                  //IV update
				}
			}
			return dst;
		} catch (Exception e) {
			WhiteBoxException wbe = new WhiteBoxException("2985");
			Common.log.info(wbe.getErrorCode());
			Common.log.info(wbe.getMessage());
			throw wbe;
		}
	}

	/**
	 * @param f 외부인코딩1
	 * @param g 외부인코딩2
	 * @param h 외부인코딩3
	 * @return 암호화 XOR 테이블
	 */
	public XorTable xorEncodingTable(WbwfleaExtEncoding f, WbwfleaExtEncoding g, WbwfleaExtEncoding h)
	{
		XorTable tab = new XorTable();
		int i, j, l;

		for(i = 0; i < 4; i++)
		{
			for(j = 0; j < 8; j++)
			{
				for (l = 0; l < 256; l++)
				{
					byte X = (byte) ((l >> 4) & 0xf);
					byte Y = (byte) ((l) & 0xf);
					byte Z = (byte) ((f.fInv[i][j][X])^(g.f[i][j][Y]));

					tab.XOR[i][j][l] = h.f[i][j][Z];
				}
			}
		}
		return tab;
	}

	/**
	 * @param f 외부인코딩1
	 * @param g 외부인코딩2
	 * @param h 외부인코딩3
	 * @return 복호화 XOR 테이블
	 */
	public XorTable xorDecodingTable(WbwfleaExtEncoding f, WbwfleaExtEncoding g, WbwfleaExtEncoding h)
	{
		XorTable tab = new XorTable();

		int i, j, l;
		for(i = 0; i < 4; i++)
		{
			for(j = 0; j < 8; j++)
			{
				for (l = 0; l < 256; l++)
				{
					byte X = (byte) ((l >> 4) & 0xf);
					byte Y = (byte) ((l) & 0xf);
					byte Z = (byte) ((f.f[i][j][X])^(g.f[i][j][Y]));
					tab.XOR[i][j][l] = h.fInv[i][j][Z];
				}
			}
		}
		return tab;
	}

	/**
	 * @param f 외부인코딩1
	 * @param g 외부인코딩2
	 * @param h 외부인코딩3
	 * @return 암호화 XOR 3차원 배열
	 */
	public byte[][][] cbcGenEncodingTable(WbwfleaExtEncoding f, WbwfleaExtEncoding g, WbwfleaExtEncoding h)
	{
		byte[][][] xor = new byte[4][8][256];
	    int i, j, l;
	    for(i = 0; i < 4; i++)
	    {
	        for(j = 0; j < 8; j++)
	        {
	            for (l = 0; l < 256; l++)
	            {
	                byte X = (byte) ((l >> 4) & 0xf);
	                byte Y = (byte) ((l) & 0xf);
	                byte Z = (byte) ((f.fInv[i][j][X]) ^ (g.f[i][j][Y]));

					xor[i][j][l] = h.f[i][j][Z];
	            }
	        }
	    }
		return xor;
	}

	public byte[] wbcbcLea(WbwfleaEncryptTableWithXor cbcEncTab, byte[] data, byte[] iv)
	{
		WbwfleaEncrypt wbwfleaEncrypt = new WbwfleaEncrypt();

		byte[] inIv = new byte[16];
		System.arraycopy(iv, 0, inIv, 0, 16);

		byte[] dst = new byte[data.length];
	    int blkLen = data.length / 16;           // block length

	    byte[] enc = new byte[16];

	    for(int i = 0; i < blkLen; i++)     // N-1 blk
	    {
	        for(int j = 0; j < 16; j++)
	        {
	            byte tmp = cbcEncTab.ExTable.XOR[j / 4][(2 * j + 1) % 8][((((data[16 * i + j] >>> 4) & 0xf) << 4 ) ^ ((inIv[j] >>> 4) & 0xf))];
	            enc[j] = (byte) ((tmp & 0xf) << 4);
	            enc[j] ^= cbcEncTab.ExTable.XOR[j / 4][(2 * j) % 8][(((data[16 * i + j] & 0xf) << 4 ) ^ (inIv[j] & 0xf))];
	        }
	        enc = wbwfleaEncrypt.wbwfleaEncryptwb(cbcEncTab.encTab, enc);
	        for(int j = 0; j < 16; j++)
	        {
	        	dst[16 * i + j] = enc[j];
	            inIv[j]= enc[j];
	        }
	    }
	    return dst;
	}

	/**
	 * @param cbcEnc base64 인코딩된 암호화 테이블
	 * @param data 입력 데이터
	 * @param ivStr base64 인코딩된 iv
	 * @return WB CBC LEA 암호화 데이터
	 */
	public byte[] wbcbcLeaEncryptBase64(String cbcEnc, byte[] data, String ivStr, WbwfleaConfig config) throws WhiteBoxException {
		if((cbcEnc.isEmpty())) {
			WhiteBoxException e = new WhiteBoxException("2005");
			Common.log.info(e.getErrorCode());
			Common.log.info(e.getMessage());
			throw e;
		} else if (data.length % 16 != 0) {
			WhiteBoxException e = new WhiteBoxException("2006");
			Common.log.info(e.getErrorCode());
			Common.log.info(e.getMessage());
			throw e;
		} else if (ivStr.length() != 24) {
			WhiteBoxException e = new WhiteBoxException("2007");
			Common.log.info(e.getErrorCode());
			Common.log.info(e.getMessage());
			throw e;
		}
		try{
			Cbclea cbclea = new Cbclea();
			Common common = new Common();
			WbwfleaEncryptTableWithXor cbcEncTab = wbwfleaEncKeyDecodeBase64(cbcEnc, config);
			byte[] iv = common.seedDecodeBase64(ivStr);
			return cbclea.wbcbcLea(cbcEncTab, data, iv);
		} catch (Exception e) {
			WhiteBoxException wbE = new WhiteBoxException("2982");
			Common.log.info(wbE.getErrorCode());
			Common.log.info(wbE.getMessage());
			throw wbE;
		}
	}

	private byte[] invWbcbcLea(WbwfleaDecryptTableWithXor cbcDecTab, byte[] src, byte[] iv)
	{
		WbwfleaEncrypt wbwfleaEncrypt = new WbwfleaEncrypt();
		byte[] dst = new byte[src.length];
		int blkLen = src.length / 16;                 // block length

		byte[] data = new byte[16];
		byte[] inIv = new byte[16];
		byte[] nextIv = new byte[16];

		System.arraycopy(iv, 0, inIv, 0, 16);

		for(int i = 0; i < blkLen; i++)     // N-1 blk
		{
			for(int j = 0; j < 16; j++)
			{
				data[j] = src[16 * i + j];
				nextIv[j] = src[16 * i + j];
			}
			data = wbwfleaEncrypt.wbwfleaDecryptwb(cbcDecTab.decTab, data);
			for(int j = 0; j < 16; j++)
			{
				byte tmp = cbcDecTab.cbcDeExTable.XOR[j / 4][(2 * j + 1) % 8][((((data[j] >> 4) & 0xf) << 4) ^ ((inIv[j] >> 4) & 0xf))];
				dst[16 * i + j] = (byte) ((tmp & 0xf) << 4);
				dst[16 * i + j] ^= cbcDecTab.cbcDeExTable.XOR[j/4][(2*j)%8 ][(( (data[j]&0xf)<<4 )^ (inIv[j]&0xf)) ];
			}
			System.arraycopy(nextIv, 0, inIv, 0, 16);
		}
		return dst;
	}

	/**
	 * @param tab base64 인코딩된 복호화 테이블
	 * @param src 입력 데이터
	 * @param ivStr base64 인코딩된 iv
	 * @return WB CBC LEA 복호화 데이터
	 */
	public byte[] wbwfcbcLeaDecryptBase64(String tab, byte[] src, String ivStr, WbwfleaConfig config) throws WhiteBoxException {
		if((tab.isEmpty())) {
			WhiteBoxException e = new WhiteBoxException("2012");
			Common.log.info(e.getErrorCode());
			Common.log.info(e.getMessage());
			throw e;
		} else if (src.length % 16 != 0) {
			WhiteBoxException e = new WhiteBoxException("2013");
			Common.log.info(e.getErrorCode());
			Common.log.info(e.getMessage());
			throw e;
		} else if (ivStr.length() != 24) {
			WhiteBoxException e = new WhiteBoxException("2014");
			Common.log.info(e.getErrorCode());
			Common.log.info(e.getMessage());
			throw e;
		}
		try{
			Cbclea cbclea = new Cbclea();
			Common common = new Common();
			WbwfleaDecryptTableWithXor cbcDecTab = wbwfleaDecKeyDecodeBase64(tab, config);		// alswl
			byte[] iv = common.seedDecodeBase64(ivStr);
			byte[] dst = cbclea.invWbcbcLea(cbcDecTab, src, iv);
			return dst;
		} catch (Exception e){
			WhiteBoxException wbE = new WhiteBoxException("2985");
			Common.log.info(wbE.getErrorCode());
			Common.log.info(wbE.getMessage());
			throw wbE;
		}
	}

	/**
	 * @param strTab base64 인코딩 적용한 String
	 * @return WB Decryption + XOR Table
	 */
	public  WbwfleaDecryptTableWithXor wbwfleaDecKeyDecodeBase64(String strTab, WbwfleaConfig config) {
		Base64.Decoder base64Decoder = Base64.getDecoder();
		byte[] tmp;

		tmp = base64Decoder.decode(strTab);

		WbwfleaDecryptTableWithXor ctx = new WbwfleaDecryptTableWithXor(config);

		int i, j, k, l;

		for(i = 0; i < ctx.decTab.wbwfleaRounds; i++) {
			for(j = 0; j < 3; j++) {
				for(k = 0 ; k < 8; k++) {
					for(l = 0; l < 256; l++) {
						ctx.decTab.DTR[i][j][k][l] = tmp[(i * 3 * 8 * 256) + (j * 8 * 256) + (k * 256) + l];
					}
				}
			}
		}
		for(i = 0; i < ctx.decTab.wbwfleaRounds; i++) {
			for(j = 0; j < 3; j++) {
				for(k = 0 ; k < 8; k++) {
					for(l = 0; l < 512; l++) {
						ctx.decTab.DTS[i][j][k][l] = tmp[(ctx.decTab.wbwfleaRounds * 3 * 8 * 256) + (i * 3 * 8 * 512) + (j * 8 * 512) + (k * 512) + l];
					}
				}
			}
		}
		for(i = 0; i < 4; i++){
			for(j = 0; j < 8; j++){
				for(k = 0; k < 256; k++){
					ctx.cbcDeExTable.XOR[i][j][k] = tmp[(ctx.decTab.wbwfleaRounds * 3 * 8 * (512 + 256)) + (i * 8 * 256) + (j * 256) + k];
				}
			}
		}

		return ctx;
	}
	public Padding decode(byte[] encodedMsg, WbwfleaExtEncoding cbcBe) throws WhiteBoxException {
		WbwfleaExtTransform wbwfleaExtTransform = new WbwfleaExtTransform();
		Cbclea cbclea = new Cbclea();
		byte[] tmp = new byte[16];

		for (int i = 0; i < encodedMsg.length / 16; i++ ){
			System.arraycopy(encodedMsg, 16 * i, tmp, 0, 16);
			tmp = wbwfleaExtTransform.wbwfleaExtTransforms(cbcBe, tmp, 0);		//Decoding
			System.arraycopy(tmp, 0, encodedMsg, 16 * i, 16);
		}
		Padding pad = cbclea.removePad(encodedMsg);
		return pad;
	}
	/**
	 * @param encodedMsg 입력 데이터
	 * @param Seed base64 인코딩된 seed값
	 * @return 외부 인코딩을 적용한 뒤 패딩 제거가 된 데이터
	 */
	public Padding decodeBase64(byte[] encodedMsg, String Seed) throws WhiteBoxException {
		if (encodedMsg.length % 16 != 0) {
			WhiteBoxException e = new WhiteBoxException("2010");
			Common.log.info(e.getErrorCode());
			Common.log.info(e.getMessage());
			throw e;
		} else if (Seed.length() != 44) {
			WhiteBoxException e = new WhiteBoxException("2011");
			Common.log.info(e.getErrorCode());
			Common.log.info(e.getMessage());
			throw e;
		}
		try{
			Cbclea cbclea = new Cbclea();
			WbwfleaExtEncoding cbcBe = cbclea.seedDecodeBase64ExtEncoding(Seed);
			Padding padding = cbclea.decode(encodedMsg, cbcBe);
			return padding;
		} catch (Exception e){
			WhiteBoxException wbE = new WhiteBoxException("2984");
			Common.log.info(wbE.getErrorCode());
			Common.log.info(wbE.getMessage());
			throw wbE;
		}
	}
	/**
	 * @param ctx WB Encryption + XOR Table
	 * @return 해당 구조체를 base64 인코딩 적용한 String
	 */
	public String wbwfleaEncKeyEncodeBase64(WbwfleaEncryptTableWithXor ctx) {
		Base64.Encoder base64Encoder = Base64.getEncoder();
		WbwfleaEncryptionTable tab = ctx.encTab;
		XorTable xorTab = ctx.ExTable;

		byte[] tmp = new byte[tab.getRounds() * 3 * 8 * (512 + 256) + (4 * 8 * 256)];
		int i, j, k, l;
		for(i = 0; i < tab.getRounds(); i++) {
			for(j = 0; j < 3; j++) {
				for(k = 0 ; k < 8; k++) {
					for(l = 0; l < 512; l++) {
						tmp[(i * 3 * 8 * 512) + (j * 8 * 512) + (k * 512) + l] = tab.ETA[i][j][k][l];
					}
				}
			}
		}
		for(i = 0; i < tab.getRounds(); i++) {
			for(j = 0; j < 3; j++) {
				for(k = 0 ; k < 8; k++) {
					for(l = 0; l < 256; l++) {
						tmp[(tab.getRounds() * 3 * 8 * 512) + (i * 3 * 8 * 256) + (j * 8 * 256) + (k * 256) + l] = tab.ETR[i][j][k][l];
					}
				}
			}
		}
		for(i = 0; i < 4; i++){
			for(j = 0; j < 8; j++){
				for(k = 0; k < 256; k++){
					tmp[(tab.getRounds() * 3 * 8 * (512 + 256)) + (i * 8 * 256) + (j * 256) + k] = xorTab.XOR[i][j][k];
				}
			}
		}
		String encodingDat = base64Encoder.encodeToString(tmp);
		return encodingDat;
	}

	/**
	 * @param ctx WB Decryption + XOR Table
	 * @return 해당 구조체를 base64 인코딩 적용한 String
	 */
	private String wbwfleaDecKeyEncodeBase64(WbwfleaDecryptTableWithXor ctx) {
		Base64.Encoder base64Encoder = Base64.getEncoder();
		WbwfleaDecryptionTable tab = ctx.decTab;
		XorTable xorTab = ctx.cbcDeExTable;

		byte[] tmp = new byte[tab.wbwfleaRounds * 3 * 8 * (256 + 512) + (4 * 8 * 256)];

		int i, j, k, l;

		for(i = 0; i < tab.wbwfleaRounds; i++) {
			for(j = 0; j < 3; j++) {
				for(k = 0 ; k < 8; k++) {
					for(l = 0; l < 256; l++) {
						tmp[(i * 3 * 8 * 256) + (j * 8 * 256) + (k * 256) + l] = tab.DTR[i][j][k][l];
					}
				}
			}
		}
		for(i = 0; i < tab.wbwfleaRounds; i++) {
			for(j = 0; j < 3; j++) {
				for(k = 0 ; k < 8; k++) {
					for(l = 0; l < 512; l++) {
						tmp[(tab.wbwfleaRounds * 3 * 8 * 256) + (i * 3 * 8 * 512) + (j * 8 * 512) + (k * 512) + l] = tab.DTS[i][j][k][l];
					}
				}
			}
		}
		for(i = 0; i < 4; i++){
			for(j = 0; j < 8; j++){
				for(k = 0; k < 256; k++){
					tmp[(tab.wbwfleaRounds * 3 * 8 * (512 + 256)) + (i * 8 * 256) + (j * 256) + k] = xorTab.XOR[i][j][k];
				}
			}
		}
		String encodingDat = base64Encoder.encodeToString(tmp);
		return encodingDat;
	}

	/**
	 * @param strTab base64 인코딩 적용한 String
	 * @return WB Encryption + XOR Table
	 */
	public WbwfleaEncryptTableWithXor wbwfleaEncKeyDecodeBase64(String strTab, WbwfleaConfig config) {
		Base64.Decoder base64Decoder = Base64.getDecoder();
		byte[] tmp = base64Decoder.decode(strTab);

		WbwfleaEncryptTableWithXor ctx = new WbwfleaEncryptTableWithXor(config);

		int i, j, k, l;
		for(i = 0; i < ctx.encTab.getRounds(); i++) {
			for(j = 0; j < 3; j++) {
				for(k = 0 ; k < 8; k++) {
					for(l = 0; l < 512; l++) {
						ctx.encTab.ETA[i][j][k][l] = tmp[(i * 3 * 8 * 512) + (j * 8 * 512) + (k * 512) + l];
					}
				}
			}
		}
		for(i = 0; i < ctx.encTab.getRounds(); i++) {
			for(j = 0; j < 3; j++) {
				for(k = 0 ; k < 8; k++) {
					for(l = 0; l < 256; l++) {
						ctx.encTab.ETR[i][j][k][l] = tmp[(ctx.encTab.getRounds() * 3 * 8 * 512) + (i * 3 * 8 * 256) + (j * 8 * 256) + (k * 256) + l];
					}
				}
			}
		}
		for(i = 0; i < 4; i++){
			for(j = 0; j < 8; j++){
				for(k = 0; k < 256; k++){
					ctx.ExTable.XOR[i][j][k] = tmp[(ctx.encTab.getRounds() * 3 * 8 * (512 + 256)) + (i * 8 * 256) + (j * 256) + k];
				}
			}
		}
		return ctx;
	}



	/**
	 * strSeed를 base64로 디코딩한 시드값으로 외부인코딩 생성
	 * @param strSeed base64 인코딩된 String
	 * @return 외부 인코딩
	 */
	private WbwfleaExtEncoding seedDecodeBase64ExtEncoding(String strSeed) {
		Randperm randperm = new Randperm();
		Base64.Decoder base64Decoder = Base64.getDecoder();
		byte[] seed = base64Decoder.decode(strSeed);
		WbwfleaExtEncoding ctx = randperm.genRandperm128Bits(seed);
		return ctx;
	}

	/**
	 * Base64 적용된 암호화 키 테이블, 초기화 벡터, 인코딩 시드. 입력 데이터, config로 WB CBC LEA 암호화
	 * @param encStr base64 적용된 암호화 테이블 (String)
	 * @param data 입력 데이터 (평문)
	 * @param ivBase64 base64 적용된 초기화 벡터 IV (String)
	 * @param CBCAeSeedBase64 base64 적용된 인코딩 정보 - 시드 CBCAe (String)
	 * @param config 알고리듬, 키 길이, 라운드 수, 블록 길이, 테이블 크기를 정해둔 config
	 * @return 화이트박스 연산 WB CBC LEA 암호화된 값
	 * @throws WhiteBoxException
	 */
	public byte[] wbCbcLeaEncryptFromBase64(String encStr, byte[] data, String ivBase64, String CBCAeSeedBase64, WbwfleaConfig config) throws WhiteBoxException {
		Cbclea cbclea = new Cbclea();
		Padding padding = cbclea.encodeBase64(data, CBCAeSeedBase64);		// WB CBC 패딩. 얼마나 패딩했는지 배열 마지막에 붙여서 리턴.

		int wbDataLen = data.length + padding.getPadNum();	// 패딩된 메시지 길이 = 메시지 길이 + 얼마나 패딩했는지 (배열 마지막 값)
		byte[] encodedMsg = new byte[wbDataLen];
		System.arraycopy(padding.getPaddedMsg(), 0, encodedMsg, 0, wbDataLen);	// 패딩된 메시지만 복사하여 사용

		/*WB CBC lea*/
		byte[] dst = cbclea.wbcbcLeaEncryptBase64(encStr, encodedMsg, ivBase64, config);
		return dst;
	}

	public byte[] wbCbcLeaDecryptFromBase64(String decStr, byte[] src, String ivBase64, String CBCBeSeedBase64, WbwfleaConfig config) throws WhiteBoxException {
		Cbclea cbclea = new Cbclea();

		byte[] encodedMsg = cbclea.wbwfcbcLeaDecryptBase64(decStr, src, ivBase64, config);		// WB CBC 복호화

		Padding padding = cbclea.decodeBase64(encodedMsg, CBCBeSeedBase64);		//PADDING 제거. 얼마나 패딩을 제거했는지 배열 마지막에 함께 리턴.

		/* 패딩 제거된 메시지 길이 = 메시지 길이 - 얼마나 패딩을 제거했는지 (배열 마지막 값) */
		int wbDataLen = encodedMsg.length - padding.getPadNum();
		byte[] dst = new byte[wbDataLen];
		System.arraycopy(padding.getPaddedMsg(), 0, dst, 0, wbDataLen);	// 패딩 제거된 메시지만 복사하여 사용

		return dst;
	}
}

