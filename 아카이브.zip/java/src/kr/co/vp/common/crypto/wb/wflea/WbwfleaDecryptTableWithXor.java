/**
 * @file    WbwfleaDecryptTableWithXor.java
 * @brief   WbwfleaDecryptTableWithXor
 * @author  FDL @ KMU
 * @date    2022.08.07.
 */
package kr.co.vp.common.crypto.wb.wflea;

import kr.co.vp.common.crypto.wb.XorTable;

public class WbwfleaDecryptTableWithXor {
    public WbwfleaDecryptTableWithXor(WbwfleaConfig config){
        this.decTab = new WbwfleaDecryptionTable(config);
    }
    public WbwfleaDecryptionTable decTab;
    public XorTable cbcDeExTable = new XorTable();

    public void setDecTab(WbwfleaDecryptionTable decTab) {
        this.decTab = decTab;
    }

    public void setCbcDeExTable(XorTable cbcDeExTable) {
        this.cbcDeExTable = cbcDeExTable;
    }
}
