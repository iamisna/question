/**
 * @file    WbwfleaEncryptionTable.java
 * @brief   WbwfleaEncryptionTable
 * @author  FDL @ KMU
 * @version 2022.08.06.
 */
package kr.co.vp.common.crypto.wb.wflea;

public class WbwfleaEncryptionTable {
    public WbwfleaEncryptionTable(WbwfleaConfig config){
        this.rounds = config.getROUNDS();
        this.ETA = new byte[rounds][3][8][512];
        this.ETR = new byte[rounds][3][8][256];
    }
    public int getRounds() {
        return rounds;
    }

    public int rounds;
    public byte[][][][] ETA;
    public byte[][][][] ETR;
}
