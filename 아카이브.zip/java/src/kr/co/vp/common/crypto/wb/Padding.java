package kr.co.vp.common.crypto.wb;

public class Padding {
    public Padding(byte[] msg, int len){
        this.paddedMsg = msg;
        this.padNum = len;
    }
    public byte[] getPaddedMsg() {
        return paddedMsg;
    }

    public int getPadNum() {
        return padNum;
    }

    public void setPaddedMsg(byte[] paddedMsg) {
        this.paddedMsg = paddedMsg;
    }

    private byte[] paddedMsg;
    private int padNum;
}
