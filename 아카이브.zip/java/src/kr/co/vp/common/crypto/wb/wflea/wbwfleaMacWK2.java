/**
 * @file    wbwfleaMacWK2.java
 * @brief   wbwfleaMacWK2
 * @author  FDL @ KMU
 * @version 2022.08.06.
 */
package kr.co.vp.common.crypto.wb.wflea;

public class wbwfleaMacWK2 {
    public wbwfleaMacWK2(WbwfleaConfig config) {
        this.Table1 = config.getTable1();
        this.Table2 = config.getTable2();
        this.ETA = new byte[Table1 + Table2][3][8][512];
        this.ETR = new byte[Table1 + Table2][3][8][256];
        this.XOR = new byte[4][8][256];            //XOR
        this.IV = new byte[16];                    //IV > WK2
    }

    public int Table1;
    public int Table2;
    public byte[][][][] ETA;
    public byte[][][][] ETR;
    public byte[][][] XOR;            //XOR
    public byte[] IV;                    //IV > WK2
}
