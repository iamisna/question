/**
 * @file    Common.java
 * @brief   etc. functions
 * @author  FDL @ KMU
 * @date    2022.08.07.
 */
package kr.co.vp.common.crypto.wb.wflea;

import kr.co.vp.common.crypto.wb.XorTable;
import kr.co.vp.common.crypto.wb.random.Randperm;
import java.util.Base64;
import java.util.logging.Logger;

public class Common {
    /**
     * log 찍을 시 사용
     */
    public static final Logger log = Logger.getLogger(Common.class.getName());
    
    /**
     * @param size : 랜덤하게 생성할 바이트 열 길이
     * @return 랜덤하게 생성된 바이트 열
     */
    public byte[] genRandBytes(int size)
    {
        byte[] dst = new byte[size];
        for (int j = 0; j < size; j++)
            dst[j] = (byte) ((byte) (Math.random() * 1000) & 0xff);
        return dst;
    }

    /**
     * @param bs : 바이트 열
     * @return Word를 Int로 변환한 Int 배열
     */
    public int[] wordToInt(byte[] bs) {     // byte array to int array
        int[] ns = new int[bs.length / 4];
        int off = 0;

        for (int i = 0; i < ns.length; ++i) {
            int cnt = off;
            int n = bs[cnt] & 0xff;
            n |= (bs[++cnt] & 0xff) << 8;
            n |= (bs[++cnt] & 0xff) << 16;
            n |= bs[++cnt] << 24;
            ns[i] = n;
            off += 4;
        }
        return ns;
    }

    /**
     * @param ns : Int 배열
     * @return Int를 Word로 변환한 바이트 배열
     */
    public byte[] intToWord(int[] ns) {
        byte[] bs = new byte[ns.length * 4];
        int off = 0;
        for (int i = 0; i < ns.length; ++i) {
            int cnt = off;
            bs[cnt] = (byte) (ns[i]);
            bs[++cnt] = (byte) (ns[i] >>> 8);
            bs[++cnt] = (byte) (ns[i] >>> 16);
            bs[++cnt] = (byte) (ns[i] >>> 24);
            off += 4;
        }
        return bs;
    }

    /**
     * @param seed byte array
     * @return base64 인코딩된 String
     */
    public String seedEncodeBase64(byte[] seed) {
        Base64.Encoder base64Encoder = Base64.getEncoder();
        String strSeed = base64Encoder.encodeToString(seed);
        return strSeed;
    }
    /**
     * @param strSeed base64 인코딩된 String
     * @return byte array
     */
    public byte[] seedDecodeBase64(String strSeed) {
        Base64.Decoder base64Decoder = Base64.getDecoder();
        byte[] seed = base64Decoder.decode(strSeed);
        return seed;
    }
}

