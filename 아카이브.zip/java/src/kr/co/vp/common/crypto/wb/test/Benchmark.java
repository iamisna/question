/**
 * @file    BenchmarkNew.java
 * @brief   시간 측정
 * @author  FDL @ KMU
 * @date    2022.08.15.
 * UTF-8
 */
package kr.co.vp.common.crypto.wb.test;

import kr.co.vp.common.crypto.wb.Cbclea;
import kr.co.vp.common.crypto.wb.Ctrlea;
import kr.co.vp.common.crypto.wb.Padding;
import kr.co.vp.common.crypto.wb.exception.WhiteBoxException;
import kr.co.vp.common.crypto.wb.mac.Vpmac;
import kr.co.vp.common.crypto.wb.random.Randperm;
import kr.co.vp.common.crypto.wb.wflea.*;

public class Benchmark {
    private static int iterationNum = 100;
    private static int blockNum = 39;

    public void TimeWBWFLEA(WbwfleaConfig config) {
        double start, finish;
        double duration = 0;

        /* setup: key */
        Common common = new Common();
        byte[] key = common.genRandBytes(32);

        /* setup: WFLEA context (roundkey generation) */
        Wflea Wflea = new Wflea();
        WfleaCtx wfleaCtx = Wflea.wfleaGenCtx(key, config);

        /* test: WFLEA round trip */
        byte[] enc;
        byte[] dec = new byte[16];
        byte[] rec;

        /* plaintext generation */
        enc = common.genRandBytes(16);

        /* WFLEA encryption */
        start = System.nanoTime();
        for(int i=0; i<4000; i++){
            dec = Wflea.wfleaEncryptblk(enc, wfleaCtx);
        }
        finish = System.nanoTime();
        System.out.printf("\n%d 반복 ECB 암호화 : %04f \t (비화이트박스)", 4000, (0.000000001 * (finish - start)));

        /* WFLEA decryption */

        start = System.nanoTime();
        for(int i=0; i<4000; i++){
            rec = Wflea.wfleaDecryptblk(dec, wfleaCtx);
        }
        finish = System.nanoTime();
        System.out.printf("\n%d 반복 ECB 복호화 : %04f \t (비화이트박스)", 4000, (0.000000001 * (finish - start)));

        /* test: whitebox encryption */
        /* external encoding generation (for encryption) */
        Randperm randperm = new Randperm();
        byte[] AeSeed = common.genRandBytes(32);
        byte[] BeSeed = common.genRandBytes(32);

        WbwfleaExtEncoding Ae = randperm.genRandperm128Bits(AeSeed);
        WbwfleaExtEncoding Be = randperm.genRandperm128Bits(BeSeed);

        /* random networked encodings generation (for encryption) */
        WbwfleaEncodings wbwfleaEncodings = new WbwfleaEncodings();
        WbwfleaEncodingsForEncryption encCtx = wbwfleaEncodings.wbwfleaGenEncodingsForEncryption(Ae, Be, config);

        /* encryption table generation with external encoding, random networked encodings, roundkey */
        WbwfleaTables wbwfleaTables = new WbwfleaTables();
        String encryptTab = "";
        start = System.nanoTime();
        for(int i=0; i<iterationNum; i++){
            encryptTab = wbwfleaTables.wbwfleaGenEncryptionTableBase64(encCtx, wfleaCtx, config); // 암호화 키 테이블 생성 base64
        }
        finish = System.nanoTime();
        System.out.printf("\n%d 반복 ECB 암호화 키생성 : %04f", iterationNum, (0.000000001 * (finish - start)));

        /* WhiteBox WFLEA Encryption */
        WbwfleaExtTransform wbwfleaExtTransform = new WbwfleaExtTransform();

        byte[] wbeDat = new byte[16];
        System.arraycopy(enc, 0, wbeDat, 0, 16);

        wbeDat = wbwfleaExtTransform.wbwfleaExtTransforms(Ae, wbeDat, 0);		// WFLEA와의 비교를 위해 외부인코딩 적용.

        WbwfleaEncrypt wbwfleaEncrypt = new WbwfleaEncrypt();
        WbwfleaEncryptionTable encTab = new WbwfleaEncryptionTable(config);

        /* test: whitebox decryption */
        /* external encoding generation (for decryption) */
        byte[] AdSeed = common.genRandBytes(32);
        byte[] BdSeed = common.genRandBytes(32);
        WbwfleaExtEncoding Ad = randperm.genRandperm128Bits(AdSeed);
        WbwfleaExtEncoding Bd = randperm.genRandperm128Bits(BdSeed);

        /* random networked encodings generation (for decryption) */
        WbwfleaEncodingsForDecryption decCtx = wbwfleaEncodings.wbwfleaGenEncodingsForDecryption(Ad, Bd, config);
        String decryptTab = "";
        /* decryption table generation with external encoding, random networked encodings, roundkey */
        start = System.nanoTime();
        for (int i=0; i<iterationNum; i++){
            decryptTab = wbwfleaTables.wbwfleaGenDecryptionTableBase64(decCtx, wfleaCtx); // 복호화 키 생성 base64
        }
        finish = System.nanoTime();
        System.out.printf("\n%d 반복 ECB 복호화 키생성 : %04f", iterationNum, (0.000000001 * (finish - start)));

        byte[] wbdDat = new byte[16];
        System.arraycopy(dec, 0, wbdDat, 0, 16);

        duration = 0;
        for (int i=0; i<4000; i++){
            if(i % 40 == 0){
                start = System.nanoTime();
                encTab = wbwfleaEncrypt.encryptTabDecodeBase64(encryptTab, config);
                finish = System.nanoTime();
                duration += 0.000000001 * (finish - start);
            }
            start = System.nanoTime();
            wbwfleaEncrypt.wbwfleaEncryptwb(encTab, wbeDat);
            finish = System.nanoTime();
            duration += 0.000000001 * (finish - start);
        }
        System.out.printf("\n%d 반복 ECB 암호화 : %04f", 4000, duration);

        /* external excoding A */
        wbdDat = wbwfleaExtTransform.wbwfleaExtTransforms(Ad, wbdDat, 0);		// WFLEA와 비교하기 위해 암호문에 외부인코딩 적용

        WbwfleaDecryptionTable decTab = new WbwfleaDecryptionTable(config);
        start = System.nanoTime();
        for (int i=0; i<4000; i++){
            if(i % 40 == 0){
                decTab = wbwfleaEncrypt.decryptTabDecodeBase64(decryptTab, config);
            }
            byte[] dst = wbwfleaEncrypt.wbwfleaDecryptwb(decTab, wbdDat);
        }
        finish = System.nanoTime();
        System.out.printf("\n%d 반복 ECB 복호화 : %04f", 4000, (0.000000001 * (finish - start)));
    }

    public void TimeCBC(WbwfleaConfig config) throws WhiteBoxException {
        double start, finish;
        double duration = 0;

        /* param set */
        Common common = new Common();
		byte[] key = common.genRandBytes(16);
		byte[] iv = common.genRandBytes(16);

        byte[] cbcIv = new byte[16];         //LEA CBC
        byte[] WbIv = new byte[16];          //WBLEA CBC

		byte[] wbeDat = common.genRandBytes(blockNum * 16);

        byte[] rndtrip = new byte[blockNum * 16];
        byte[] cbcDat = new byte[blockNum * 16];

        System.arraycopy(wbeDat, 0, rndtrip, 0, blockNum * 16);		// round trip
        System.arraycopy(wbeDat, 0, cbcDat, 0, blockNum * 16);		// LEA CBC
        System.arraycopy(iv, 0, cbcIv, 0, 16);
        System.arraycopy(iv, 0, WbIv, 0, 16);

        String ivBase64 = common.seedEncodeBase64(iv);								// iv base64 Encoding
        String wbIvBase64 = common.seedEncodeBase64(WbIv);							// iv base64 Encoding
        byte[] encodedMsg = new byte[blockNum * 16 + 16];

        /* key table gen (encryption, decryption) */
        /* external encoding generation (for encryption) */
        Randperm randperm = new Randperm();
		byte[] BeSeed = common.genRandBytes(32);
        WbwfleaExtEncoding Be = randperm.genRandperm128Bits(BeSeed);

        /*Xor encoding (for encryption) */
		byte[] CBCAeSeed = common.genRandBytes(32);
        String CBCAeSeedBase64 = common.seedEncodeBase64(CBCAeSeed);		// CBCAe 외부인코딩을 생성하는 시드값 base64 적용하여 저장

        /*Xor encoding (for decryption) */
		byte[] CBCBeSeed = common.genRandBytes(32);
        String CBCBeSeedBase64 = common.seedEncodeBase64(CBCBeSeed);		// CBCBe 외부인코딩을 생성하는 시드값 base64 적용하여 저장

        /* encryption table generation with external encoding, random networked encodings, roundkey */
        /* Xor table (for encryption) */
        Cbclea cbclea = new Cbclea();
        String encryptTab = "";
        start = System.nanoTime();
        for (int i=0; i<iterationNum; i++){
            encryptTab = cbclea.cbcKeyGenEncBase64(CBCAeSeed, BeSeed, key, config);		// 암호화 테이블 base64 적용하여 저장
        }
        finish = System.nanoTime();
        System.out.printf("\n%d 반복 CBC 암호화 키생성 : %04f", iterationNum, 0.000000001 * (finish - start));

        /* decryption table generation with external encoding, random networked encodings, roundkey */
        /* Xor table (for decryption) */
        String decryptTab = "";
        start = System.nanoTime();
        for(int i=0; i< iterationNum; i++){
            decryptTab = cbclea.cbcKeyGenDecBase64(CBCBeSeed, BeSeed, key, config);		// 복호화 테이블 base64 적용하여 저장
        }
        finish = System.nanoTime();
        System.out.printf("\n%d 반복 CBC 복호화 키생성 : %04f", iterationNum, 0.000000001 * (finish - start));

        WbwfleaExtTransform wbwfleaExtTransform = new WbwfleaExtTransform();
        /*WBLEA CBC encryption*/
        /*encryption*/

        /*encode in wb-secure zone*/
        start = System.nanoTime();
        for(int i=0; i<iterationNum; i++){
            Padding padding = cbclea.encodeBase64(wbeDat, CBCAeSeedBase64);		// WB CBC 패딩. 얼마나 패딩했는지 배열 마지막에 붙여서 리턴.

            int wbDataLen = wbeDat.length + padding.getPadNum();	// 패딩된 메시지 길이 = 메시지 길이 + 얼마나 패딩했는지 (배열 마지막 값)
            encodedMsg = new byte[wbDataLen];
            System.arraycopy(padding.getPaddedMsg(), 0, encodedMsg, 0, wbDataLen);	// 패딩된 메시지만 복사하여 사용

            /*WB CBC lea*/
            encodedMsg = cbclea.wbcbcLeaEncryptBase64(encryptTab, encodedMsg, ivBase64, config);
        }
        finish = System.nanoTime();
        System.out.printf("\n%d 반복 CBC 암호화 : %04f", iterationNum, 0.000000001 * (finish - start));

        byte[] tmp = encodedMsg;

        /*WBLEA CBC decryption*/
        start = System.nanoTime();
        for(int i=9; i<iterationNum; i++){
            encodedMsg = cbclea.wbwfcbcLeaDecryptBase64(decryptTab, tmp, wbIvBase64, config);		// WB CBC 복호화

            Padding padding = cbclea.decodeBase64(encodedMsg, CBCBeSeedBase64);		//PADDING 제거. 얼마나 패딩을 제거했는지 배열 마지막에 함께 리턴.

            /* 패딩 제거된 메시지 길이 = 메시지 길이 - 얼마나 패딩을 제거했는지 (배열 마지막 값) */
            int wbDataLen = encodedMsg.length - padding.getPadNum();
            byte[] wbdecmsg = new byte[wbDataLen];
            System.arraycopy(padding.getPaddedMsg(), 0, wbdecmsg, 0, wbDataLen);	// 패딩 제거된 메시지만 복사하여 사용
        }
        finish = System.nanoTime();

        System.out.printf("\n%d 반복 CBC 복호화 : %04f", iterationNum,  0.000000001 * (finish - start));

        /* 비화이트 박스 연산 : CBC LEA 속도 측정 파트 */
        byte[] decCbc = new byte[blockNum * 16 + 16];
        Padding padding;
        int cbcDataLen;
        start = System.nanoTime();
        for (int i=0; i<iterationNum; i++){
            /* Encode */
            padding = cbclea.cbcPad(cbcDat);			// PADDING

            cbcDataLen = cbcDat.length + padding.getPadNum();			// 패딩된 메시지의 길이 = 메시지 길이 + 얼마나 패딩했는지 (배열 마지막 값)

            byte[] cbcmsg = new byte[cbcDataLen];
            System.arraycopy(padding.getPaddedMsg(), 0, cbcmsg, 0, cbcDataLen);	// 패딩된 메시지만 복사하여 사용
            decCbc = cbclea.cbcLea(cbcmsg, cbcIv, key, config);							// CBC LEA
        }
        finish = System.nanoTime();
        System.out.printf("\n%d 반복 CBC 암호화 : %04f \t (비화이트박스)", iterationNum,  0.000000001 * (finish - start));

        start = System.nanoTime();
        for(int i=0; i<iterationNum; i++){
            byte[] rec = cbclea.inCbcLea(decCbc, cbcIv, key, config);			// CBC LEA 복호화

            padding = cbclea.removePad(rec);		// 패딩 제거. 얼마나 제거했는지 배열 마지막에 함께 리턴.

            /* 패딩 제거된 메시지 길이 = 메시지 길이 - 얼마나 패딩을 제거했는지 (배열 마지막 값) */
            cbcDataLen = rec.length - padding.getPadNum();
            byte[] decodeMsg = new byte[cbcDataLen];
            System.arraycopy(padding.getPaddedMsg(), 0, decodeMsg, 0, cbcDataLen);	// 패딩 제거된 메시지만 복사하여 사용
        }
        finish = System.nanoTime();
        System.out.printf("\n%d 반복 CBC 복호화 : %04f \t (비화이트박스)", iterationNum,  0.000000001 * (finish - start));
    }

    public void TimeCTR(WbwfleaConfig config) throws WhiteBoxException {
        double start, finish;
        /* param set */
        Common common = new Common();
        byte[] key = common.genRandBytes(16);
        byte[] iv = common.genRandBytes(16);
        byte[] wbeDat = common.genRandBytes(blockNum * 16 + 16);

        byte[] CTRIV = new byte[16];    //In CTR LEA
        byte[] WbIV = new byte[16];     //IN CTR WBLEA
        byte[] rndtrip = new byte[blockNum * 16 + 16];		// round trip
        byte[] ctrDat = new byte[blockNum * 16 + 16];		// ctr lea 평문

        System.arraycopy(wbeDat, 0, rndtrip, 0, blockNum * 16 + 16);
        System.arraycopy(wbeDat, 0, ctrDat, 0, blockNum * 16 + 16);
        System.arraycopy(iv, 0, CTRIV, 0, 16);
        System.arraycopy(iv, 0, WbIV, 0, 16);
        String ivStr = common.seedEncodeBase64(WbIV);

        int ctrDataLen = 0;

        byte[] encodedMsg = new byte[blockNum * 16 + 16];

        /* CTR-table-permutation */
        byte[] CTRGSeed = common.genRandBytes(32);			//XOR g
        String CTRGSeedBase64 = common.seedEncodeBase64(CTRGSeed);

        Randperm randperm = new Randperm();
        byte[] CTRHSeed = common.genRandBytes(32);
        WbwfleaExtEncoding CTRH = randperm.genRandperm128Bits(CTRHSeed);	//XOR h

        /* CTR-table-permutation */
        byte[] CTRHdSeed = common.genRandBytes(32);
        String CTRHdSeedBase64 = common.seedEncodeBase64(CTRHdSeed);

        /* CTR-table-gen */
        byte[] AeSeed = common.genRandBytes(32);
        WbwfleaExtEncoding Ae = randperm.genRandperm128Bits(AeSeed);

        /* encryption table generation with external encoding, random networked encodings, roundkey */
        /* Xor table (for encryption) */
        Ctrlea ctrlea = new Ctrlea();
        String encryptTab = "";
        start = System.nanoTime();
        for(int i=0; i<iterationNum; i++){
            encryptTab = ctrlea.ctrKeyGenEncBase64(AeSeed, CTRHSeed, CTRGSeed, key, config);   //key gen base64
        }
        finish = System.nanoTime();
        System.out.printf("\n%d 반복 CTR 암호화 키생성 : %04f", iterationNum, 0.000000001 * (finish - start));

        /* decryption table generation with external encoding, random networked encodings, roundkey */
        /* Xor table (for decryption) */
        String decryptTab = "";
        start = System.nanoTime();
        for(int i=0; i<iterationNum; i++){
            decryptTab = ctrlea.ctrKeyGenDecBase64(AeSeed, CTRHSeed, CTRHdSeed, key, config);   //key gen base64
        }
        finish = System.nanoTime();
        System.out.printf("\n%d 반복 CTR 복호화 키생성 : %04f", iterationNum, 0.000000001 * (finish - start));

        Cbclea cbclea = new Cbclea();
        /* WBLEA CTR*/
        /*encryption*/
        /*encode in wb-secure zone*/
        Padding padding;
        int wbDataLen = 0;
        start = System.nanoTime();
        for(int i=0; i<iterationNum; i++){
            padding = cbclea.encodeBase64(wbeDat, CTRGSeedBase64);			// WB CBC 패딩. 얼마나 패딩했는지 배열 마지막에 붙여서 리턴.

            wbDataLen = wbeDat.length + padding.getPadNum(); // 패딩된 메시지 길이 = 메시지 길이 + 얼마나 패딩했는지 (배열 마지막 값)
            encodedMsg = new byte[wbDataLen];
            System.arraycopy(padding.getPaddedMsg(), 0, encodedMsg, 0, wbDataLen);	// 패딩된 메시지만 복사하여 사용

            /*WB CTR lea encryption*/
            encodedMsg = ctrlea.wbctrLeaEncBase64(encryptTab, encodedMsg, ivStr, config);			// WB CTR 암호화 base64
        }
        finish = System.nanoTime();
        System.out.printf("\n%d 반복 CTR 암호화 : %04f", iterationNum, 0.000000001 * (finish - start));

        /*WB CTR LEA decryption*/
        byte[] tmp = encodedMsg;
        start = System.nanoTime();
        for(int i=0; i<iterationNum; i++){
            encodedMsg = ctrlea.wbctrLeaDecBase64(decryptTab, tmp, ivStr, config);	// WB CTR 복호화 base64

            padding = cbclea.decodeBase64(encodedMsg, CTRHdSeedBase64);		// PADDING 제거. 얼마나 패딩을 제거했는지 배열 마지막에 함께 리턴.

            /* 패딩 제거된 메시지 길이 = 메시지 길이 - 얼마나 패딩을 제거했는지 (배열 마지막 값) */
            wbDataLen = encodedMsg.length - padding.getPadNum();
            byte[] wbdecmsg = new byte[wbDataLen];
            System.arraycopy(padding.getPaddedMsg(), 0, wbdecmsg, 0, wbDataLen); // 패딩 제거된 메시지만 복사하여 사용
        }
        finish = System.nanoTime();
        System.out.printf("\n%d 반복 CTR 복호화 : %04f", iterationNum, 0.000000001 * (finish - start));


        byte[] decCtr = new byte[blockNum * 16 + 16];
        start = System.nanoTime();
        for(int i=0; i<iterationNum; i++){
            padding = cbclea.cbcPad(ctrDat); 	// PADDING한 뒤 얼마나 패딩했는지 배열 마지막에 포함하여 리턴

            ctrDataLen = ctrDat.length + padding.getPadNum();	// 패딩된 메시지의 길이 = 메시지 길이 + 얼마나 패딩했는지 (배열 마지막 값)
            byte[] ctrmsg = new byte[ctrDataLen];
            System.arraycopy(padding.getPaddedMsg(), 0, ctrmsg, 0, ctrDataLen); // 패딩된 메시지만 복사하여 사용

            /* CTR LEA encryption*/
            /* encode Ae for compare WBLEA and LEA*/
            decCtr = ctrlea.ctrLeaWEncoder(ctrmsg, iv, Ae, key, config);		// CTR LEA 암호화
        }
        finish = System.nanoTime();
        System.out.printf("\n%d 반복 CTR 암호화 : %04f \t (비화이트박스)", iterationNum, 0.000000001 * (finish - start));


        /* CTR LEA decryption */
        byte[] rec;
        start = System.nanoTime();
        for(int i=0; i<iterationNum; i++){
            rec = ctrlea.ctrLeaWEncoder(decCtr, CTRIV, Ae, key, config);			// CTR LEA 복호화

            padding = cbclea.removePad(rec);		 // 패딩 제거. 얼마나 제거했는지 배열 마지막에 함께 리턴.

            /* 패딩 제거된 메시지 길이 = 메시지 길이 - 얼마나 패딩을 제거했는지 (배열 마지막 값) */
            ctrDataLen = rec.length - padding.getPadNum();
            byte[] decodeMsg = new byte[ctrDataLen];
            System.arraycopy(padding.getPaddedMsg(), 0, decodeMsg, 0, ctrDataLen);	// 패딩 제거된 메시지만 복사하여 사용
        }
        finish = System.nanoTime();
        System.out.printf("\n%d 반복 CTR 복호화 : %04f \t (비화이트박스)", iterationNum, 0.000000001 * (finish - start));
    }

    public void TimeVPMAC(WbwfleaConfig config) throws WhiteBoxException {
        double start, finish;

        /*param gen*/
        Common common = new Common();
		byte[] key = common.genRandBytes(16);
		byte[] iv = common.genRandBytes(16);
		byte[] wbeDat = common.genRandBytes(blockNum * 16);

        byte[] ivSig = new byte[16];
        System.arraycopy(iv, 0, ivSig, 0, 16);		// 서명용 IV. 복사하여 사용.
        byte[] copyDat = new byte[blockNum * 16];
        System.arraycopy(wbeDat, 0, copyDat, 0, blockNum * 16);	// 서명 검증용 평문. 복사하여 사용.

        /* test: whitebox encryption */
        /* external encoding generation (for encryption) */
        Randperm randperm = new Randperm();
		byte[] BeSeed = common.genRandBytes(32);
        WbwfleaExtEncoding Be = randperm.genRandperm128Bits(BeSeed);
        String BeSeedBase64 = common.seedEncodeBase64(BeSeed);

        /* wk1 start*/
		byte[] AinSeed = common.genRandBytes(32);
		byte[] BinSeed = common.genRandBytes(32);

        Vpmac vpmac = new Vpmac();
        String wk1 = "";
        String wk2 = "";

        start = System.nanoTime();
        for(int i=0; i<iterationNum; i++){
            wk1 = vpmac.vpmacWk1KeyGenBase64(AinSeed, BinSeed, key, config);		// wk1 생성 base64
        }
        finish = System.nanoTime();
        System.out.printf("\n%d 반복 VPMAC WK1 키생성 : %04f", iterationNum, 0.000000001 * (finish - start));

        start = System.nanoTime();
        for(int i=0; i<iterationNum; i++){
            wk2 = vpmac.vpmacWk2KeyGenBase64(AinSeed, BinSeed, iv, BeSeed, key, config);		// wk2 생성 base64
        }
        finish = System.nanoTime();
        System.out.printf("\n%d 반복 VPMAC WK2 키생성 : %04f", iterationNum, 0.000000001 * (finish - start));


        WbwfleaExtTransform wbwfleaExtTransform = new WbwfleaExtTransform();
        byte[] dec = new byte[16];
        /*VPMAC sig GEN*/
        start = System.nanoTime();
        for(int i=0; i<iterationNum; i++){
            dec = vpmac.vpMacGenTagFromBase64(wk1, wk2, wbeDat, config);		// vpmac sig gen.
        }
        finish = System.nanoTime();
        System.out.printf("\n%d 반복 VPMAC Sig 생성 : %04f", iterationNum, 0.000000001 * (finish - start));

        byte[] tag = new byte[16];
        System.arraycopy(dec, 0, tag, 0, 16);		// 서명 검증시 사용할 tag에 복사.

        start = System.nanoTime();
        for(int i=0; i<iterationNum; i++){
            String ivSigBase64 = common.seedEncodeBase64(ivSig);
            vpmac.vpMacTagVerifyBase64(key, wbeDat, ivSigBase64, BeSeedBase64, tag, config);
        }
        finish = System.nanoTime();
        System.out.printf("\n%d 반복 VPMAC Sig 검증 : %04f", iterationNum, 0.000000001 * (finish - start));
    }
}
